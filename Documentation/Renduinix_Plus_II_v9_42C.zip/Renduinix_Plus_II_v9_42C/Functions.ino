//Dumping General Functions here

// read in the button presses
byte readLcdButtons()
{
  static int adcKeyIn = 0; //Analog read, keep int
  static unsigned long btnPrevTime;
  static int btnRead1; //keep int for analog read
  static int btnRead2;
  static int btnRead3;
  static int btnRead4;

  if (millis() > btnPrevTime + 10){//time throttled sampling for more spaced out readings
    btnPrevTime = millis();
  //shifts last 4 button reads
  btnRead4 = btnRead3;
  btnRead3 = btnRead2;
  btnRead2 = btnRead1;
  btnRead1 = analogRead(buttonsPin);      // read the value from the button resistors

  // absolutle comparator makes sure all reads are within 4 units of each other to filter noise and button rise time
  if(abs(btnRead4 - btnRead1) < 5 && abs(btnRead3 - btnRead1) < 5 && abs(btnRead2 - btnRead1) < 5 && abs(btnRead4 - btnRead2) < 5)
    adcKeyIn = btnRead1;    // pass value through if it is consistant
  }
  
  // my buttons when read are centered at these values: 0, 512, 601, 698, 845, 1022
  // we add approx 10 to those values to allow variation
  if (adcKeyIn < 500) return btnNone; // We make this the 1st option for speed reasons since it will be the most likely result

  // custom thresholds used
  if (adcKeyIn < 522)  return btnHome;        //512
  if (adcKeyIn < 611)  return btnBottomRight; //601
  if (adcKeyIn < 708)  return btnBottomLeft;  //698
  if (adcKeyIn < 855)  return btnTopRight;    //845
  if (adcKeyIn < 1025) return btnTopLeft;     //1022
  return btnNone;  // when all others fail, return this...
}

//easy exponential average method using Infintie Impulse Response, 0(long) to 1(no change)*****************************************************************
float expoAVG(float Input, float oldInput, float ALPHA){
  //Look up IIF, Alpha is a number from 0(long) to 1(no change)
  return ALPHA * Input + (1 - ALPHA) * oldInput;
}

//prints X if test is False ********************************************************************************************************
void xPrint(bool Input){
  if (Input == true)
    lcd.print("X");
  else
    lcd.print(" ");
}

//prints X if test is False ********************************************************************************************************
void tPrint(char Text, bool Input){
  if (Input == true)
    lcd.print(Text);
  else
    lcd.print(" ");
}

//space pad int values ********************************************************************************************************
void intPrint (int value, byte significant) 
{
  if (value < 0) //negitive sign handeling 
    --significant;
  if (abs(value) < 10000000 && significant > 7)
    lcd.print(" ");
  if (abs(value) < 1000000 && significant > 6)
    lcd.print(" ");
  if (abs(value) < 100000 && significant > 5)
    lcd.print(" ");
  if (abs(value) < 10000 && significant > 4)
    lcd.print(" ");
  if (abs(value) < 1000 && significant > 3)
    lcd.print(" ");
  if (abs(value) < 100 && significant > 2)
    lcd.print(" ");
  if (abs(value) < 10 && significant > 1)
    lcd.print(" ");
  lcd.print(value);
}

//space pad float values up to 3 decimal digits ********************************************************************************
void floatPrint (float value, byte significant, byte decimal) 
{
  float val10 = 0;
  switch (decimal){ //fun fact, lcd.print rounds up the LSD so comparisons get annoying
    case 1:
      val10 = 0.95;
    break;
    case 2:
      val10 = 0.995;
    break;
    case 3:
      val10 = 0.9995;
    break;
  }

  significant -= decimal + 1; //makes formatting easier by just inputing total spaces needed, including decimal spot
  
  if (value < 0) //negitive sign handeling 
    --significant;

  float absValue = abs(value); //used in place of if statments since abs trunicates decimal comparisons
  
  if (absValue < val10 + 9999 && significant > 4)
    lcd.print(" ");
  if (absValue < val10 + 999 && significant > 3)
    lcd.print(" ");
  if (absValue < val10 + 99 && significant > 2)
    lcd.print(" ");
  if (absValue < val10 + 9 && significant > 1)
    lcd.print(" ");
  lcd.print(value, decimal);
}

//left justify and space pad int values ********************************************************************************************************
void leftPrint(int value, byte significant){
  lcd.print(value);
  if (value < 0) //negitive sign handeling 
    --significant;
  if (abs(value) < 10000000 && significant > 7)
    lcd.print(" ");
  if (abs(value) < 1000000 && significant > 6)
    lcd.print(" ");
  if (abs(value) < 100000 && significant > 5)
    lcd.print(" ");
  if (abs(value) < 10000 && significant > 4)
    lcd.print(" ");
  if (abs(value) < 1000 && significant > 3)
    lcd.print(" ");
  if (abs(value) < 100 && significant > 2)
    lcd.print(" ");
  if (abs(value) < 10 && significant > 1)
    lcd.print(" ");
}

//show 255 reading in 100 scale
byte hundredConvert(byte input) {
  return input / 2.55;
}

//behind the scenes adjuster to ensure visual increase amount is met
void hundredAdjust(byte &input, int amount) {
  byte *pInput = &input;
  
  byte tempHund = hundredConvert(*pInput) + amount; //the value we want to see afterwards
  byte watchDog = 0; //safegaurd inf loop
 
  if (tempHund == 0) //safegaurd near 0 issues
    *pInput = 0;
  else {
    while(hundredConvert(*pInput) != tempHund) {
      *pInput += amount;
      
      if (watchDog > 8)
        break;
      ++watchDog;
    }
  }
}

void serialPad (byte value)
{
  if (value < 100)
    Serial.print(" ");
  if (value < 10)
    Serial.print(" ");
  Serial.print(value);
}

//0 pad binary values ********************************************************************************************************
void binPrint(int c) 
{
  for (int bits = 7; bits > -1; bits--)
  {
    if (c & (1 << bits))  //compare bits 7-0 in byte
      lcd.print ("1");
    else 
      lcd.print ("0");
  }
}

void binSPrint(int c) 
{
  for (int bits = 7; bits > -1; bits--)
  {
    if (c & (1 << bits))  //compare bits 7-0 in byte
      Serial.print ("1");
    else 
      Serial.print ("0");
  }
}

//print number of true bits in a value ****************************************************************************************
void bitPrint(int c) 
{
  byte counter = 0;
  for (int bits = 7; bits > -1; bits--)
  {
    if (c & (1 << bits))  //compare bits 7-0 in byte
      ++counter;
  }
  lcd.print(counter);
}

//create 2 lcd characters to represent 8 bits of the input, use 1-4 ********************************************************
void drawBinChar(byte input, byte CHAR)
{
//makes typing in the starter char easier 
  CHAR *= 2;
  
//used for other functions that use custom characters
  charFlag = true;
  
//create characters from inputs
  drawCharBits(input, CHAR - 1, 2);
  drawCharBits(input, CHAR, 0);
}

//prints 2 lcd characters to represent 8 bits of the input, use 1-4 ********************************************************
void printBinChar(byte CHAR)
{
//makes typing in the starter char easier 
  CHAR *= 2;

//print symbol first since createChar erases lcd cursor memory, onscreen character will automatically update to CGRAM
  lcd.write(CHAR - 1);
  lcd.write(CHAR);
}

//creates lcd character to represent 4 bits of the input *****************************************************************
void drawCharBits(byte input, byte CHAR, byte NUM)
{
  // declare Char Array
  byte symbol[8] = //notice the centering dot
  {
    B00000,
    B00000,
    B00000,
    B00100,
    B00000,
    B00000,
    B00000
  };

//Compund Bitwise OR will add to itself to the symbol if selected bit is true
  if (bitRead(input, NUM + 5)) //top left
  {
    symbol[0] |= B11000;
    symbol[1] |= B11000;
    symbol[2] |= B11000;    
  }
  if (bitRead(input, NUM + 1)) //bottom left
  {
    symbol[4] |= B11000;
    symbol[5] |= B11000;
    symbol[6] |= B11000;    
  }
  if (bitRead(input, NUM + 4)) //top right
  {
    symbol[0] |= B00011;
    symbol[1] |= B00011;
    symbol[2] |= B00011;    
  }
  if (bitRead(input, NUM + 0)) //bottom right
  {
    symbol[4] |= B00011;
    symbol[5] |= B00011;
    symbol[6] |= B00011;    
  }

//write the symbol to LCD Memory, this erases lcd cursor memory so we print this later (or before since lcd display automatially updates to cgRAM)
  lcd.createChar(CHAR, symbol);
}

//used to print temperature symbol ********************************************************************************************************
void tempSymbol()
{ 
//if characters are not in use, print temp symbol, decided outside of function
  if (charFlag == false)
    lcd.write(1);
  else
  { 
    if (tempUnit == false)
     lcd.print("c");
    else
     lcd.print("f");
  }
}

//creates temp character while only using 1 RAM slot ******************************************************************************************
void createTempChar()
{
  if (tempUnit == false)
    lcd.createChar(1, celsiusSymbol);  //sends custom character to lcd memory
  else
    lcd.createChar(1, fahrenheitSymbol);

}

//creates spinning character while only using 1 RAM slot ******************************************************************************************
void createDizzyChar()
{
//only update character if a change has been noticed
  if (dizzyFlag == true)
  {
    dizzyFlag = false;        //reset flag
    ++dizzyCounter;           //increase display counter
    if (dizzyCounter > 7)    //slows down animation 
      dizzyCounter = 0;
    
    switch (dizzyCounter)     //send appropriate character the lcd ram slot
    {
      case 0:
        lcd.createChar(2, dizzy1);
      break;
      case 1:
        lcd.createChar(2, dizzy2);
      break;
      case 2:
        lcd.createChar(2, dizzy3);
      break;
      case 3:
        lcd.createChar(2, dizzy4);
      break;
      case 4:
        lcd.createChar(2, dizzy5);
      break;
      case 5:
        lcd.createChar(2, dizzy6);
      break;
      case 6:
        lcd.createChar(2, dizzy7);
      break;
      case 7:
        lcd.createChar(2, dizzy8);
      break;
    }
  }
}

//prints circle symbols at indicated columns ********************************************************************************
void circlePrint(byte Left, byte Right){
  lcd.setCursor(Left,1);
  lcd.write(6);
  lcd.setCursor(Right,1);
  lcd.write(7);
}

//automatically centers and prints text by length ************************************************************************************
void centerPrint(String text, byte row){
  byte column = text.length();
  column = (16 - column) / 2; //Total - Length / 2
  lcd.setCursor(column, row);
  lcd.print(text);
}
          
//formula to convert raw byte into desired pressure ******************************************************************************************
float pressureConvert(byte Input){
  float Output = 0;
  switch(pressureUnit){
    /*case 1://Voltage Calc
      Output = (MAPRaw / 51.2);//converts to Voltage (0 - 4.98)
    break;*/
    case 2://inHg
      Output = (Input / 9.13 + 3.1); //converts to "Hg (3.1 - 31)
    break;
    case 3://KPA
      Output = (Input / 2.7 + 11);//converts to KPA (11 - 105)
    break;
    case 4://PSI
      Output = (Input / 18.6 + 1.5);//converts to PSI (1.52 - 15.2)
    break;
   }
   return Output;
}

//formula to convert raw byte into desired temperature ***************************************************************************************
int tempConvert(byte Input){ 
  int Output;
  if (tempUnit == false)
    Output = (Input * 0.625 - 40); //converts to Celsius (-40 - 119)
  else
    Output = (Input * 1.125 - 40); //converts to Fahrenheit (-40 - 247)
  return Output;
}

//formula to convert unit into desired distance **********************************************************************************************
float distanceConvert(float Input){
  if (speedUnit == false)
    return Input * 1.609; //converts to KPH
  else
    return Input; //converts to MPH
}

//formula to convert unit into desired volume *************************************************************************************************
float fuelConvert(float Input){ 
  if (speedUnit == false)
    return Input * 3.785; //converts to Litres
  else
    return Input; //converts to Gallons
}

//used to print errors codes and line advance *************************************************************************************************
void errorPrint(bool input, String string)
{
  if (input == true)
  {
    if (ecuCursor > -1 && ecuCursor < 2)
    {
      lcd.setCursor(0,ecuCursor);
      lcd.print(string);
    }
    ++ecuCursor;
  }
}

//used to print tcu errors codes and line advance *************************************************************************************************
void TerrorPrint(bool input, String string)
{
  if (input == true)
  {
    if (tcuCursor > -1 && tcuCursor < 2)
    {
      lcd.setCursor(0,tcuCursor);
      lcd.print(string);
    }
    ++tcuCursor;
  }
}

// automated up/down scroller with safe rollover protection ***********************************************************************************
void upDownArrowScroller(byte &Ainput, byte MIN, byte MAX) {
  byte *input = &Ainput; //point to original value

  if (btnCheck(btnTopRight)) { //decrease value with rollover
    if (*input <= MIN)
      *input = MAX;
    else
      --*input;
  }

  if (btnCheck(btnBottomRight)) { //increase value with rollover
    if (*input >= MAX)
      *input = MIN;
    else
      ++*input;
  }
}

//Static scroll menu printer ********************************************************************************************************
void scrollPrint(byte index, String string, byte input)
{
  if (input == index)
  {
    lcd.setCursor(1,0);
    lcd.print(string);
  }
  if (input + 1 == index)
  {
    lcd.setCursor(1,1);
    lcd.print(string);
  }
}

/***********************************
 * True/False List Scrolling System:
 * 
 * var desired row                          = list display position
 * var count total possible list elements   = boundary checking
 * 
 * 
 * Top of Loop:
 * 
 * listCursorMove ++/-- // change desired cursor position
 * 
 * listReset(); // resets list counter and constrains listCursorMove bounds, use after move but before list printing 
 * 
 * prevCursorBlock = listCursor; //saves current list value for "No Show" messages if no other checks pass
 * 
 * listCheck(); // self advancing counter that returns true if current list element is to be displayed 
 * listError(); // listCheck + Additonal True/False input check to display
 * listCEL();   // listCheck + CEL Array check to display, supports normal and flashing codes 
 * listTCU();   // listCheck + Additonal True/False input + Additonal Current True/False input for flashing codes 
 * 
 * if (listCursor == prevCursorBlock && listCheck()) //"No Show" message if no extra list checks ran
 */
//simple scroll check ***************************************************************************************************************
void listReset()
{
  /*
   * list cursor = 0
   * ++ list cursor on succesful checks
   * show if cursor == move or move +1
   * constrain move to max cursor count
   */
   
   listCursorMove = constrain(listCursorMove, 1, listCursor); // constrains within visible list element bounds
   listCursor = 0; //reset cursor
}

//simple scroll check ***************************************************************************************************************
bool listCheck()
{
  ++listCursor;
  if (listCursor == listCursorMove || listCursor == listCursorMove + 1){ //set Cursor if asked to display
    lcd.setCursor(0, listCursor - listCursorMove);
    return true;
  }
  else
    return false;  
}

//used to print errors codes and line advance **************************************************************************************
void listError(bool input, String string)
{
  if (input == true && listCheck() == true)
    lcd.print(string);
    
}

//used to print REM error codes and line advance **************************************************************************************
void listCEL(byte input, String string)
{   
//if Code is Current, replace spaces with blinking characters
  if (checkCELCode(input, true)){ 
    if (celBlinkyFlag == true)
      string.replace(' ', '*');
    else
      string.replace(' ', 255); 
  }

//Code Printing 
  if (checkCELCode(input, false) && listCheck() == true){
  
  //Skip printing 2nd code line if detailed view is active
    if (celExpandFlag == true && listCursor == listCursorMove + 1 && listCursor > 2)
      return;
    else
      lcd.print(string);

  //detailed view for first code line
    if (listCursor == listCursorMove && celExpandFlag == true)
    {
      lcd.setCursor(0,1);
      lcd.print("^");
      
      unsigned long celTime = millis() - celStopwatchArray[celPrevReading];
      if (celTime < 60000){
        intPrint(celTime / 1000, 3);
        lcd.print("sec");
      }
      else{
        intPrint(celTime / 60000, 3);
        lcd.print("min");
      }

      lcd.print("  Sum:");
      intPrint(celFaultArray[celPrevReading], 1);
      //intPrint(celGlitchArray[celPrevReading], 3);
      //lcd.print("P");
        
    }
  }
}

//used to print normal or flashing errors codes and line advance **************************************************************************************
void listTCU(bool input, bool currInput, String string)
{
  //if Code is Current, replace spaces with blinking characters
  if (currInput == true){ 
    if (celBlinkyFlag == true)
      string.replace(' ', '*');
    else
      string.replace(' ', 255); 
  }
  
  if ((input == true || currInput == true) && listCheck() == true)
    lcd.print(string);
    
}

//cleans up main code to switch an eeprom bool value and bring it to ram*****************************************************************
void eeBoolUpdate(int address, bool &aUnit){
  bool *unit = &aUnit;
  
  *unit = EEPROM.read(address);               
  if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
    *unit = !*unit;
  EEPROM.update(address, *unit);
}

//cleans up main code to switch an eeprom bool value and bring it to ram*****************************************************************
void rollover(byte &ainput, byte MIN, byte MAX){
  byte *input = &ainput;
  if (*input < MIN)
    *input = MAX;
  if (*input > MAX)
    *input = MIN;
}

//print ABS Solenoid output**************************************************************************************************************
void solenoidPrint(byte Input)
{
  switch(Input)
  {
    case 4: //Isolate, takes priority
      lcd.print("Isolate   ");
    break;                                             
    case 3://Build & Decay
      lcd.print("BuildDecay");
    break;
    case 2://Decay
      lcd.print("Decay     ");
    break;     
    case 1://Build
      lcd.print("Build     ");
    break;
    default:
      lcd.print("Off       ");
    break;
  }
}

void ocPrint(byte Input)
{
  if (Input == true)
    lcd.print("Closed");
  else
    lcd.print("Open  ");
}
void ynPrint(byte Input)
{
  if (Input == true)
    lcd.print("Yes");
  else
    lcd.print("No ");
}
void ofPrint(byte Input)
{
  if (Input == true)
    lcd.print("On ");
  else
    lcd.print("Off");
}
void printNumText(byte Input){
  switch(Input)
  {
    case 1:
      lcd.print("st");
    break;
    case 2:
      lcd.print("nd");
    break;
    case 3:
      lcd.print("rd");
    break;
    default:
      lcd.print("th");
    break;
  }
}

void printPressureText(){
  switch(pressureUnit){
    case 2://inHg
      lcd.print("\"Hg");
    break;
    case 3://KPA
      lcd.print("KPA");
    break;
    case 4://PSI
      lcd.print("PSI");
    break;
    }
}
//prints Left Arrow Symbol ************************************************************************************************************************
void leftArrow()
{
  lcd.write(127); //left arrow registure, DEL in proper Ascii
}

//prints Right Arrow Symbol ************************************************************************************************************************
void rightArrow()
{
  lcd.write(126); //right arrow registure, ~ in proper Ascii
}

//prints dual row arrows for menus ****************************************************************************************************************
void menuArrows()
{
  lcd.setCursor(0,0);
  lcd.print("<");
  lcd.setCursor(15,0);
  lcd.print(">");
  lcd.setCursor(0,1);
  leftArrow();
  lcd.setCursor(15,1);
  rightArrow();
}

//prints right justified up/down menu arrows*************************************************************************************************
void upDownArrows(){
  lcd.createChar(6, upArrow);
  lcd.createChar(7, downArrow);
  
  lcd.setCursor(15,0);
  lcd.write(6);//lcd.print("^");
  lcd.setCursor(15,1);
  lcd.write(7);//lcd.print("v");
}

//reads current button state **********************************************************************************************************
byte getBtnState(byte Test)
{
  /*
  //different button states
  const byte btnOFF     = 0;
  const byte btnPRESS   = 1;
  const byte btnHOLD    = 2;
  const byte btnREPEAT  = 3; //single trigger
  const byte btnRELEASE = 4; //mulitple trigger, --btnState to continue
  const byte btnUSED    = 5; //set to used after completed task
  
  static byte btnState = btnOFF; //start in the off state*/
  static unsigned long btnTimer = 0; //millis tracker
  //static byte btnPrev;

  if (lcdKey == btnNone && prevKey == btnNone) // #0 - state reset (release & used)
    btnState = btnOFF;

  if (btnState == btnUSED || updateScreen == menu){// #5 - skip state code if state was used
    btnState = btnUSED;
    return btnState;
  }
  
  if (lcdKey != btnNone && btnState == btnOFF){ // #1 - rising edge trigger
    btnState = btnPRESS;
    btnTimer = millis();
  }

  if (millis() > btnTimer + 600 && btnState == btnPRESS){ // #2 - hold trigger
    btnState = btnHOLD;
    btnTimer = millis();
  }
   
  if (millis() > btnTimer + 30 && btnState == btnHOLD){ // #3 - repeat trigger
    btnState = btnREPEAT; // to use this, just --btnState once when used
    btnTimer = millis();
  }

  if (lcdKey == btnNone && prevKey == Test && btnState > btnOFF) // #4 - falling edge trigger
    btnState = btnRELEASE;

  if (lcdKey == Test || prevKey == Test)
    return btnState;
  else
    return btnOFF; 
}

//OLD confirms press button request **********************************************************************************************************
bool btnCheck(byte Test){
  if (lcdKey == Test && btnPrev != lcdKey){
    btnPrev = lcdKey;
    return true;
  }
  else 
    return false;
}
//OLD confirms repeat button request **********************************************************************************************************
bool btnRepeat(byte Test){
  if (btnCheck(Test))
    return true;
  else if (btnRepeatFlag == true && lcdKey == Test){
    btnRepeatFlag = false;
    screenBtnFlag = false; //allows proper screen refresh
    return true;
  }
  else 
    return false;
}

//confirms press button request **********************************************************************************************************
bool btnPress(byte Test){
  if (getBtnState(Test) == btnPRESS){
    btnState = btnUSED;
    updateScreen = buttons;
    return true;
  }
  else 
    return false;
} 

//confirms hold button request **********************************************************************************************************
bool btnHold(byte Test){
  if (getBtnState(Test) == btnHOLD){
    btnState = btnUSED;
    updateScreen = buttons;
    return true;
  }
  else 
    return false;
} 

//confirms repeat button request **********************************************************************************************************
bool btnRepeat2(byte Test){
  if (getBtnState(Test) == btnREPEAT){
    --btnState;
    updateScreen = buttons;
    return true;
  }
  else 
    return false;
}

//confirms release button request **********************************************************************************************************
bool btnRelease(byte Test){
  if (getBtnState(Test) == btnRELEASE){
    btnState = btnUSED;
    updateScreen = buttons;
    return true;
  }
  else 
    return false;
  /*if (lcdKey == Test && btnPrev != lcdKey && btnHoldFlag == false){
    btnPrev = lcdKey;
  }
  if (lcdKey == btnNone && btnPrev == Test){
    btnPrev = lcdKey;
    updateScreen = buttons; //allows proper screen refresh
    return true;
  }
  
  return false;*/
}
void EEbitFlipper(byte EEin, byte EEbit){
  byte Tempfill = EEPROM.read(EEin);
  bool Switcharoo = !bitRead(Tempfill, EEbit);//Read
  
  bitWrite(Tempfill, EEbit, Switcharoo);      //flip
  
  EEPROM.update(EEin, Tempfill);              //write
}

//set board version from unit number ***************************************************************************************************************
void getBoardVersion()
{
  word unitNumber = 0;
  
  if (EEPROM.read(EEModelNumberHi) == 255)
    unitNumber = EEPROM.read(EEModelNumberLo);
  else 
    unitNumber = word(EEPROM.read(EEModelNumberHi),EEPROM.read(EEModelNumberLo));

  if      (unitNumber >= 185 && unitNumber <= 205)
    boardVersion = 40;
  else if (unitNumber >= 206 && unitNumber <= 307)
    boardVersion = 41;
  else if (unitNumber >= 308 && unitNumber <= 316)
    boardVersion = 50;
  else if (unitNumber >= 317 && unitNumber <= 367)
    boardVersion = 51;
  else if (unitNumber >= 368 && unitNumber <= 647)
    boardVersion = 52;
  else if (unitNumber >= 648 && unitNumber <= 1047)
    boardVersion = 53;
  else if (unitNumber >= 1048 && unitNumber <= 1058)
    boardVersion = 42;
  else if (unitNumber >= 1059 && unitNumber <= 1559)
    boardVersion = 43;
}

//add or subtract a specific region of bits in a variable************************************************************************************************************
byte bitRanger(byte CMD, byte Input, byte Limit) //Limit must contain the desired bitmask range
{
/*  isolate number range, save orginal
 *  add or sub isolated range
 *  range check and roll over
 *  replace range of orginal with rollover
 */
    
//isolate range from byte
  byte tempInput = 0;         //number range variable
  tempInput = Input & Limit;  //Bitwise AND to only keep data from the Limit bitmask area
  
  byte lsb = 7;                     //find beginning of Limit range
  for (byte i = 0; i < 7; i++)
  {  
    if (bitRead(Limit, i) == 0)     //find and remove LSB 0's from temp for simple math
      tempInput = tempInput >> 1;
      
    else                            //save value and exit
    {
      lsb = i;
      break;
    } 
  }
  
//command functions
  switch(CMD) 
  {
    case ADD:
            
      if (tempInput == Limit >> lsb) //Range end stop check
        tempInput = 0;
      else ++tempInput;
        
    break;
    case SUB:
    
      if (tempInput == 0)            //Range beginning stop check
        tempInput = Limit >> lsb;
      else --tempInput;
        
    break;
  }
  
//replace Limit range of Input with temp
  tempInput = tempInput << lsb;     //expand temp back to normal range
  Input = Input & ~Limit;           //clear Limit Range of Input for next step
  Input = Input | tempInput;        //combine new temp variable into Input

  return Input; 
}

//smart voltage engine for different circuits ************************************************************************************************************
byte voltPin(byte CMD, byte PIN)
{
  //pin lookup tables
  const byte pinArray51[] = {0, port1, port2, port4, mod4, mod5, 255};  //V5.1, 5.2, 5.3
  const byte pinArray50[] = {0, port1, port2, port4, mod4, 255};        //V5.0
  const byte pinArray40[] = {0, port1, port2, port3, 255};              //V4.0, 4.1, 4.3

  byte pinArray[8] = {0,0,0,0,0,0,0,0}; //main array to accept table
  byte arrayIndex = 0;

  //load table into main array
  switch(boardVersion) 
  {
    case 40: //drops down
    case 41:
    case 42:
    case 43:
      memcpy(pinArray, pinArray40, sizeof(pinArray40)); //destination, source, length
      break;
    case 50:
      memcpy(pinArray, pinArray50, sizeof(pinArray50)); //destination, source, length
      break;
    default:
      memcpy(pinArray, pinArray51, sizeof(pinArray51)); //destination, source, length
      break;
  }

  //locate current pin in array
  for (byte i = 0; i < 8; i++){
    if (PIN == pinArray[i]){
      arrayIndex = i;
      break;
    }
  }

  //command functions
  switch(CMD) 
  {
    case ADD:
   
      if (pinArray[arrayIndex + 1] != 255) //array end stop check
        PIN = pinArray[arrayIndex + 1];
        
    break;
    case SUB:
    
      if (arrayIndex > 0)                 //array beginning stop check
        PIN = pinArray[arrayIndex - 1];
        
    break;
    case PRINT:
    
      switch(PIN)
      {
        case 0:
          lcd.print(" Off");
        break;
        case port1:
          lcd.print("Port 1");
        break;
        case port2:
          lcd.print("Port 2");
        break;
        case port3:
          lcd.print("Port 3");
        break;
        case port4:
          lcd.print("Port 4");
        break;
        case mod2:
          lcd.print(" Mod 2");
        break;
        case mod4:
          lcd.print(" Mod 4");
        break; 
        case mod5:
          lcd.print(" Mod 5");
        break;
        default:
          lcd.print("Pin ");
          lcd.print(PIN);
        break;           
      }
      
    break;
  }

  return PIN; //this will be updated if add or sub is used
}

//get voltage from different circuits ************************************************************************************************************
float getVoltage(byte PIN) 
{
  #define REFVOLTS 3.328//3.291 //change this to your actual reference voltage
  #define ADCMAX 1023    //change this to the max ADC value

  float R1;
  float R2;
  bool diodeDrop = false; //compensates for input diode voltage drop
  bool rawInput = false; //skips voltage divider math, default input

  switch(boardVersion)
  {    
    case 40:
      switch(PIN) //V4
      {
        case port1:  //18.5v
          diodeDrop = true;
          R1 = 10000;
          R2 = 2200;
        break;
        case o2HeaterPin: //18.5v
          diodeDrop = true;
          R1 = 10000;
          R2 = 2200;
        break;
        default:
          rawInput = true;
        break;
      }
    break;
    case 41:
      switch(PIN) //V4.1
      {
        case port1:  //18.5v
          diodeDrop = true;
          R1 = 10000;
          R2 = 2200;
          break;
        case port2:  //5.5v
          R1 = 2200;
          R2 = 3300;
          break;
        case port3:  //5.5v
          R1 = 2200;
          R2 = 3300;
          break;
        case o2HeaterPin: //18.5v
          diodeDrop = true;
          R1 = 10000;
          R2 = 2200;
          break;
        default:
          rawInput = true;
          break;
      }
      break;
    case 42:
      switch(PIN) //V4.2
      {
        case port1:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case port2:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case port3:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case o2HeaterPin: //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case battSense:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        default:
          rawInput = true;
          break;
      }
      break;
    case 43:
      switch(PIN) //V4.3
      {
        case port1:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case port2:  //5.3v
          R1 = 10000;
          R2 = 16000;
          break;
        case port3:  //5.3v
          R1 = 10000;
          R2 = 16000;
          break;
        case o2HeaterPin: //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        case battSense:  //18.3v
          R1 = 10000;
          R2 = 2200;
          break;
        default:
          rawInput = true;
          break;
      }
      break;
    case 50:
      switch(PIN) //V5
      {
        case port1:    //18.8v, 3.3k / 1k
          R1 = 3300;
          R2 = 1000;
        break;
        case port2:    //5.6v, 3.3k / 4.7k & 3.6v Zener
          R1 = 3300;
          R2 = 4700;
        break;
        case o2HeaterPin: //18.3v, 10k / 2.2k
          R1 = 10000;
          R2 = 2200;
        break;
        case mod4:    //5.6v, 3.3k / 4.7k
          R1 = 3300;
          R2 = 4700;
        break;
        case battSense:  //18.3v, 10k / 2.2k
          R1 = 10000;
          R2 = 2200;
        break;
        default:
          rawInput = true;
        break;
      }
    break;
    default:
      switch(PIN) //V5.1, 5.2, 5.3      
      {
        case port1:    //18.8v, 3.3k / 1k
          R1 = 3300;
          R2 = 1000;
        break;
        case port2:    //5.6v, 3.3k / 4.7k & 3.6v Zener
          R1 = 3300;
          R2 = 4700;
        break;
        case o2HeaterPin:    //18.3v, 10k / 2.2k *v5.2+ is 1M / 220K & 22nf cap, same math
          R1 = 10000;
          R2 = 2200;
        break;
        case mod4:    //5.6v, 3.3k / 4.7k
          R1 = 3300;
          R2 = 4700;
        break;
        case mod5:    //5.6v, 3.3k / 4.7k
          R1 = 3300;
          R2 = 4700;
        break;
        case battSense:  //18.3v, 10k / 2.2k
          R1 = 10000;
          R2 = 2200;
        break;
        default:
          rawInput = true;
        break;
      }
    break;
  }
  
   float volts = analogRead(PIN);
   volts = (volts * REFVOLTS) / ADCMAX; // convert to pin voltage
   
   if (rawInput == false) 
    volts = volts / (R2 / (R1 + R2));   // convert to input voltage

   if (diodeDrop == true)
   {
    if (volts < 0.3)       //show clean 0 because of diode cut off
      volts = 0;
    else
      volts = volts + (0.07 * log(volts) + 0.42);// for diode drop
   }
   
   return volts;
}

//get resistance from different circuits **********************************************************************************************************
unsigned long getResistance(byte PIN)
{
  // V2 Calcs with R2 Protection Diode***************
  #define SERIESRESISTOR 4700
  float READ = analogRead(PIN);
  
  if (READ < 59)
    return 0;
  if (READ > 1009)
    return 9999999;
    
  READ = (READ * REFVOLTS) / ADCMAX;                                    //voltage convert
  READ = READ - ((0.00106 * pow(READ, 2)) - (0.071 * READ) + 0.287);    //Poly correction for protection Diode (+-0.5%)    
  READ = SERIESRESISTOR / ((REFVOLTS / READ) - 1);                      //ohm convert

  return READ;
  
  // V1
  /*float READ = analogRead(PIN);
  
  if (READ < 2) //short
    return 0;
  if (READ > 1021) //open
    return 9999999;
    
  float alogTemp; //float needed for division accuracy

  // convert the analog value to resistance
  alogTemp = 1023 / READ - 1;
  alogTemp = 4700 / alogTemp;
  
  return alogTemp;
  */
}

//auto i2c Reset if RTC gets stuck with data line low
void i2cLineUnsticker() {
  static byte i2cStop = 0; //attempt counter

  if (digitalRead(A4) == LOW && digitalRead(A5) == HIGH && i2cStop < 10){
    ++i2cStop;

    pinMode(A5, OUTPUT); //take manual control of line
    for (byte i2cCounter = 0; i2cCounter < 9; i2cCounter++){ //pulse 9 times
    //while (digitalRead(A4) == LOW){//stop when line is free
      digitalWrite(A5, LOW); //manually pulse line high and low for normal length
      delayMicroseconds(5);
      digitalWrite(A5, HIGH);
      delayMicroseconds(5);
    }

    Wire.begin(); //restart i2c to give control back
    clockBegin(); //restart AS1117 incase it got confused
  }
}
  
//gets data from MCP9700T-E/TT Analog Temp Probe ***********************************************************************************************************
float pcbTemp()
{
  float leTemp = analogRead(A12); //read in sensor
  leTemp = (leTemp * REFVOLTS * 100) / ADCMAX; //convert to mVolt, change analog max or ref voltage as needed, is /10 for less math later
  leTemp = leTemp - 50;           //convert to temp ºC, Ta = (Vout / Tc) - (V0 / Tc) where V0ºC = 500mV & Tc = 10mV/ºC
  leTemp = leTemp * 1.8 + 32;     //convert to ºF for us imperials
  return leTemp;                  //seems to be a farily noisy signal, so this needs to be averaged over atleast a few seconds
}
      
