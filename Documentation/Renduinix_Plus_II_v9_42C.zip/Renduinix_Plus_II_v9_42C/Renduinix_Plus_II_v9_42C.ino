/*
  Renduinix Plus for REM II + models (V5.0+ Hardware) and (V4.2+ Hardware) ONLY! Set Board Version define (Line 150) for correct pins!

  This was orginally complied on Arduino IDE 2.0.3 and used 167,052 bytes PS, 8,616 bytes DM
  
  UPLOAD SETTINGS:
  
    Double Check the correct pinout definitions are uncommented below
    
  - Tools > Board: > Teensy 3.2
  - Tools > CPU Speed > 96MHz   (for v4.1+ users, could even push to 120MHz I think but not tested)
  - Tools > CPU Speed > 48MHz   (for v4 users, 48MHz for compatibility with tcu baud rate when not used on Serial3, oops)
  - Tools > Port > Teensy
  - Tools > Programmer: > AVRISP mkII

  Requires RTClib Library from adafruit to be installed to compile.
  - Sketch > Include Library > Add .ZIP Library...
  - Gonna need more Adafruit Libraries for Gyroscope compatibilty, links below 

  Links:
   - REM II V4 Update Video: https://www.youtube.com/watch?v=sjbltaFosbQ
   - PJRC Teensyduino IDE add-on: https://www.pjrc.com/teensy/td_download.html
   - PJRC TeensyLoader for Hex uploads: https://www.pjrc.com/teensy/loader.html
   - RTClib.h Download: https://github.com/adafruit/RTClib
   - FXOS8700.h Download: https://github.com/adafruit/Adafruit_FXOS8700
   - FXAS21002C.h Download: https://github.com/adafruit/Adafruit_FXAS21002C
   - Sensor.h Download: https://github.com/adafruit/Adafruit_Sensor
   
   - Mac FTDI Drivers?: https://learn.sparkfun.com/tutorials/how-to-install-ftdi-drivers/mac
   
**********************************************************************************************************************

  
  This code is formated for the open source Renix Engine Monitor but can be built on a breadboard.
  This sketch will read a 1986 to 1990 Jeep Renix 2.5L or 4.0L ECU's TX output, convert the string into useable measurements,
  and display them on a 16x2 LCD display allowing you to cylce through with buttons.

  Renduinx Plus allows the Renix Engine Monitor to read the AW-4 TCU Serial Stream as well with a
  1k pull-up resistor to 5v. The TCU does all of the other work for creating the logic level.
  
  The circuit:
   A PJRC Teensy 3.2 is connected to a 16x2 RGB LCD Screen and 5 buttons to provide the base scanner. 

    Components needed for ECU communication:
     just about any NPN Transisitor (I'm using a 2N3904)
     a 1k and 3.3k Resistor (1k isn't even nessisary with onboard pullup)
     some wire and maybe a breadboard

   The Renix Diagnostic Connector has 2 ports, D2 is the larger one. D2 Pins are numbered
   Bottom to Top, Left to Right if D1 is to the Left of D2

     D1      D2
    |4 1|   <3 6 9 12 15|
    |5 2)   <2 5 8 11 14|
    |6 3|   <1 4 7 10 13|

    Pin D2-1 is the ECU TX output, it is open collector to ground
    Pin D2-3 is the ECU TX Positve bias thing? (2.5L M/T ONLY) Connect to ground for complete signal 
    Pin D2-4 is Ignition Postive (+)
    Pin D2-7 is Ignition Ground  (-)
    Pin D2-15 is TCU TX output

   We will use an NPN transistor to physically NOT (invert) the data and use some resistors to get the switching done
   On 2.5L a resistor divider will be required to get the NPN to switch since it doesn't use a true zero voltage

    Arduino VIN pin ->  Pin D2-4 Ign Pos(+) (Arduino Uno is good to 20v, Adafruit to 16v, Teensy only 6V so EXTERNAL needed)
    Arduino 5V pin  ->  3.3k resistor -> NPN Base      <- Pin D2-1 ECU TX     (This is the ECU Input)
    Arduino 5V pin  ->  1k resistor   -> NPN Collector <- Arduino RX Pin 0    (This is the Output to Arduino)
    Arduino Gnd pin ->                   NPN Emitter   <- Pin D2-7 Ign Gnd(-) (Negitive Rail)
    Arduino 5v pin  ->  1k resistor   -> Arduino RX2   <- Pin D2-15 TCU TX    (TCU Input)

  Orginal Core Code
  RenixComm V 0.3
  First incarnation January 7th, 2012
  This revision Jan 17th, 2012 (Subrevision 24)
  Phil Andrews 2011, 2012
  Thanks to Kes for help with the code

  Additional Code
  Renduinix v9.31
  Created July 13th, 2016 (v0.1)
  by Nick Risley, NickInTimeDesign
  Modified Jul 12th, 2022

  Update Log:
  v0.1 Modified core code to display predetermined outputs on a 16x2 display
  v0.2 Interfaced buttons to cycle through a sensor array
  v0.3 Updated calculations to show proper, added more data points, and debounced button presses
  v0.4 Cleaned up formating, custom character, updated text data points, added permanent memory function
  v0.5 Update pins for Trinket Pro, fixed RPM calc, added custom backlight options, fixed freeze if no data was present
  v0.6 Migrated code to Switch Case, Revamped Menu System, improved stream acquisition, added settings and debug, unified gauge spacing, added custom Baud and PROG# Option
  v0.7 Added EEPROM presets and reset, revamped vehicle selection, released Alpha Models
     -0.71 Fixed Color and Software Info Menus
     -0.72 Fixed Vehicle Selection Menu, added basic CEL function
     -0.73 Added RPM Error Check
     -0.74 Rewrote gauge delay to improve buttons, maxed Green and Cyan intensity, updated button delays, added Throttle Switch & Data Check gauge
     -0.75 Added TPS and Knock Error Check, updated Vehicle Screen, added more CEL Options, made data check more useful, added unit conversions, fixed switch analog pin reference, added cel notification, reactivated Custom Program option
     -0.76 Updated Data Gauge, Added correct RPM check, CEL tweaking, Added adv TPS and loop option, Added Vac Gauge, Filled out Diagnostic Menu, condensed bulky variables, unified data acquisition code
        -0.761 Quick fix, Commented out Custom Program Menu for a bit more free ram to allieviate crashes
     -0.77 Updated Settings Text and Diagnose Menu Units, added diagnostic CEL, tweaked CEL, added Beta hardware support, updated button debouncing, added serial average modifier for speed, freed most text from RAM
     -0.78 tweaked CEL, fixed TPS skip issue, robust 255 data handling, tweaked auto birghtness, added min/max feature, added auto brightness menu
        -0.781 removed Bar Pressure and replaced it with Voltage, slightly updated gauge math
        -0.782 added screen auto re-sync and home button screen reset
     -0.79 added flag to lcd.clear commands, removed stream averaging, updated diagnostic menu, added injector ducty cycle
       
       -0.79+ adds basic TCU Support, used const byte, trimmed total bytes, commented out the fat, added speed unit
       -0.791+ added seperate time var for auto sync, adjuted tcu screen updating, updated Duty Cycle formatting, updated splash screen
       -0.792+ increased null button range, added seperate tcu time variable, fixed gauges updating for auto resync and buttons, increased tcu array to fix final byte issues, tuned CELs
  v0.8 Seprated data and cel to tab, Simultaneous data reading, added gph and mpg, EEprom float values, added 0-60 timer, added cel delay, fixed Baro calc, added vehicle menu and trans variable, selective (F) macros saved 600b ram, adjusted button range, rewrote button debouncing code
       -0.801+ Updated TCU Array timing to prevent accidental early reading, updated GPH reading, added 0-60 restart, rolled back ECU search code to old method, removed LockUp byte
      
       -0.802+V3 Added other pin variables, Added RTC Stuff, added time to home screen & guages, moved Trans options to Vehicle, condensed duplicate variables, Removed Wait Screen, InjDC to float, 0-60 reset fix, Clock Menu, fixed MAPRaw TireSize and SpeedCorr float dependencies, removed resync screen
     -0.81+V3 Fixed Vehicle # display issue, 0to60 buttons & formatting, changed transType tempUnit speedUnit tpsUnit loopMode splashScreen lambdacounter tcuReadFlag & updateScreen to Boolean, added TCU Errors, readlcdbuttons & rgb values to byte, TCU screen throttling for read speed, moved clock gauge for speed
       -0.811+V3 Fixed M/T GPH issue, updated TCU Error Scrolling, added gauge # variables and porting notes, Updated KPH calc, added LPH and LHK conversion, fixed double 12am issue, setCursor cleaning, autoDim menu tweak
       -0.812+V3 updated reset values, 0-60 tweak, added ECU detection
     
     -0.82+V4 Updated pins to V4 Spec, Added 2.5L support, fixed dim menu spacing, re-calibrated VHT, fixed date spacing, gyro gauges, cleaned up get_gata, adjusted color values, wrote gauge skip function, EGR gauge, added Gauges tab, updated rpm math, updated ECU detection, gyro and BT options, button filtering, CEL dimming
     -0.83+V4 Updated TCU Screen formatting, added Out Support, fixed TCU read bugs, loop time efficiency improvements, rewrote display refresh throttling routine, fixed 0-60 timer, removed wait menu, added advanced menu
       -0.831+V4 Removed extra readlcdbuttons, added time throttling to button reads, fixed vehicle and Unit menu saving issues, updated Diagnose I/O screen
       -0.832+V4 Updated Bluetooth Protocol, Updated 2.5L ECU Detection
       
     -0.84+V4.1 Added AC Fan Triggering, added SYN Spinning Animation, added Clock IC Commands, added i2c SDA reset
     -0.85+V4.1 Fixed ECU stream not fully reading in, added usb serial output, added Settings subpage, i2c reset runs in loop, Clock updates with minute & hour change, revamped Time display, revamped fan control, added usb upload reboot option, rtc poll throttling, clock auto dimming, option to seperate gph & mpg. auto dim averaging, proper roll/tilt gauge with offset options and averaging
        -0.851+V4.1 Reorganized i2c startup, added rtc begin back, added i2c multiple attempt kill
     -0.86+V4.1 Fixed Gyro no-start on clocks, condensed tcuStreamUpdate, added fuel and distance tracking, added avgMPG, throttled ecu calcs for faster loop, fixed unit number display, added more USB Output modes, refined EGR AC Throttle Sw & Loop output, refined fsync animation, vht adjustment, added fuel tracking & diagnose page, updated time formatting, updated update speed, added unit conversion functions, updated GPH for 2.5L, added avgGPH, added engine Run Time and Run Flag, updated CEL, added Serial defines & updated fan pin display for porting  
     -0.87+V4.1 added LCD formatting functions, fan menu functions, fixed fan pin control, added 2 speed fan option, fixed 2.5L stream length, added BT Speeds, added shift light, diagnose graphing, updated vht reading, added tank mpg tracking, added fuel tank size option, updated vht cel, added fiil-up menu, added wideband AFR gauge, wideband diag menu, wideband to narrowband output, added tankAVG gauge option, temp symb function, NSS gauge, added clock brownout dim
     -0.88+V4.1 fixed NSS based fuel saving, AFR 1 dec, fill-up menu fixes, Wideband defaults to Lean, Seperate 4.0L/2.5L calcs, Fixed EGR, switched calcs to bitRead, updated TCU stream, Functions Tab, cleaned up Get_Data, updated TCU error display, updated Gear gauge, updated Mystery Bytes, Digital Bytes display as bit symbols, added User Fuel Cal option, added trip ECU CEL Error memory, Diagnose menu updated, 2.5L PS Sw Gauge added, CEL runs on all screens, tidier createChar code, easier porting defines
     -0.89+V5 Updated pins, added unknowns to tcu error, added pcb temp func, converted to volt grab function, pin selection functions, capped auto dim, updated wideband tuning, updated RTC stuff, updated some eeprom reset values
  -9.00+V5 Revamped ECU data parsing, SD data logging test code, fixed MAP diagnose page, added Sensor Readings and Sensor Tests Menu, added wideband closed loop helper, usb passthrough mode no longer emulated, added ABS support, additional readings in readings menu, fixed spark retard zeroing, unified button check func, rpm rounding and fuel trim zero options, signal out test menu, CEL Routine Overhaul, CEL History, Fixed Fan A/C trigger issue, restructured options menus, proper button repeating, combo A/C gauge, removed combo loop gauge, 
          added menu back option, basic DMM support, removed nss from gauge screen
     -9.10+V5 added IAC gauge and reading, Rich/Lean from o2 directly now, fixed dizzy gauge incorrectly spinning, updated A/C gauge, added button state tracking code, hold button to go back 1 gauge, updated gaugeSkip function, estimated AFR gauge from stock o2, added more to ECU Readings list
        -9.11+V5 fixed i2c boot crash, fixed KPH conversion, fixed 2.5L Vac reading, added volt readings to 2.5L page
        -9.12+V5 fixed 2.5L TPS Text, readings page menu resets, revampped TCU datastream parsing code, fixed ecu RAW usb option, shows vehicle screen on initial boot now, hold button on boot to force home screen
        -9.13+V5 fixed LHK calculation
        -9.14+V5 revamped voltage pin selection funciton, fixed wideband pin resetting, added board version checker
        -9.15+V5 seperated wideband to own menu list, added more wideband settings, wideband loop helper works for lean too, AFR adjust btn repeats now, AFR added to USB RAW output
        -9.16+V5 added 3rd Wideband AFR profile, new bit range math func, wideband settings tweaks
     -9.20+V5 added no start page, fixed CEL disable bug, fixed Heater CEL with Wideband Conversion, added 5.38 gear ratio, fixed IACgauge showing on 2.5L, updated listing functions, added Master CEL menu, updated 4.0L ECU Codes, incorrect datastreams disabled in readings menu, restructured tests menu, Wideband Closed loop helper adjustment
        -9.20C+V5 added V4.2 Clock Pinouts, Enabled Clock Display funcs, updated clock dim screen, added clock boot animation   
     -9.30+V5 improved dim func for better low light range, rgb backlight func, vehicle menu btnRepeats added, dataOrder Out of Bounds checker, fixed trans info gauge never showing, Manual trans MPH hack added
        -9.31+V5 Fixed AEM Wideband Profile not showing HEAT
        -9.32+V5 Added V4.2 and V4.3 pin definitions to voltage functions, added dummy function to force IDE to add dataOrder prototypes above globals, updated V4 port pins, added support for custom 100PSI sensor, ST and LT + sign for zeroed mode, Fuel Tracking function refactoring
     -9.40+V5 Updated to new Adafruit AHRS library imports(TODO: GYRO ISSUES), refactored rtcTime start code, increased sync code CEL trigger time, RTC date and time display func cleanup, basic rtc time drift correction, moved Codes Menu to home screen, fixed clock boot animation if display set to off, max lcd brightness reduced for longevity, rgb function refactored, lcd dim menu reworked for single threshold value, RGB values shown in 100 scale, time menu layout restructure, fancy board compile defines added, i2c unsticker functioned   
        -9.41+V5 Fixed Gyro Library imports to use included legacy libraries
        -9.42+V5 Added Innovate Wideband profile, button code adjustment, spelling fixes, tps test screen hundred scale 

     todo: 6 gauges, accelerometer, sd logging, gauge sensor graphing, variable auto dim, target mode fan control, clock display gauge, 1/4 mile
     update v5 clock stuff, update new pins and math, New TCU data tracking doesn't work for V4.0 boards
     gyro auto calibrate, update averaging technique, DMM functions, unify time keeping, revamp fuel consumption tracking   
*/
const float softwareVersion = 9.42;
#define COMPILE_VERSION 50 //decimal in 1's place, use lowest common value: 40, 41, (42)-43, (50)-53

#include <EEPROM.h> //included for EEPROM memory functions
#include <LiquidCrystal.h> //included to interface with the LCD

//SD Card Stuff
#include <SD.h>
#include <SPI.h>

//RTC clock stuff
#include <Wire.h>
//#include "RTClib.h"  //REM V4 and previous
//RTC_DS3231 rtc;//sets RTC chip type
#include <TimeLib.h> //REM V5
boolean show12Hours = true;
boolean homeScreen = false;//for clock option
byte timeSetOrder = 1;
byte timeMenuOrder = 1;

//Gyro/Mag Stuff
//NOTE: must include these libraries in the root folder for use, new libraries break this code
#include "Adafruit_Sensor.h"
#include "Adafruit_FXAS21002C.h"
#include "Adafruit_FXOS8700.h"
#include "Mahony.h"
#include "Madgwick.h"
// Mahony is lighter weight as a filter and should be used
// on slower systems
Mahony filter;
//Madgwick filter;
/* Assign a unique ID to this sensor at the same time */
Adafruit_FXAS21002C gyro = Adafruit_FXAS21002C(0x0021002C);
Adafruit_FXOS8700 accelmag = Adafruit_FXOS8700(0x8700A, 0x8700B);

byte celDim = 10; //0 = off, 255 = max, controls CEL Brightness

#if COMPILE_VERSION == 50
//V5 Pins
                //RS, E, 4, 5, 6, 7
LiquidCrystal lcd(28, 27, 29, 30, 14, 8);
byte boardVersion = 51;
//const byte ECUpin = 0; //RX1
const byte TCUpin   = 7; //RX3
#define tcuSerialPort Serial3 //placeholder to select proper port
#define btSerialPort Serial2
const byte sdCSPin  = 2;
//LCD RGB Backlight Pins, uses PWM
const byte celPin   = 5; //Check Engine Light
const byte redPin   = 32;
const byte greenPin = 25;
const byte bluePin  = 6;
//Analog Pins
const int lightSensorPin = A1;
const int buttonsPin  = A13;
const int o2HeaterPin = A7;
const byte battSense  = A2;
//In/Out Pins
const byte port1  = A8;
const byte port2  = A9;
const byte port3  = A6;
const byte port4  = A7;
const byte mod2   = 24;
const byte mod4   = A3;
const byte mod5   = A20;

const byte tcuLowGap = 60; //since clock speed effects timing for some reason
const byte tcuHighGap = 85;

#elif COMPILE_VERSION == 42
//V4.2C & V4.3 Pins
               //RS, E, 4, 5, 6, 7
LiquidCrystal lcd(1, 2, 3, 4, 5, 6);
byte boardVersion = 43; //detected through unit number now
//const byte ECUpin = 0; //RX1
const byte TCUpin = 7; //RX3
#define tcuSerialPort Serial3 //placeholder to select proper port
#define btSerialPort Serial2
const byte celPin = A9; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = A8;
const byte greenPin = A7;
const byte bluePin = A6;
//Analog Pins
const int lightSensorPin = A11;
const int buttonsPin = A10;
const int o2HeaterPin = A14;
//In/Out Pins
const byte port1 = A3; //changing pins will work, but lcdprint will be wrong
const byte port2 = A2;
const byte port3 = A1;

const byte port4  = 29;//filler
const byte mod2   = 30;//filler
const byte mod4   = 31;//filler
const byte mod5   = 32;//filler
const byte battSense  = A0;

const byte tcuLowGap = 60; //since clock speed effects timing for some reason
const byte tcuHighGap = 85;


#elif COMPILE_VERSION == 41
//V4.1 Pins
               //RS, E, 4, 5, 6, 7
LiquidCrystal lcd(1, 2, 3, 4, 5, 6);
byte boardVersion = 41; //detected through unit number now
//const byte ECUpin = 0; //RX1
const byte TCUpin = 7; //RX3
#define tcuSerialPort Serial3 //placeholder to select proper port
#define btSerialPort Serial2
const byte celPin = A9; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = A8;
const byte greenPin = A7;
const byte bluePin = A6;
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A10;
const int o2HeaterPin = A11;
//In/Out Pins
const byte port1 = A1; //changing pins will work, but lcdprint will be wrong
const byte port2 = A2;
const byte port3 = A3;

const byte port4  = 29;//filler
const byte mod2   = 30;
const byte mod4   = 31;
const byte mod5   = 32;
const byte battSense  = 33;

const byte tcuLowGap = 60; //since clock speed effects timing for some reason
const byte tcuHighGap = 85;

#elif COMPILE_VERSION == 40
//V4 Pins
                //RS, E, 4, 5, 6, 7
LiquidCrystal lcd(1, 2, 3, 4, 5, 6);
byte boardVersion = 40;
//const byte ECUpin = 0; //RX1
const byte TCUpin = 9; //RX2
#define tcuSerialPort Serial2 //placeholder to select proper port
#define btSerialPort Serial3
const byte celPin = A9; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = A8;
const byte greenPin = A7;
const byte bluePin = A6;
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A1;
const int o2HeaterPin = A2;
//In/Out Pins
const byte port1 = A3;//A11 orginally, both are analog only, whoops
const byte port2 = A10;//A10 orginally, use 10-12 if not using sd card for more functions
const byte port3 = A11;//changing pins will work, but lcdprint will be wrong

const byte port4  = 29;//filler
const byte mod2   = 30;
const byte mod4   = 31;
const byte mod5   = 32;
const byte battSense  = 33;

const byte tcuLowGap = 100; //since clock speed effects timing for some reason, (109? or 0?)
const byte tcuHighGap = 130; //140 read

#endif
/*
//V3 Pins
                //RS, E, 4, 5, 6, 7
LiquidCrystal lcd(4, 5, 6, 7, 8, 12);
const byte boardVersion = 30;
const byte TCUpin = 2;
const byte celpin = 3; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = 11;
const byte greenPin = 10;
const byte bluePin = 9;
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A1;
const int o2HeaterPin = A2;*/
/*
// V1 & V2 Pins
                //RS,  E, 4, 5, 6, 7
LiquidCrystal lcd(12, A0, 8, 6, 5, 4);
const byte boardVersion = 20;
const int TCUpin = A3;
const byte celpin = 3; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = 9;
const byte greenPin = 10;
const byte bluePin = 11;
//Analog Pins
const int lightSensorPin = A4;
const int buttonsPin = A1;
const int o2HeaterPin = A2;
*/

//values for buttons
byte lcdKey  = 0;
byte btnPrev = 0;
bool btnRepeatFlag = false;
bool btnHoldFlag = false;

const byte btnNone = 0;
const byte btnHome = 1;
const byte btnBottomRight = 2;
const byte btnBottomLeft = 3;
const byte btnTopRight = 4;
const byte btnTopLeft = 5;
//different button states
const byte btnOFF     = 0;
const byte btnPRESS   = 1;
const byte btnHOLD    = 2;
const byte btnREPEAT  = 3; //single trigger
const byte btnRELEASE = 4; //mulitple trigger, --btnState to continue
const byte btnUSED    = 5; //set to used after completed task
byte btnState = btnOFF; //start in the off state
byte prevKey = 0;

//Custom character setup for LCD
/*byte leftArrow[8] =//lcd1
{
  B00010,
  B00100,
  B01000,
  B11111,
  B01000,
  B00100,
  B00010
};
byte rightArrow[8] =//lcd2
{
  B01000,
  B00100,
  B00010,
  B11111,
  B00010,
  B00100,
  B01000
};
*/
byte fahrenheitSymbol[8] =
{
  B11000,
  B11000,
  B01111,
  B01000,
  B01110,
  B01000,
  B01000
};
byte celsiusSymbol[8] =
{
  B11000,
  B11000,
  B00110,
  B01001,
  B01000,
  B01001,
  B00110
};
byte dizzy1[8] =//spinny1 
{
  B01110,
  B10101,
  B10101,
  B10101,
  B10001,
  B10001,
  B01110
};
byte dizzy2[8] =//spinny2
{
  B01110,
  B10011,
  B10011,
  B10101,
  B10001,
  B10001,
  B01110
};
byte dizzy3[8] =//spinny3
{
  B01110,
  B10001,
  B10001,
  B10111,
  B10001,
  B10001,
  B01110
};
byte dizzy4[8] =//spinny4
{
  B01110,
  B10001,
  B10001,
  B10101,
  B10011,
  B10011,
  B01110
};
byte dizzy5[8] =//spinny5
{
  B01110,
  B10001,
  B10001,
  B10101,
  B10101,
  B10101,
  B01110
};
byte dizzy6[8] =//spinny6
{
  B01110,
  B10001,
  B10001,
  B10101,
  B11001,
  B11001,
  B01110
};
byte dizzy7[8] =//spinny7
{
  B01110,
  B10001,
  B10001,
  B11101,
  B10001,
  B10001,
  B01110
};
byte dizzy8[8] =//spinny8
{
  B01110,
  B11001,
  B11001,
  B10101,
  B10001,
  B10001,
  B01110
};

//Program Runtime variables, used to slow down gauge screen without delays and other timing
//unsigned long currentTime = 0;
unsigned long prevTime = 0;
unsigned long resyncPrevTime = 0;
unsigned long btPrev = 0;

// Serial registers etc
byte dataStream[31];  // 32 bytes. we only have 1024 to play with. 31 for data, 1 for sign apart from it doesn't use the sign. bah.
bool dataStreamCounter = false;// used to check for double 255's
byte bluetoothStream[16];
bool ecuStreamUpdate;

// Serial data variables
//byte ProgramVersion = 0;
//byte PROMversion = 0;
//byte CalibrationCode = 0;
//unsigned long PROM = 0;
byte MAPRaw = 0;
float MAP = 0; 
float MAPMin = 0;
float MAPMax = 0;
float Vacuum = 0;
byte CTSRaw = 0;
int CTS = 0;
int CTSMin = 0;
int CTSMax = 0;
int IAT = 0;
int IATMin = 0;
int IATMax = 0;
byte IATRaw = 0;
float Volts = 0;
float VoltsMin = 0;
float VoltsMax = 0;
float BatterySense = 0;
float Lambda = 0;
float LambdaMin = 0;
float LambdaMax = 0;
float LambdaPrev = 0;
bool LambdaCounter = false; // true = millis set
unsigned long LambdaPrevTime = 0;
float LambdaHeater = 0;
unsigned int RPM = 0;
unsigned int RPMMin = 0;
unsigned int RPMMax = 0;
//byte PROM9_10 = 0;
//byte PROM7_8 = 0;
byte TPS = 0;
byte TPSMin = 0;
byte TPSMax = 0;
byte SparkADV = 0;
//byte Unknown14 = 0;
byte SparkRTD = 0;
byte BaroRaw = 0;
float Baro = 0;
//byte Unknown17 = 0;
byte LoopStatus = 0;
byte Exhaust = 0;
bool EGR;
float InjPulse = 0;
//byte Unknown20 = 0;
byte ThrottleSwitch;
bool FuelSync = 0;
//byte Unknown22 = 0;
//byte Unknown23 = 0;
byte STFuel = 0;
byte STFuelMin = 0;
byte STFuelMax = 0;
//byte Unknown25 = 0;
byte LTFuel = 0;
byte Knock = 0;
byte KnockMin = 0;
byte KnockMax = 0;
//byte Unknown28 = 0;
bool ACSwitch = 0;
bool ACRequest = 0;
bool ACClutch = 0;
bool NSS = 0;      
bool PSSwitch = 0; //2.5L
bool Starter = 0;
bool EngineRun = 0;
byte IAC = 0;
bool IACdir = false; //true open, false closed
int IACcount = 1280;
float estAFR = 0;
//byte PROM11_12 = 0;
byte mystery1; //bits           /Zero?
int mystery2;  //cts offset     /slow increase
byte mystery3; //bits           /bits
byte mystery4; //zero?          /Zero?
byte mystery5; //IGN Knock      /Zero?
float mystery6;//warmup offset  /small offset
int mystery7;  //iat offset     /ISM idle offset
byte mystery8; //zero or 128    /RPM offset?
int mystery9; //                /IAT offset?
byte mystery10;//               /128

float InjDuty = 0;
float GPH = 0;
int engineRPM = 0; //display value, may be trunication
int STFT = 0; //display value, may be zeroed
int LTFT = 0; //display value, may be zeroed

//For Exhaust
const byte Lean = false;
const byte Rich = true;
 
//For loop status
const byte Clsd = true;
const byte Open = false;
const byte Dcel = 2;

//For throttle switch
//const byte Clsd = true; //declared above
const byte WOT = false;
const byte Part = 2;

//For IAC
unsigned long IACtimer;

//ABS
float LFWheel = 0;
float RFWheel = 0;
float LRWheel = 0;
float RRWheel = 0;
byte LFSolenoid = 0;
byte RFSolenoid = 0;
byte RearSolenoid = 0;
bool GSwitch = false;
bool DiffPressure = false;
bool BoostPressure = false;
bool LowAccum = false;
bool ABSPump = false;
bool ModulatorRelay = false;
bool SolenoidUndervolt = false;
bool ParkingBrakeFluidLow = false;
bool ABSBrake = false;

//Settings Variables
byte engine = 4;
byte settingsOrder = 1;//1 indexed to allow use of byte
//byte settingsTotal = 5; //Speed, CEL, Splash, Reset, info
//boolean splashScreen = true; //true on, false off
byte updateSpeedMenu = 3; //1 slow, 2 med, 3 fast, 4 ludi
byte updateSpeed = 25;
const byte slow = 120; //Gauge Update Speeds in milliseconds/10 (must be less than 256)
const byte med = 65;
const byte fast = 25;
const byte ludi = 12;
//byte debugStreamOrder = 1;//sets debug stream "page" #
byte cel = 1; //1 CEL Disabled, 2 CEL Faliure, 3 CEL Warning
byte celGauge = 0; //placeholder for gauge # requesting CEL
byte unitOrder = 1;
//byte unitTotal = 4; //Pressure, Temp, TPS, Loop
byte pressureUnit = 2; //1 bar, 2 "Hg, 3 kPa, 4 psi 
boolean tempUnit = true; //false celsius, true farenheit
boolean speedUnit = true; //false kmh, true mph
boolean mpgMode = true; //false combo, true normal
boolean tpsMode = true; //false advanced, true normal
//boolean loopMode = true; //false combo, true normal
byte diagnoseMenu = 1;//1 indexed to allow byte
//byte diagnoseTotal = 10;
byte diagnoseMode = 0; //Switches Screen Info
byte diagnoseMinMax = 0; //0 = off, 1 = on
boolean MinMaxReset = false; //false = off, true = on, initially set to on to record an actual number
byte MinMaxCheck = 0; //0 = not triggered, 1 = counting, 2 = triggered
unsigned long MinMaxCheckTime = 0;
byte advSettingsOrder = 1;

byte dataOrder1 = 6; //Top Left counter, 0 indexed, used byte so that EEPROM can use it
byte dataOrder2 = 5; //Top Right counter, 0 indexed
byte dataOrder3 = 11;//Bottom Left counter, 0 indexed
byte dataOrder4 = 4; //Bottom Right counter, 0 indexed

//Menu Counter used to cycle through menues
byte menuOrder = 1; //Sets to Waiting screen initially
byte vehicleOrder = 1;
byte menuPrev = 255; //prevents multiple lcd clears
//const byte menuDelay = 40; //delay used on menus to reduce screen flicker, and help buttons register
byte updateScreen = 1;

//Assign variables to menus for easy reference
const byte Home = 0;
const byte Waiting = 1; 
const byte Vehicle = 2;
const byte Gauges = 3;
const byte Diagnose = 4;
const byte Options = 5;
const byte Units = 6;
const byte PickColor = 7;
const byte Backlight = 8;
const byte CustomColor = 9;
const byte RGBCustomSave = 10;
const byte DisplayMenu = 11;
const byte Settings = 12;
//const byte VehicleCustom = 13;
//const byte ProgramNumberMenu = 15;
const byte AutoBrightness = 16;
const byte AutoResyncScreen = 17;
const byte TCUGauges = 18; //screen page variable
const byte TimeMenu = 19;
const byte TCUErrors = 20;
const byte InOutMenu = 21;
const byte AdvancedMenu = 22;
const byte MoreMenu = 23;
const byte clockDimMenu = 24;
const byte GyroCalibrateMenu = 25;
const byte AFRmenu = 26;
const byte FillUpMenu = 27;
const byte ECUErrors = 28;
const byte SensorList = 29;
const byte SensorTestMenu = 30;
const byte DiagnoseMenu = 31;
const byte DMMmenu      = 32;
const byte SettingsMenu = 33;
const byte WidebandMenu = 34;
const byte NoStartMenu = 35;
const byte CELMenu = 36;
const byte timeDriftMenu = 37;

//TCU stuff
//#include <SoftwareSerial.h>
//SoftwareSerial tcuSerial(TCUpin, A7); //RX, TX

byte serialBeginFlag = 1; //0 = off, 1 = on
unsigned int byteGap = 0;
bool tcuReadFlag = false; //false = Search, true = Read
bool tcuDataGood = false; //true if succesful streams are being read
unsigned long tcuPrevTime = 0; // tcu time variable for measuring byte length
int tcuCursor = 0; //cursor variable
byte tcuCursorMove = 0; //modifier for scrolling
unsigned long tcuFaultTime;//fault display timer
byte tcuFaultCounter;
bool tcuStreamUpdate;
bool tcuDebug = false; //serial debug stuff
bool tcuOutput = false; //serial datastream output test

byte tcuDataStream[7]; //7 bytes,0 indexed, extra spot for stability

byte tcuTPS;
int tcuRPM;
byte tcuPRNDL;
bool tcuBrake;
bool tcuMode;
bool solenoid1;
bool solenoid2;
bool solenoid3;
bool tcuShiftLogic;
bool tcuMystery;
byte tcuGear;
byte SolenoidFaults;
byte TPSFaults;

float MPH;
float MPG = 0;

boolean transType = 0; //0 = M/T, 1 = A/T, 
byte tcuMenu = 0;
byte TireSize = 29;
float GearRatio = 3.55;
byte GearRatioCounter = 2;
byte SpeedCorr = 100;

float launchTime = 0;
float startTime = 0;
float endTime = 0;
float Best060Time = 99.99;
byte armedFlag = 0;

//Jiggy-Ninja of Arduino Forum: https://forum.arduino.cc/t/array-of-functions/429541/11
//The IDE inserts the prototypes immediately before the first function definition in the .ino file.
//This will make the IDE put the prototypes above this function, so they’ll be above the globals.
void dummy(){} //This fixes the GaugeFunction dataArray from needing all the function prototypes manually typed here :)

//callback pointer stuff for displaying each sensor string
typedef void (*GaugeFunction) ();

//V4 Data Array connected to callback pointer
GaugeFunction dataArray[] = {displayOutputs, displayGyro, displayTime, displayMAP, displayVacuum, displayCTS, displayIAT, displayRPM, displayVolts, displayLambda, displayExhaust, displayAFR, displayLambdaHeater, displayLoopStatus, displayFPR, displayEGR, displayIAC, displayTPS, displayThrottleSwitch, displaySparkADV, displayKnock, displayInjPulse, displayInjDuty, displayFuelSync, displaySTFuel, displayLTFuel, displayACStatus, displayGPH, displayMPG, displayAVG, displayMPH, displayGear, displayTransInfo};
//void (*dataArray[])(void) = {displayOutputs, displayGyro, displayTime, displayMAP, displayVacuum, displayCTS, displayIAT, displayRPM, displayVolts, displayLambda, displayExhaust, displayAFR, displayLambdaHeater, displayLoopStatus, displayEGR, displayIAC, displayTPS, displayThrottleSwitch, displaySparkADV, displayKnock, displayInjPulse, displayInjDuty, displayFuelSync, displaySTFuel, displayLTFuel, displayACStatus, displayGPH, displayMPG, displayAVG, displayMPH, displayGear, displayTransInfo};

//displayAccel, displayMag,

const byte dataTotal = 33; //number of data points in above array, 1 indexed so add 1 to largest number ;)
const byte outputsGauge =   0;
const byte gyroGauge =      1;
//const byte accelGauge =     2;
//const byte magGauge =       3;
const byte timeGauge =      2;
const byte MAPGauge =       3;
const byte VACGauge =       4;
const byte CTSGauge =       5;
const byte IATGauge =       6;
const byte RPMGauge =       7;
const byte voltGauge =      8;
const byte lambdaGauge =    9;
const byte exhaustGauge =   10;
const byte afrGauge =       11;
const byte heaterGauge =    12;//4.0 only
const byte loopGauge =      13;
const byte FPRGauge =       14;
const byte egrGauge =       15;
const byte IACGauge =       16;
const byte TPSGauge =       17;
const byte throttleGauge =  18;
const byte ADVGauge =       19;
const byte knockGauge =     20;//4.0 only
const byte injGauge =       21;
const byte IDCGauge =       22;
const byte fsyncGauge =     23;//4.0 only
const byte STFGauge =       24;
const byte LTFGauge =       25;
const byte ACSGauge =       26;
//const byte ACRGauge =       25;
//const byte ACCGauge =       26;//2.5 only
//const byte NSSGauge =       25;//A/T only?
const byte GPHGauge =       27;
const byte MPGGauge =       28;
const byte AVGGauge =       29;
const byte MPHGauge =       30;
const byte gearGauge =      31;
const byte transGauge =     32;
const byte nullGauge =     255;

//current LED values to be multiplied by dim value
byte redValue = 0; //int to prevent looping
byte greenValue = 128;
byte blueValue = 0;

//diming variable to affect final output of RGB Variables
byte RGBDim = 100; //100 = Max and 0 = Off
byte RGBDimOrder = 4; //1 = Off, 2 = Low, 3 = Med, 4 = High, 5 = Auto
//byte RGBDimTotal = 5; //total number of options
//int lightSensor = 0;
float lightSensorAvg;
byte autoDim = 15; // 0 - 100
byte lowDim = 2; // divided by 4 to conform to byte, orginally 8
byte highDim = 16; // will be multiplied by 4 in code, orginally 64
byte AutoDimOrder = 1; //1 = auto, 2 = low, 3 = high
//byte AutoResync = 2; //1 = On, 2 = Off

//counter variables for RGB Preset Color Selection Screen
byte RGBOrder = 4; //1 = Red, Orange, Yellow, Green, Cyan, Blue, Purple, Pink, White, 10 = Custom
//byte RGBTotal = 10;

//counter variables for RGB Custom Color Selection Screen
byte RGBCustomOrder = 0; //0 = red, 1 = green, 2= blue
//byte RGBCustomTotal = 3;

//stores custom RGB color values
byte redCustom = 0;
byte greenCustom = 0;
byte blueCustom = 0;

//EEPROM Addresses to save options between power cycles
const byte EEreset        = 0;        //used to determin EEPROM State for first boot
const byte EEdataOrder1   = 1;   //stores first gauge counter
const byte EEdataOrder2   = 2;
const byte EEdataOrder3   = 3; 
const byte EEdataOrder4   = 4;
const byte EERGBOrder     = 5;     //preset color setting
const byte EERGBDimOrder  = 6;  //dim setting
const byte EEredValue     = 7;     //selected color values
const byte EEgreenValue   = 8;
const byte EEblueValue    = 9;
const byte EEredCustom    = 10;   //custom color values
const byte EEgreenCustom  = 11;
const byte EEblueCustom   = 12;
const byte EERGBDim       = 13;      //selected dim value
const byte EEsplashScreen = 14;
const byte EEupdateSpeedMenu = 15; //saves menu screen for continuity
const byte EEupdateSpeed  = 16; //saves actual delay value
const byte EEengine       = 17; //was previously Program Number
const byte EEtransType    = 18; //was previously customProgramNumber = 18;
const byte EEModelNumberHi = 19;
const byte EEModelNumberLo = 20;
const byte EEcel          = 21;
const byte EEpressureUnit = 22;
const byte EEtempUnit     = 23;
const byte EEtpsMode      = 24;
const byte EEloopMode     = 25; //not used anymore
const byte EEautoDim      = 26;
const byte EElowDim       = 27;
const byte EEhighDim      = 28;
const byte EEAutoResync   = 29;
const byte EETireSize     = 30;
const byte EEGearRatioCounter = 31;
const byte EESpeedCorr    = 32;
const byte EEspeedUnit    = 33;
const byte EEGearRatio    = 34; //This is a float, takes up 4 addresses, don't write to 34-37
const byte EEBest060Time  = 38; //float for 0-60, don't write 38-41
const byte EEhourSetting  = 42;
const byte EEhomeScreen   = 43;
const byte EEbluetooth    = 44;
const byte EEgyroscope    = 45;
const byte EEfan1Pin      = 46;
const byte EEfan2Pin      = 47;
const byte EEfan3Pin      = 48;
const byte EEfan1Mode     = 49;
const byte EEfan2Mode     = 50;
const byte EEfan3Mode     = 51;
const byte EEtemp1on      = 52;
const byte EEtemp1off     = 53;
const byte EEtemp2on      = 54;
const byte EEtemp2off     = 55;
const byte EEtemp3on      = 56;
const byte EEtemp3off     = 57;
const byte EEac1Trigger   = 58;
const byte EEac2Trigger   = 59;
const byte EEac3Trigger   = 60;
const byte EEclockMode    = 61;
const byte EEusbOutput    = 62;
const byte EEclockLowDim  = 63;
const byte EEclockHighDim = 64;
const byte EEmpgMode      = 65;
const byte EErollOffset   = 66;
const byte EEpitchOffset  = 67;
const byte EEdualFan      = 68;
const byte EEdistanceTrack = 69; //This is a float, takes up 4 addresses, don't write to 69-72
const byte EEfuelTrack    = 73; //float, don't write 73-76
const byte EEtankSize     = 77;
const byte EEtankLevel    = 78; //float, don't write 78-81
const byte EEfuelCal      = 82; //float, don't write 82-85
const byte EEfillupCheck  = 86;
const byte EEwideband     = 87;
const byte EEAFRtarget    = 88; //float, don't write 88-91
const byte EEAFRrange     = 92; //float, don't write 92-95
const byte EEAVGmode      = 96;
const byte EEwidebandPin  = 97;
const byte EEInjCorr      = 98;
const byte EEfuelCalMode  = 99;
const byte EErpmUnit      = 100;
const byte EEfuelTrimUnit = 101;
const byte EEnewVehicle   = 102;
const byte EEnoStartOverride = 103;
const byte EEfuelPressurePin = 104;
const byte EEtimeSetpoint = 105; //time_t, don't write 105-108
const byte EEtimeDriftRate = 109; //int, don't write 109-110

bool rpmUnit;
bool fuelTrimUnit;

//Stuff for In/Out Adapter

bool fan1State;
bool fan2State;
bool fan3State;

const byte out = 1;
const byte in = 2;
const byte inPull = 3;

const byte off = 1;
const byte on = 2;
const byte Auto = 3;

byte InOutOrder;
byte ioCursor;

unsigned long loopTime;

unsigned long screenTimer; //used to auto refresh screen
bool updateTimedScreen;

const byte menu = 2; //shortcuts for menu refreshing
const byte buttons = 1;
bool screenBtnFlag;
//byte btDelay = 100;
byte dizzyPrev;
byte dizzyCounter = 7; //fix for initial ++ advance
bool dizzyFlag = true; //runs atleast once to create char
bool dizzyCEL = false;

//byte i2cFlag = false;

byte fanSetupOrder = 1;
bool fanKill;
bool clockDimOrder;

//unsigned long dimPrev;
bool autoDimTestFlag;

bool gyroFlag;
unsigned long gyroPrevTime;
unsigned long gyroUpdateTime;
bool gyroCaliOrder;

bool charFlag;

//fuel tracking
float dtElapsed; //FUN FACT, needs float for better accuracy in later calcs
unsigned long dtPrev;
float distanceCurrent;
float distanceTemp;
float distanceHistory = 0;

float ftElapsed;
unsigned long ftPrev;
float fuelCurrent;
float fuelTemp;
float fuelHistory = 0;

float avgMPG;
float avgGPH;
float engineRunTime;

unsigned long ecuStreamTime;
unsigned int ecuPrevTime;
byte engineRunCount;
bool engineRunFlag;

float dPrev; //eeprom check 
float fPrev;
float dTemp;
float fTemp;
float startDist;
float startFuel;

float InjCorr = 1.00;
byte fuelCalMode = 1;

//Wideband o2 stuff
float AFRV;
float AFR;
float AFRtarget = 14.7;
float AFRrange = 0.5;
unsigned long o2UpdateTime;
long o2DAC;

byte ecuCursor;
byte ecuCursorMove;
bool ecuFirstDataFlag = false;

unsigned int RPMPrev;
float InjPulsePrev;
bool celManualFlag;
bool celExpandFlag;
byte celPrevReading; //hack-ish variable to work with celExpand

const byte celArrayTotal = 24;
byte celBitmapArray[celArrayTotal]; //7-0,  Fault, Glitch, L2, L1, x
unsigned long celStopwatchArray[celArrayTotal]; //last initial trigger time 
//word celPrevTimeArray[celArrayTotal]; //last final active time
byte celFaultArray[celArrayTotal]; //Fault Count
byte celGlitchArray[celArrayTotal]; //Glitch Count
byte celStarBitmap = 0;

// CEL ARRAY Master Log
const byte MAPL     = 0;
const byte MAPH     = 1;
const byte BARL     = 2;
const byte CTSL     = 3;
const byte CTSH     = 4;
const byte IATL     = 5;
const byte IATH     = 6;
const byte VoltL    = 7;
const byte VoltH    = 8;
const byte CrankVL  = 9;
const byte o2L      = 10;
const byte o2H      = 11;
const byte o2HeatL  = 12;
const byte stftL    = 13;
const byte stftH    = 14;
const byte RPMD     = 15;
const byte RPML     = 16;
const byte RPMH     = 17;
const byte TPSL     = 18;
const byte TPSH     = 19;
const byte KnockH   = 20;
const byte KnockD   = 21;
const byte SyncD    = 22;
const byte INJH     = 23;


float floaty; //Used to set EEPROM type

int listCursor;
int listCursorMove;
byte sensorMenu = 0;
bool sigOutOverride = false; //used to test sig out opperation

byte ParkInvert[8] =
    {
      B00001,
      B01110,
      B01110,
      B00001,
      B01111,
      B01111,
      B01111
    };
byte rightLine[8] =
    {
      B00111,
      B00110,
      B00100,
      B00100,
      B00100,
      B00110,
      B00111
    };
byte leftLine[8] =
    {
      B11100,
      B01100,
      B00100,
      B00100,
      B00100,
      B01100,
      B11100
    };

byte upArrow[8] =
    {
      B00000,
      B00100,
      B01110,
      B10101,
      B00100,
      B00100,
      B00000
    };
byte downArrow[8] =
    {
      B00000,
      B00100,
      B00100,
      B10101,
      B01110,
      B00100,
      B00000
    };

bool homeFlag = false; //emergency skip to home

//volt pin function commands
const byte SUB   = 0;
const byte ADD   = 1;
const byte PRINT = 2;

static bool celBlinkyFlag;//for Active CEL Blinking Timer
byte prevCursorBlock; // for list scrolling no error checking

//********************************************************************************************************************************************************************************************************
void setup()
{
  //Check to see if EEPROM is blank and write useable values 
  if (EEPROM.read(EEreset) == 255){
    EEPROM.update(EEreset, 0);
    EEPROM.update(EEdataOrder1, CTSGauge);
    EEPROM.update(EEdataOrder2, RPMGauge);
    EEPROM.update(EEdataOrder3, TPSGauge);
    EEPROM.update(EEdataOrder4, voltGauge);
    EEPROM.update(EERGBOrder, 4);     //preset color setting
    EEPROM.update(EERGBDimOrder, 4);  //dim setting
    EEPROM.update(EEredValue, 0);     //selected color values
    EEPROM.update(EEgreenValue, 255);
    EEPROM.update(EEblueValue, 0);
    EEPROM.update(EEredCustom, 128);   //custom color values
    EEPROM.update(EEgreenCustom, 128);
    EEPROM.update(EEblueCustom, 128);
    EEPROM.update(EERGBDim, 100);      //selected dim value
    EEPROM.update(EEsplashScreen, true); //on
    EEPROM.update(EEupdateSpeedMenu, 3);
    EEPROM.update(EEupdateSpeed, fast);
    EEPROM.update(EEtransType, false); //Manual
    EEPROM.update(EEengine, 4);
    EEPROM.update(EEcel, 2);
    EEPROM.update(EEpressureUnit, 2);
    EEPROM.update(EEtempUnit, true); //F
    EEPROM.update(EEtpsMode, true); //normal
    //EEPROM.update(EEloopMode, true); //normal
    EEPROM.update(EEautoDim, 15);
    EEPROM.update(EElowDim, 8);
    EEPROM.update(EEhighDim, 12);
    //EEPROM.update(EEAutoResync, 2);//V1-V2 option
    EEPROM.update(EETireSize, 29);
    EEPROM.update(EEGearRatioCounter, 2);
    EEPROM.update(EESpeedCorr, 100);
    EEPROM.update(EEspeedUnit, true); //mph
    EEPROM.put(EEGearRatio, GearRatio);//notice .put, second argument is just the data type, variable is set equal to the value we want
    EEPROM.put(EEBest060Time, Best060Time);
    EEPROM.update(EEhourSetting, true);//V3 option
    EEPROM.update(EEhomeScreen, false);//V3 option
    EEPROM.update(EEbluetooth, false);
    EEPROM.update(EEgyroscope, false);
    EEPROM.update(EEfan1Pin, 0);
    EEPROM.update(EEfan2Pin, 0);
    EEPROM.update(EEfan3Pin, 0);
    EEPROM.update(EEfan1Mode, off);
    EEPROM.update(EEfan2Mode, off);
    EEPROM.update(EEfan3Mode, off);
    EEPROM.update(EEtemp1on, 210);
    EEPROM.update(EEtemp1off, 205);
    EEPROM.update(EEtemp2on, 210);
    EEPROM.update(EEtemp2off, 205);
    EEPROM.update(EEtemp3on, 210);
    EEPROM.update(EEtemp3off, 205);
    EEPROM.update(EEac1Trigger, 0);
    EEPROM.update(EEac2Trigger, 0);
    EEPROM.update(EEac3Trigger, 0);
    EEPROM.update(EEclockMode, 3);
    EEPROM.update(EEusbOutput, 0);
    EEPROM.update(EEclockLowDim, 3);
    EEPROM.update(EEclockHighDim, 15);
    EEPROM.update(EEmpgMode, 1);
    EEPROM.update(EErollOffset, 128);
    EEPROM.update(EEpitchOffset, 128);
    EEPROM.update(EEdualFan, 0);
    EEPROM.put(EEdistanceTrack, 0.00);
    EEPROM.put(EEfuelTrack, 0.00);
    EEPROM.update(EEtankSize, true);
    EEPROM.put(EEtankLevel, 0.00);
    EEPROM.put(EEfuelCal, 1.00);
    EEPROM.update(EEfillupCheck, 0);
    EEPROM.update(EEwideband, 0);
    EEPROM.put(EEAFRtarget, 14.7);
    EEPROM.put(EEAFRrange, 0.5);
    EEPROM.update(EEAVGmode, 0);
    EEPROM.update(EEwidebandPin, 0);
    EEPROM.update(EEInjCorr, 128);
    EEPROM.update(EEfuelCalMode, 0);
    EEPROM.update(EErpmUnit, 0);
    EEPROM.update(EEfuelTrimUnit, 0);
    EEPROM.update(EEnewVehicle, true);
    EEPROM.update(EEnoStartOverride, false);
    EEPROM.update(EEfuelPressurePin, 0);
    EEPROM.put(EEtimeSetpoint, 0);
    EEPROM.put(EEtimeDriftRate, 0); //int value, /10 for single decimal
  }
  //EEPROM.put(EEtimeSetpoint, 1671580980); //placeholder setpoint
  //EEPROM.put(EEtimeDriftRate, 94); //int value, /10 for single decimal

  getBoardVersion(); //reads model number to set board version
  
// Sets the Active Varables equal to the Saved Variables
  redValue = EEPROM.read(EEredValue);
  greenValue = EEPROM.read(EEgreenValue);
  blueValue = EEPROM.read(EEblueValue);
  
  RGBDim = EEPROM.read(EERGBDim);
  autoDim = EEPROM.read(EEautoDim);
  lowDim = EEPROM.read(EElowDim);
  highDim = EEPROM.read(EEhighDim);
  
  redCustom = EEPROM.read(EEredCustom);
  greenCustom = EEPROM.read(EEgreenCustom);
  blueCustom = EEPROM.read(EEblueCustom);
  
  RGBOrder = EEPROM.read(EERGBOrder);
  RGBDimOrder = EEPROM.read(EERGBDimOrder);
  
  Wire.begin();
  //AutoResync = EEPROM.read(EEAutoResync);

  for (byte i = 0; i < 4; i++)                  //Check dataOrder bounds, out of bounds will cause a crash
  {
    //Serial.println(EEdataOrder1 + i);
    //Serial.println(EEPROM.read(EEdataOrder1 + i));
    if (EEPROM.read(EEdataOrder1 + i) >= dataTotal)
      EEPROM.update(EEdataOrder1 + i, RPMGauge);
  }
  dataOrder1 = EEPROM.read(EEdataOrder1);       //gauge order
  dataOrder2 = EEPROM.read(EEdataOrder2);
  dataOrder3 = EEPROM.read(EEdataOrder3);
  dataOrder4 = EEPROM.read(EEdataOrder4);

  updateSpeed = EEPROM.read(EEupdateSpeed);

  cel = EEPROM.read(EEcel);
  pressureUnit = EEPROM.read(EEpressureUnit);
  tempUnit = EEPROM.read(EEtempUnit);
  mpgMode = EEPROM.read(EEmpgMode);
  tpsMode = EEPROM.read(EEtpsMode);
  //loopMode = EEPROM.read(EEloopMode);

  engine = EEPROM.read(EEengine);
  transType = EEPROM.read(EEtransType);
  TireSize = EEPROM.read(EETireSize);
  GearRatioCounter = EEPROM.read(EEGearRatioCounter);
  SpeedCorr = EEPROM.read(EESpeedCorr);
  speedUnit = EEPROM.read(EEspeedUnit);
  GearRatio = EEPROM.get(EEGearRatio, GearRatio);//reads in the float
  InjCorr   = EEPROM.read(EEInjCorr);
  InjCorr   = (InjCorr - 128) / 2;
  fuelCalMode = EEPROM.read(EEfuelCalMode);
  rpmUnit =     EEPROM.read(EErpmUnit);
  fuelTrimUnit = EEPROM.read(EEfuelTrimUnit);

  show12Hours = EEPROM.read(EEhourSetting);//V3 option
  homeScreen = EEPROM.read(EEhomeScreen);//V3 option

  startDist = EEPROM.get(EEdistanceTrack, startDist);
  startFuel = EEPROM.get(EEfuelTrack, startFuel);

  pinMode(0, INPUT_PULLUP);               // Pin zero, RX on the UART
  Serial1.begin(62500);                   // Begin ECU serial comms at 62500.
  pinMode(TCUpin, INPUT_PULLUP);          // RX pin for TCU, needs external pullup to work long distance
  tcuSerialPort.begin(500);               // Begin TCU serial comms at 500.
  
  celOn();                                // Turns on Check Engine Light
  lcd.begin(16,2);                        //set up the LCD's number of columns and rows 
  createTempChar();                       //sends custom character to lcd memory

  rtcTimeBegin();                            //start time keeping functions
  
  //Wire.begin(); //start i2c library, needed to prevent non exsitant gyro from locking up code
   
  if (EEPROM.read(EEgyroscope) > 0){//Initialise gyro sensors
    gyro.begin();
    accelmag.begin(ACCEL_RANGE_4G);
  // Filter expects 70 samples per second
  // Based on a Bluefruit M0 Feather ... rate should be adjuted for other MCUs
    filter.begin(1);
  }

  //auto i2c Reset if RTC gets stuck with data line low
  i2cLineUnsticker();

  //Commands for AS1115 7-Seg IC 
  clockBegin();
// Serial Commands don't seem to work till here? using IDE 2.0.3
  updateAutoDim();  //gets dim value for backlight
  updateRGB();      //sets RGB backlight color and brightness

  if (EEPROM.read(EEsplashScreen) == true && EEPROM.read(EEnoStartOverride) == false)    //display Splash Screen Text
  {
    int bootDelay = 3000;
    
    lcd.setCursor(0,0);
    lcd.print(F("Renduinix+ v"));          
    lcd.print(softwareVersion,2);
    lcd.setCursor(0,1);
    lcd.print(F("Nick Risley 2024"));
    
    if (EEPROM.read(EEclockMode) != 0) {
      bootDelay -= clockBootAnimation();
    }
    delay(bootDelay);                
  }
  celOff();
  lcd.clear(); 

  if (EEPROM.read(EEbluetooth) != false)
    btSerialPort.begin(115200);

  //pinMode(9, INPUT_PULLUP);
  //Serial2.begin(9600);
  //Serial.begin(115200);

  if (EEPROM.read(EEusbOutput) == 3) //passthrough
    Serial.begin(62500);
  else if (EEPROM.read(EEusbOutput) > 0)  
    Serial.begin(115200); //moved to the bottom because it increases boot time

//driftOffsetNow(); //test 

//SD Card stuff
  /*Serial.print("Initializing SD card... ");
  
  // see if the card is present and can be initialized:
  if (!SD.begin(sdCSPin))
    Serial.println("Card failed, or not present");
  else
    Serial.println("Card Initialized.");
    */
//sets menu to gauge screen if data is available
  if (Serial1.available() > 0)
    menuOrder = Gauges;
  else menuOrder = Home;

  if (analogRead(buttonsPin) > 400){ //emergency case for lack of home button or other program faults
    menuOrder = Home;
    homeFlag = true;
  }

  else if (EEPROM.read(EEnewVehicle) > 0){ //first start opens vehicle menu
    menuOrder = Vehicle;
    EEPROM.update(EEnewVehicle, 0);
  }

  else if (EEPROM.read(EEnoStartOverride) == true) //go to no-start helper, useful if power disconnects temporaily
    menuOrder = NoStartMenu;


  //menuOrder = NoStartMenu; //for testing, jumps directly to this menu
  analogReadAveraging(32); // this one is optional TEENSY
  
  //pinMode(13, OUTPUT);
/*
  pinMode(A1, OUTPUT);//useful debug for checking loop time with an osciliscope
  pinMode(A2, OUTPUT);//useful debug for checking loop time with an osciliscope
  
  // be sure to set the ADC to use the external reference, put the following in your setup():
    analogReference(EXTERNAL);
    analogReadResolution(12);
    analogReadAveraging(32); // this one is optional.
    */

}
  //float wbSerial;
  //bool wbReadFlag;
  
void loop()
{ 
  /*
  if (Serial2.available() > 0){ //read and parse wideband
    if (wbReadFlag == false){
      if (Serial2.read() == 10){ //carriage return search, -38
        wbReadFlag = true;
      }
    }
    if (wbReadFlag == true){ //read in number
      if (Serial2.available() > 4){ //wait for all numbers to arrive
        wbSerial = (Serial2.read() - 48) * 10; //10's
        wbSerial += Serial2.read() - 48;       //1's
        Serial2.read();                        //dump decimal
        float temp = (Serial2.read() - 48);
        wbSerial += temp / 10;                 //10th's
        Serial2.read();                        //dump line end
        wbReadFlag = false;                    //reset flag
        //Serial.println(wbSerial, 1);
      }
    }
    //Serial.write(Serial2.read());
    
  }
  //delay(1);
  //Serial.println(digitalRead(9));
  */
//sorta useful debug for checking looptime over serial.
  /*currentTime = micros();
  loopTime = currentTime - loopTime;
  Serial.println(loopTime);
  loopTime = currentTime;*/
  
//useful debug for checking loop time with an osciliscope
  //digitalWrite(A2, !digitalRead(A2));
  /*
//unsigned long vin = getInputVoltage();
if (digitalRead(TCUpin) == LOW)
  digitalWrite(13, HIGH);
else
  digitalWrite(13, LOW);
  */

  i2cLineUnsticker(); //max 10 attempt limit

/*
//emergency clock dim if voltage reg overheat is detected
  if (getInputVoltage() > 374) //Since the input V is the Aref, this isn't directly accurate, but it does go up during brownout so it'll do. 
    asWrite(0x0A, 0x01); // normal is around 368-370
*/        
  updateClock(); //for seven segment clock display

  updateAutoDim(); //Auto Dimming Routine
  updateRGB();     //Sets RGB Backlight color and intensity

  autoDimTestFlag = false;//reset flag for autoDim Menu
  
  prevKey = lcdKey;
  lcdKey = readLcdButtons();// For averaging's sake, it's best to only run this once per loop, read in button pressed

  //btnState();

  static byte lcdKeyPrev = 0;
  static byte btnHoldCounter = 0;
  static unsigned long btnTimer = 0;
  if (lcdKey == lcdKeyPrev && lcdKey != btnNone){ //button hold repeating code
    if (btnHoldCounter == 0){ //inital timer set
      btnHoldCounter = 1;
      btnTimer = millis();
    }
    if (btnHoldCounter == 1 && btnTimer + 800 < millis()){ //hold initial trigger
      btnHoldCounter = 2;
      btnRepeatFlag = true;  
      btnHoldFlag = true;    
    }
    if (btnHoldCounter == 2 && btnRepeatFlag == false){ //repeat hold wait loop
      btnTimer = millis();
      btnHoldCounter = 3;
    }
    if (btnHoldCounter == 3 && btnTimer + 30 < millis()){ //repeat hold trigger loop
      btnRepeatFlag = true;
      btnHoldCounter = 2;
    }
  }
  else{
    btnHoldCounter = 0;
    btnRepeatFlag = false;
    btnHoldFlag = false;
  }
  lcdKeyPrev = lcdKey;
  
    
  if (btnCheck(btnHome))        //checks if Select button press is true & debounce button presses
  {
    if (menuOrder == CustomColor)   //saves color and resets screen color
      menuOrder = RGBCustomSave;
    else{
      menuOrder = Home;             //sets order back to home screen  
      celOff();                     //turns off cel
      lcd.noCursor();//removes underline cursor
    }
    lcd.begin(16,2);  //used to resync the screen if it bugs out
    createTempChar(); //sends custom character to lcd memory
    charFlag = false; //reset char check flag
  }

  if (EEPROM.read(EEwidebandPin) > 0)
    updateO2(); //reads AFR and converts AFR into Narrow o2 output
  
  getData(); //this get's all our data, check tab

  if (ecuStreamUpdate == true)
    updateCEL();//Check Engine Light stuff, check tab

  updateIO(); //updates free In/Out pins for Fan support

  if (gyroFlag == true && millis() >= gyroUpdateTime + 10){ 
    gyroUpdateTime = millis(); 
    updateGyroMagFilter();

/*
  float roll = filter.getRoll();
  float pitch = filter.getPitch();
  float heading = filter.getYaw();
  Serial.print(heading, 1);
  Serial.print(" ");
  Serial.print(pitch, 1);
  Serial.print(" ");
  Serial.print(roll, 1);

  sensors_event_t aevent;
  accelmag.getEvent(&aevent);

  Serial.print(" ");
  Serial.print((aevent.acceleration.y * 9)*-1);
  Serial.print(" ");
  Serial.print((aevent.acceleration.x * 9)*-1);
  Serial.print(" ");
  Serial.println((aevent.acceleration.z * 9)*-1);*/
   }

  if (millis() > gyroPrevTime + 2000)
    gyroFlag = false; //Reset update flag if not being used

  if (menuOrder != NoStartMenu)
    EEPROM.update(EEnoStartOverride, false); //forces menu to show first incase power is lost temporarily    
    

//V1/V2 AutoResync routine
  /*currentTime = millis();//update variable to current runtime
  if (currentTime > resyncPrevTime + 1000 && AutoResync == 1){ //checks for proper delay and setting  
    resyncPrevTime = currentTime;
    lcd.begin(16,2);  //used to resync the screen if it bugs out
    lcd.createChar(3, fahrenheitSymbol); //sends custom character to lcd memory
    lcd.createChar(4, celsiusSymbol);
    updateScreen = 1;
    }*/
    //________
    //1O 2f 3f
//Main Switch Case to control displayed Menu
switch (menuOrder)
 {
    case InOutMenu://Extra In Out Pins for REM****************************************************************************
      switch (InOutOrder){
        case 0://main menu*****************************************
          if (updateScreen > 0){
            lcd.clear();
       
            lcd.setCursor(0,0);
            lcd.print("Fan1");
          
            lcd.setCursor(0,1);
            lcd.print("Fan2");
          
            lcd.setCursor(11,0);
            lcd.print("Setup");
            
            lcd.setCursor(12,1);
            lcd.print("Fan3"); 
          }

          lcd.setCursor(5,0); //Pin 1
          if (updateTimedScreen == true || updateScreen > 0){ 
            if (EEPROM.read(EEfan1Pin)){
              if (fan1State == HIGH)
                lcd.print("ON ");
              else lcd.print("OFF");
            }
            else lcd.print("X ");

            intPrint(CTS, 3);        

            lcd.setCursor(5,1); //Pin 2
            if (EEPROM.read(EEfan2Pin)){
              if (fan2State == HIGH)
                lcd.print("ON ");
              else lcd.print("OFF");
            }
            else lcd.print("X");
            

            lcd.setCursor(9,1); //Pin 3
            if (EEPROM.read(EEfan3Pin)){
              if (fan3State == HIGH)
                lcd.print("ON");
              else lcd.print("OF");
            }
            else lcd.print(" X");
          }
          
          if (btnCheck(btnTopLeft))
            InOutOrder = 1;
          if (btnCheck(btnTopRight))
            InOutOrder = 4;
          if (btnCheck(btnBottomLeft))
            InOutOrder = 2;
          if (btnCheck(btnBottomRight))
            InOutOrder = 3;
        break;
        case 4://Setup menu**********************************************
          if (btnCheck(btnTopLeft)){ //goes back 1 menu
            if (fanSetupOrder == 1)
              InOutOrder = 0;
            else
              --fanSetupOrder;
          }  
          
          if (btnCheck(btnTopRight)) //goes forward 1 menu
            ++fanSetupOrder;

          rollover(fanSetupOrder, 1, 5);

            
          if (updateScreen > 0){
            lcd.clear();
            menuArrows();
            if (fanSetupOrder == 1)
            {
              lcd.setCursor(0,0);
              lcd.print("^");
            }
          }
          switch(fanSetupOrder){
            case 1://fan kill**********************
              if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
                fanKill = !fanKill;//Boolean variable, neat trick to switch the value to true or flase

              if (updateScreen > 0){
                lcd.noCursor();
                centerPrint("Fan Mode", 0);
                if (fanKill == true)
                  centerPrint("ALL OFF", 1);
                else 
                  centerPrint("Normal", 1);
               }
            break;
            case 2://fan 1 set***********************
              fanSetupMenu(EEfan1Pin, 1);
            break;
            case 3://fan 2 set***********************
              fanSetupMenu(EEfan2Pin, 2);
            break;
            case 4://fan 3 set***********************
              fanSetupMenu(EEfan3Pin, 3); 
            break;
            case 5://Low/High Fan set****************
              if (btnCheck(btnBottomLeft)){//decrease
                if (EEPROM.read(EEdualFan) > 0)
                  EEPROM.update(EEdualFan, EEPROM.read(EEdualFan) - 1);
              } 
              if (btnCheck(btnBottomRight)){//decrease
                if (EEPROM.read(EEdualFan) < 3)
                  EEPROM.update(EEdualFan, EEPROM.read(EEdualFan) + 1);
              }

              if (updateScreen > 0){
                lcd.noCursor();
                centerPrint("2 Speed Fan", 0);
                switch(EEPROM.read(EEdualFan))
                {
                  case 0:
                    centerPrint("None", 1);
                  break;
                  case 1:
                    centerPrint("1 Lo / 2 Hi", 1);
                  break;
                  case 2:
                    centerPrint("2 Lo / 3 Hi", 1);
                  break;
                  case 3:
                    centerPrint("1 Lo / 3 Hi", 1);
                  break;
                  default:
                    centerPrint(EEPROM.read(EEdualFan), 1);
                    EEPROM.update(EEdualFan, 0);
                  break;
                }
              }
            break;
          }
        break;
        case 1://Pin 1 main menu*****************************************
          fanMainMenu(11, EEfan1Mode, fan1State);
        break;
        case 11://Pin 1 Auto Edit Menu*****************************************
          fanEditMenu(1, EEtemp1on, EEtemp1off, EEac1Trigger, fan1State);
        break;
        case 2://Pin 2 main menu*****************************************
          fanMainMenu(22, EEfan2Mode, fan2State);
        break;
        case 22://Pin 2 Auto Edit Menu*****************************************
          fanEditMenu(2, EEtemp2on, EEtemp2off, EEac2Trigger, fan2State);
        break;
        case 3://Pin 3 main menu*****************************************
          fanMainMenu(33, EEfan3Mode, fan3State);
        break;
        case 33://Pin 3 Auto Edit Menu*****************************************
          fanEditMenu(3, EEtemp3on, EEtemp3off, EEac3Trigger, fan3State);
        break;
      }//InOutOrder end
    break;
    case TCUGauges://TCU Gauge Screen**************************************************************************************
      if (transType == false)
        menuOrder = Vehicle;//just used for gauge length at this point

      celManualFlag = true; //disables Main CEL light trip code
      if(SolenoidFaults != 0 || TPSFaults != 0)
        celOn();
      else celOff(); 
        
      if (tcuMenu == 0 && (tcuStreamUpdate == true || updateScreen > 0)){ //checks screen update flag
      //tcuStreamUpdate = false;//reset flag
                          
      lcd.setCursor(0,0); //row 1
      intPrint(tcuRPM, 4);
      lcd.print(F("RPM"));

      
      intPrint(MPH, 3);
      if (speedUnit == false)
        lcd.print("KPH");
      else
        lcd.print("MPH");

      intPrint(tcuTPS, 2);
      lcd.print("TPS");

    
      lcd.setCursor(0,1); //row 2
      switch(tcuPRNDL)
      {
        case 1: //1-2
          lcd.print("1-2");
        break;
        case 3: //3rd
          lcd.print(" D3");
        break;
        case 4: //PRND
          lcd.print("RND");
        break;
        default: //????
          lcd.print("???");
        break;
      }
      
      switch(tcuGear)
      {
        case 1: //1st
          lcd.print(" 1ST");
        break;
        case 2: //2nd
          lcd.print(" 2ND");
        break;
        case 3: //3rd
          lcd.print(" 3RD");
        break;
        case 4: //4th
          lcd.print(" 4TH");
        break;
        default: //????
          lcd.print(" ???");
        break;
      }
      
      if (tcuBrake == true)
        lcd.print(" B");
      else
        lcd.print("  ");
    
      if (solenoid1 == true)
        lcd.print("1");
      else
        lcd.print(" ");
    
      if (solenoid2 == true)
        lcd.print("2");
      else
        lcd.print(" ");
    
      if (solenoid3 == true)
        lcd.print("L");
      else
        lcd.print(" ");

      if (tcuMode == true)
        lcd.print("P");
      else
        lcd.print("C");

      bitPrint(SolenoidFaults);
      lcd.print("/");
      bitPrint(TPSFaults);
      
    }//main display end
    
    if (btnCheck(btnTopLeft))
      tcuMenu = 0;
    if (tcuMenu == 0){
      if (btnCheck(btnTopRight) || btnCheck(btnBottomLeft))
        tcuMenu = 1;
      if (btnCheck(btnBottomRight))
        menuOrder = TCUErrors;
    }
    
    if (tcuMenu != 0){ //0-60 timer              
        if (armedFlag == 0)
          Best060Time = EEPROM.get(EEBest060Time, Best060Time);
        
        if (tcuRPM < 681 && (MPH > 0 || tcuTPS > 1) && armedFlag == 2){//Armed initial trigger
          startTime = millis();
          armedFlag = 3;
        }
        if (armedFlag == 3){//Armed timer
          endTime = millis();
          launchTime = (endTime - startTime) / 1000;//Fun Fact, Software Serial Data reading interupts millis updating, so a correction factor was previously needed.
          if ((MPH >= 60 && speedUnit == true) || (MPH >= 100 && speedUnit == false)){//timer finish
            armedFlag = 1;
            if (launchTime < Best060Time){//Best Time Recording
              Best060Time = launchTime;
              EEPROM.put(EEBest060Time, launchTime);
              armedFlag = 4;
            }//end best time if
          }//end 60 if
          if (MPH == 0){
            armedFlag = 2;//set back to waiting mode if vehicle stops again
            startTime = endTime;//resets counter
          }//end 0 mph if
        }//end timer if 

      if (tcuStreamUpdate == true || updateScreen > 0){ //if statement may help grab tcu data more reliably
        //tcuStreamUpdate = false;//reset flag
        
         lcd.setCursor(0,0);
        if (armedFlag == 4)
          lcd.print(F(" NEW BEST TIME! "));
        else{
          if (speedUnit == false)
            lcd.print(F("0-100Timer:"));
          else
            lcd.print(F("0-60 Timer:"));
          
          if (armedFlag > 1)
            lcd.print(F("ARMED"));
          else if (armedFlag == 0)
            lcd.print(F("Best "));
          else lcd.print(F("idle "));
        }
        
        lcd.setCursor(0,1);
        if (armedFlag == 0)
          lcd.print("r");
        else
          lcd.print(" ");
          
        floatPrint(MPH, 5, 1);
        if (speedUnit == false)
          lcd.print("KPH");
        else
          lcd.print("MPH");
          
        if (armedFlag == 0){
          floatPrint(Best060Time, 6, 2);
          lcd.print("s");
        }
        }//end screen update

        if (armedFlag != 0 && millis() > prevTime + 60){
          prevTime = millis();
          lcd.setCursor(9,1);
          floatPrint(launchTime, 6, 2);
          lcd.print("s");
        }
      
       
      if (btnCheck(btnTopRight) || btnCheck(btnBottomRight)){
        ++armedFlag;
        if (armedFlag > 2)
          armedFlag = 0;
      }
      if(btnCheck(btnBottomLeft) && armedFlag == 0) //reset only if on best screen
        EEPROM.put(EEBest060Time, 99.99);

    }//if 0-60 menu
  break;
  case TCUErrors://TCU Error Code Screen *********************************************************************************
    celManualFlag = true; //disables Main CEL light trip code
    if(SolenoidFaults != 0 || TPSFaults != 0)
        celOn();
    else celOff();
        
    if (tcuStreamUpdate == true|| updateScreen > 0){//if statment helps tcu read in reliably
      lcd.clear();
        
      lcd.setCursor(15,0);
      lcd.print("^");
      lcd.setCursor(15,1);
      lcd.print("v");
    
      tcuCursor = 1 - tcuCursorMove; 
      
      if (tcuCursor > -1 && tcuCursor < 2){
        lcd.setCursor(0,tcuCursor);
        leftArrow();
        lcd.print(F("TCU Error:"));
        
        bitPrint(SolenoidFaults);
        lcd.print("/");
        bitPrint(TPSFaults);
      }
        ++tcuCursor;
    
        if (SolenoidFaults == 0 && TPSFaults == 0){
          lcd.setCursor(0,1);
          lcd.print(F("No Codes Found"));
        }

        byte tcuCurrCheck = SolenoidFaults & B11100000; //mask to remove lower bits 
        TerrorPrint(tcuCurrCheck > 0 || TPSFaults > 0, "*Current Codes*");

        TerrorPrint(bitRead(SolenoidFaults, 0), "Bit 0 Error?"); //incase these ever trip
        TerrorPrint(bitRead(SolenoidFaults, 0), "Bit 4 Error?");

        TerrorPrint(TPSFaults > 0, "TCU TPS Fault  "); //TPS Current
        TerrorPrint(bitRead(SolenoidFaults, 5), "Solenoid 1 Falt"); //S1 Current
        TerrorPrint(bitRead(SolenoidFaults, 6), "Solenoid 2 Falt"); //S2 Current
        TerrorPrint(bitRead(SolenoidFaults, 7), "Solenoid 3 Falt"); //S3 Current

        byte tcuStoreCheck = SolenoidFaults & B00001110; //mask to remove higher bits 
        TerrorPrint(tcuStoreCheck > 0, "*Stored Codes*");

        TerrorPrint(bitRead(SolenoidFaults, 1), "Solenoid 1 Falt"); //S1 Stored
        TerrorPrint(bitRead(SolenoidFaults, 2), "Solenoid 2 Falt"); //S2 Stored
        TerrorPrint(bitRead(SolenoidFaults, 3), "Solenoid 3 Falt"); //S3 Stored
    }
    
    if (btnCheck(btnTopLeft))
      menuOrder = TCUGauges;
      
    if (btnCheck(btnTopRight))
      --tcuCursorMove;
      
    if (btnCheck(btnBottomRight) &&  tcuCursor > 1)
      ++tcuCursorMove;

    tcuCursorMove = constrain(tcuCursorMove, 1, 10); 
  break;
  case Gauges://Gauge Screen *********************************************************************************************   
    
    if (btnRelease(btnTopLeft))     //falling edge advances
      gaugeSkip(dataOrder1, true);  //range keeping and skips unused gauges
    if (btnHold(btnTopLeft))        //hold goes back one
      gaugeSkip(dataOrder1, false);
   
    if (btnRelease(btnTopRight))
      gaugeSkip(dataOrder2, true);
    if (btnHold(btnTopRight))
      gaugeSkip(dataOrder2, false);

    if (btnRelease(btnBottomLeft))
      gaugeSkip(dataOrder3, true);
    if (btnHold(btnBottomLeft))
      gaugeSkip(dataOrder3, false);
      
    if (btnRelease(btnBottomRight))
      gaugeSkip(dataOrder4, true);
    if (btnHold(btnBottomRight))
      gaugeSkip(dataOrder4, false);
    
  if (updateTimedScreen == true || updateScreen > 0){ //adds delay while still allowing buttons to registure      
    lcd.setCursor(0,0);               //set gauge start position
    dataArray[dataOrder1]();          //prints selected data from the Array
    lcd.setCursor(8,0);
    dataArray[dataOrder2]();          //Note lcd print commands are already in the gauge functions
    lcd.setCursor(0,1);
    dataArray[dataOrder3]();
    lcd.setCursor(8,1);
    dataArray[dataOrder4]();
    celStarPrint();                   //print cel starts if nessisary
  }
      
    EEPROM.update(EEdataOrder1, dataOrder1); //Updates EEPROM value to counter value if it has changed
    EEPROM.update(EEdataOrder2, dataOrder2); //EEPROM has limited lifecycle so (update) is more efficent then (write)
    EEPROM.update(EEdataOrder3, dataOrder3);
    EEPROM.update(EEdataOrder4, dataOrder4);
    
  break;
  case CELMenu:// Master Codes List Screen******************************************************************************
  /*
   * Master code lists
   * REM Codes
   * ECU Codes
   * TCU Codes
   * ABS Codes
   */
//Button Commands
    if (btnCheck(btnTopLeft))
      menuOrder = Home;

    if (btnCheck(btnBottomLeft))
      celExpandFlag = !celExpandFlag;
      
    if (btnRepeat(btnTopRight) && listCursor > 1)
      --listCursorMove;
      
    if (btnRepeat(btnBottomRight))
      ++listCursorMove;

//Full Screen Refresh 
    if (updateScreen > 0){
      lcd.clear();
      upDownArrows();
    }

//List Printing Code  
    if (updateTimedScreen == true || updateScreen > 0){
      
    //Active CEL Blink Code
      static unsigned long blinkyTimer;
      //static bool celBlinkyFlag;
      
      if (millis() > blinkyTimer + 225){ //current code blink timer
        celBlinkyFlag = !celBlinkyFlag;
        blinkyTimer = millis();
      }
      
      
      listReset();
      
      lcd.setCursor(0,0);
        
    //REM Codes **********************************************************************************************
      if (listCheck() == true){
        lcd.print("<--REM CODES---*");}

      prevCursorBlock = listCursor; //used to show "no faults" message later

      //bitSet(celBitmapArray[MAPL], 4); //CEL testing code
      //celFaultArray[MAPL] = 1;
      //celFaultArray[MAPH] = 1;
      
      listCEL(MAPL, "MAP Sensor Low");
      listCEL(MAPH, "MAP Sensor High");
      listCEL(BARL, "Baro Presur Low");

      listCEL(CTSL, "Water Temp Low");
      listCEL(CTSH, "Water Temp High");

      listCEL(IATL, "Air Temp Low");
      listCEL(IATH, "Air Temp High");

      listCEL(VoltL, "Bat Voltage Low");
      listCEL(VoltH, "Bat Voltage High");
      listCEL(CrankVL, "Batt Crank Weak");

      listCEL(o2L, "o2 Sensor Low");
      listCEL(o2H, "o2 Sensor High");
      listCEL(o2HeatL, "o2 HeaterV Low");

      listCEL(stftL, "Loop Fault Rich");
      listCEL(stftH, "Loop Fault Lean");

      listCEL(RPMD, "CPS Crank Fault");
      listCEL(RPML, "RPM Idle Low");
      listCEL(RPMH, "RPM Over Rev");

      listCEL(TPSL, "TPS Too Low");
      listCEL(TPSH, "TPS Too High");

      listCEL(KnockH, "Knock Too High");
      listCEL(KnockD, "Knock Snsr Fault");

      listCEL(SyncD, "Distributr Sync");
      listCEL(INJH, "Injectors Weak");

      if (listCursor == prevCursorBlock && listCheck()) //only shows if no extra list checks ran
        lcd.print(" No REM Codes!");

      if (listCheck() == true){}

  //ECU Codes**************************************************************************************************
      if (listCheck() == true){
        lcd.print("*--ECU CODES--*");}

      prevCursorBlock = listCursor; //used to show "no faults" message later

      ecuCodeList(); //ECU Code list function, brain managment to prevent fragmented lists

      if (listCursor == prevCursorBlock && listCheck()) //only shows if no extra list checks ran
        lcd.print(" No ECU Codes!");
        
      if (listCheck() == true){}
      
    //TCU Codes *****************************************************************************************************
      if (listCheck() == true){
        lcd.print("*--TCU CODES--*");}

      prevCursorBlock = listCursor; //used to show "no faults" message later
      //SolenoidFaults = 32; //fault test
      //TPSFaults = 255; //fault test
      
      if (transType == true)
      {
        listTCU(bitRead(SolenoidFaults, 1), bitRead(SolenoidFaults, 5), "700 Solenoid 1");
        listTCU(bitRead(SolenoidFaults, 2), bitRead(SolenoidFaults, 6), "700 Solenoid 2");
        listTCU(bitRead(SolenoidFaults, 3), bitRead(SolenoidFaults, 7), "700 Solenoid 3");
        listTCU(bitRead(TPSFaults, 0), bitRead(TPSFaults, 0), "705 TPS Fault");
        /* 
        listError(bitRead(SolenoidFaults, 5), "700 Sol1 Current");
        listError(bitRead(SolenoidFaults, 6), "700 Sol2 Current");
        listError(bitRead(SolenoidFaults, 7), "700 Sol3 Current");
        listError(bitRead(SolenoidFaults, 1), "700 Sol 1 Stored");
        listError(bitRead(SolenoidFaults, 2), "700 Sol 2 Stored");
        listError(bitRead(SolenoidFaults, 3), "700 Sol 3 Stored");
        listError(bitRead(TPSFaults, 0), "705 TPS Fault");            
        */
        if (listCursor == prevCursorBlock && listCheck()) //only shows if no extra list checks ran
          lcd.print(" No TCU Codes!");
      }
      else
      {
        if (listCheck() == true)
          lcd.print(" Not Available");
      }
        
      if (listCheck() == true){}

    //ABS Codes *************************************************************************************************
      if (listCheck() == true){
        lcd.print("*--ABS CODES--*");
      }
      //dataStream[13] = 255; //testing
      prevCursorBlock = listCursor; //used to show no fault message later
      
      absCodeList(); //ABS Code list function, brain managment to prevent fragmented lists
      
      if (listCursor == prevCursorBlock && listCheck()) //only shows if no extra list checks ran
        lcd.print(" No ABS Codes!");
        
      //if (listCheck() == true){} //helpful to show end of list gap
    }
  break;
  case ECUErrors://REM Error Display Screen*****************************************************************************
    diagnoseMode = 0; //reset menu to prevent looping

    if (updateTimedScreen == true || updateScreen > 0){
      
      lcd.clear();
        
      upDownArrows();
    
      listCursor = 0 - listCursorMove;  
      
      if (listCheck()){
        leftArrow();
        lcd.print(F("ECU Errors:"));
        lcd.print(countCELCode(true));
        lcd.print("/");
        lcd.print(countCELCode(false));
      }
    
        if (countCELCode(true) == 0 && countCELCode(false) == 0 && listCheck()){
          lcd.print(F("No Codes Found"));
          celExpandFlag = false; //reset to prevent menu glitches
        }
/*
     MAPL         = 0;        2     2s
1052 MAPH         = 1;        253   2s
     BARL         = 2;        85    2s
1054 CTSL         = 3;        2     2s
1055 CTSH         = 4;  245   253   2s           
1016 IATL         = 5;        2     2s
1017 IATH         = 6;  232   253   2s
1004 VoltL        = 7;  12.6  12.0  15s    
     VoltH        = 8;  15    15.5  15s
     CrankVL      = 9;        10.0  2s
1065 o2L          = 10;       2     45s
1066 o2H          = 11;       253   45s
1002 o2HeatL      = 12;       10.0  5s
     stftL        = 13;       2     1s
     stftH        = 14;       253   1s
     RPMD         = 15;       0     3s
1050 RPML         = 16;       500   5s
1051 RPMH         = 16;       2000  5s?
     RPMH         = 17;       5020  2s
1037 TPSL         = 18; 25    2     2s
     TPSH         = 19; 245   253   2s
1058 KnockH       = 20; 100   240   1s
     KnockD       = 21;       0     30s
1020 SyncD        = 22;       0     10s
     INJH         = 23; 80          1s
     */
        
        listError(countCELCode(false), "*Stored Codes*");         //print stored error codes, print first for less menu bounce

        listError(checkCELCode(MAPL, false), "MAP Sensor Low");
        listError(checkCELCode(MAPH, false), "MAP Sensor High");
        listError(checkCELCode(BARL, false), "Baro Presur Low");

        listError(checkCELCode(CTSL, false), "Water Temp Low");
        listError(checkCELCode(CTSH, false), "Water Temp High");

        listError(checkCELCode(IATL, false), "Air Temp Low");
        listError(checkCELCode(IATH, false), "Air Temp High");

        listError(checkCELCode(VoltL, false), "Bat Voltage Low");
        listError(checkCELCode(VoltH, false), "Bat Voltage High");
        listError(checkCELCode(CrankVL, false), "Batt Crank Weak");

        listError(checkCELCode(o2L, false), "o2 Sensor Low");
        listError(checkCELCode(o2H, false), "o2 Sensor High");
        listError(checkCELCode(o2HeatL, false), "o2 HeaterV Low");

        listError(checkCELCode(stftL, false), "Loop Fault Rich");
        listError(checkCELCode(stftH, false), "Loop Fault Lean");

        listError(checkCELCode(RPMD, false), "CPS Crank Fault");
        listError(checkCELCode(RPML, false), "RPM Idle Low");
        listError(checkCELCode(RPMH, false), "RPM Over Rev");

        listError(checkCELCode(TPSL, false), "TPS Too Low");
        listError(checkCELCode(TPSH, false), "TPS Too High");

        listError(checkCELCode(KnockH, false), "Knock Too High");
        listError(checkCELCode(KnockD, false), "Knock Snsr Fault");

        listError(checkCELCode(SyncD, false), "Distributr Sync");
        listError(checkCELCode(INJH, false), "Injectors Weak");

        
                                                                        //print current error codes
        listError(countCELCode(true), "*Current Codes*");

        listError(checkCELCode(MAPL, true), "MAP Sensor Low");
        listError(checkCELCode(MAPH, true), "MAP Sensor High");
        listError(checkCELCode(BARL, true), "Baro Presur Low");

        listError(checkCELCode(CTSL, true), "Water Temp Low");
        listError(checkCELCode(CTSH, true), "Water Temp High");

        listError(checkCELCode(IATL, true), "Air Temp Low");
        listError(checkCELCode(IATH, true), "Air Temp High");

        listError(checkCELCode(VoltL, true), "Bat Voltage Low");
        listError(checkCELCode(VoltH, true), "Bat Voltage High");
        listError(checkCELCode(CrankVL, true), "Batt Crank Weak");

        listError(checkCELCode(o2L, true), "o2 Sensor Low");
        listError(checkCELCode(o2H, true), "o2 Sensor High");
        listError(checkCELCode(o2HeatL, true), "o2 HeaterV Low");

        listError(checkCELCode(stftL, true), "Loop Fault Rich");
        listError(checkCELCode(stftH, true), "Loop Fault Lean");

        listError(checkCELCode(RPMD, true), "CPS Crank Fault");
        listError(checkCELCode(RPML, true), "RPM Idle Low");
        listError(checkCELCode(RPMH, true), "RPM Over Rev");

        listError(checkCELCode(TPSL, true), "TPS Too Low");
        listError(checkCELCode(TPSH, true), "TPS Too High");

        listError(checkCELCode(KnockH, true), "Knock Too High");
        listError(checkCELCode(KnockD, true), "Knock Snsr Fault");

        listError(checkCELCode(SyncD, true), "Distributr Sync");
        listError(checkCELCode(INJH, true), "Injectors Weak");


        if (listCheck() == true){} //helpful to show end of list gap     
    }

      if (listCursorMove == 1)
        celExpandFlag = false; //reset to prevent menu glitches
 

      if (btnCheck(btnTopLeft))
        menuOrder = Diagnose;

      if (btnCheck(btnBottomLeft))
        celExpandFlag = !celExpandFlag;
        
      if (btnCheck(btnTopRight))
        --listCursorMove;
        
      if (btnCheck(btnBottomRight) &&  listCursor > 1)
        ++listCursorMove;

    listCursorMove = constrain(listCursorMove, 1, 40); 
  break;
  case DiagnoseMenu: //***************************************************************************************
    if (btnCheck(btnTopLeft))
      menuOrder = SensorList;

    if (btnCheck(btnTopRight))
      menuOrder = SensorTestMenu;

    if (btnCheck(btnBottomLeft))
      menuOrder = Diagnose;

    if (btnCheck(btnBottomRight))
      menuOrder = TCUGauges;//NoStartMenu;

    if (updateScreen > 0){
      lcd.clear();
      lcd.print("Readings   Tests");
      lcd.setCursor(0,1);
      lcd.print("Pages   AW-4 TCU");
    }
    
  break;
  case DMMmenu: //***************************************************************************************
    static bool menuAdvance2 = false;
    static bool showVolts = true; //menu display
    static bool pauseRead = false;
    static bool resetRead = false;
    static float dmmRead = 0;
    static float voltMax = 0;
    static float ohmMax = 0; 

    if (updateScreen == menu){
      menuAdvance2 = false;
      pauseRead = false;
    }
    
    if (btnCheck(btnTopLeft))
      menuOrder = SensorTestMenu;

    if (btnCheck(btnTopRight))
      resetRead = !resetRead; 

    if (btnCheck(btnBottomLeft))
      showVolts = !showVolts;

    if (btnCheck(btnBottomRight)){
      if (menuAdvance2 == false)
        menuAdvance2 = true;
      else
        pauseRead = !pauseRead;
    }

      //Volts Ohms Signal

    if (updateScreen > 0 || updateTimedScreen == true){
      if (menuAdvance2 == false){
        lcd.setCursor(0,0);
        lcd.print("Set REM SW1&3 UP");
        lcd.setCursor(0,1);
        lcd.print("+ DMM Adptr SW >");
      }
      else {
        if (pauseRead == true)
          break;
        lcd.clear();
        lcd.print("^");
        lcd.setCursor(0,1);
        lcd.print(">");
        lcd.setCursor(2,0);
        
        if (showVolts == true){
          dmmRead = getVoltage(port1);
          if (dmmRead > voltMax || resetRead == true)
             voltMax = dmmRead;
             
          lcd.print("Volts Max");
          floatPrint(voltMax, 5, 2);
             
          lcd.setCursor(1,1);
          floatPrint(dmmRead, 5, 2);
          lcd.print("V ");
          printLongScroll(dmmRead, 0, 15, 8, 1, 8);
        }
        else{
          dmmRead = getResistance(port3);
          if ((dmmRead > ohmMax && dmmRead < 200000) || resetRead == true){
            if (resetRead == true)
              ohmMax = 0;
            else  
              ohmMax = dmmRead;
          }
             
          lcd.print("Ohms Max");
          intPrint(ohmMax, 6);
          
          lcd.setCursor(1,1);
          if (dmmRead > 200000)
            lcd.print(" O.L. ");
          else
            intPrint(dmmRead, 6);
          lcd.write(B11110100);
          
          if (dmmRead > 200000)
            dmmRead = 0;
          printLongScroll(dmmRead, 0, 100000, 8, 1, 8);
        }
        resetRead = false;
      }
    }
  break;
  case SensorTestMenu: //*********************************************************************************************
    static byte index2 = 1;           //selection menu scroll var
    static byte testerMenuIndex = 0;  //master list selection var
    static bool menuAdvance = false;  //show intial text var

    if (updateScreen == menu){
      testerMenuIndex = 0; //resets to main menu
      index2 = 1;
      menuAdvance = false;
      sigOutOverride = false; //safegaurd incase it gets stuck
    } 
     
    switch (testerMenuIndex){
      case 0: //Main Menu******************************************************
        if (btnCheck(btnTopRight))
          --index2;
        if (btnCheck(btnBottomRight))
          ++index2;
        
        rollover(index2, 1, 6);
        
        if (btnCheck(btnTopLeft))
          testerMenuIndex = index2; //updates to new sub menu
  
        menuAdvance = false; //reset
          
        if (updateScreen > 0){
          lcd.clear();
  
          rightArrow();
          upDownArrows();
          
          scrollPrint(1, "Engine No-Start", index2);
          scrollPrint(2, "TPS Alignment", index2);
          scrollPrint(3, "NSS Alignment", index2);
          scrollPrint(4, "Wideband Sync", index2);
          scrollPrint(5, "DMM Meter", index2);
          scrollPrint(6, "Back", index2);
        }
      break;
      case 1: //Engine No-Start Tester*****************************************
        menuOrder = NoStartMenu;
      break;
      case 2: //TPS Alignment Tester*******************************************
        if (btnCheck(btnTopLeft))
          testerMenuIndex = 0;
        if (btnCheck(btnBottomRight) && menuAdvance == false)
          menuAdvance = true;
           
        if (updateScreen > 0 || (updateTimedScreen == true && menuAdvance == true)){      
          lcd.clear();
          
          if (menuAdvance == false){
            lcd.print(" Adjust TPS");
            lcd.setCursor(0,1);
            lcd.print(" to 17%    >Next");
          }
          else {
            lcd.print("TCU: ");
            //tcuTPS = 7;
            for (byte temp = 0; temp < 8; temp++){
              if (tcuTPS > temp)
                lcd.write(255);
              else
                lcd.print(" ");
            }
            //tcuTPS = 1; //test
            intPrint(tcuTPS * 14, 2);
            lcd.print("%");
            
            lcd.setCursor(0,1);
            lcd.print("ECU: ");
            
            //dataStream[12] = 20; //test
            byte tempTPS = dataStream[12] / 35;
            for (byte temp = 0; temp < 8; temp++){
              if (tempTPS > temp)
                lcd.write(255);
            }
    
            byte TPSsymbol[8]=
            {
              B00000,
              B00000,
              B00000,
              B00000,
              B00000,
              B00000,
              B00000
            };
            
            byte TPSdraw = dataStream[12] - (tempTPS * 35); //find remainder
            //TPSdraw /= 7; //cut into 5 bits
            //TPSdraw = 2;
            
            for (byte inc = 0; inc < 5; inc++)
            {
              byte incHolder = 4 - inc; //invert
              if (TPSdraw > 0){
                bitSet(TPSsymbol[7], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[6], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[5], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[4], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[3], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[2], incHolder);
                --TPSdraw;
              }
              else break;
              if (TPSdraw > 0){
                bitSet(TPSsymbol[1], incHolder);
                --TPSdraw;
              }
              else break;
              /*if (TPSdraw > 0){  
                bitSet(TPSsymbol[0], incHolder);
                --TPSdraw;
              }
              else break;*/
            }
            
            lcd.write(4);
            lcd.createChar(4, TPSsymbol);//update after to preserve cursor
            
            lcd.setCursor(13,1);
            intPrint(TPS,2);
            lcd.print("%");
          }  
        }
      break;
      case 3: //NSS Halves Alignment Tester**********************************
        if (btnCheck(btnTopLeft))
          testerMenuIndex = 0;
        if (btnCheck(btnBottomRight) && menuAdvance == false)
          menuAdvance = true;
           
        if (updateScreen > 0 || (updateTimedScreen == true && menuAdvance == true)){      
          lcd.createChar(6, rightLine);
          lcd.createChar(7, leftLine);
          lcd.clear();
    
          if (menuAdvance == false){
            lcd.print(" Adjust NSS in");
            lcd.setCursor(0,1);
            lcd.print(" Neutral.  >Next");
          }
    
          else {
            static bool oldNSS = NSS;
            static byte oldPRNDL = tcuPRNDL;
            static byte testBitmap = 0;
    
            if (NSS != oldNSS)
              bitSet(testBitmap, 0);
    
            if (oldPRNDL != tcuPRNDL && tcuPRNDL == 3)
              bitSet(testBitmap, 1);
              
            if (oldPRNDL != tcuPRNDL && tcuPRNDL == 1)
              bitSet(testBitmap, 2);
    
            oldPRNDL = tcuPRNDL;
    
            lcd.print("< NSS Test: ");
            bitPrint(testBitmap);
            lcd.print("/3");
              
            lcd.setCursor(0,1);
            lcd.print("  P R N D 3 1-2");
      
            if (tcuPRNDL == 4){
              if (NSS == true){   //R-D
                circlePrint(3,5);
                circlePrint(7,9);
              }
              else{               //P-N
                circlePrint(1,3);
                circlePrint(5,7);
              }
            }
            if (tcuPRNDL == 3)    //D3
              circlePrint(9,11);
            if (tcuPRNDL == 1)    //D1-2
              circlePrint(11,15);
          }
        }
      break;
      case 4: //Wideband Signal Output to Input Sync Tester*******************
        if (btnCheck(btnTopLeft))
          testerMenuIndex = 0;
        if (btnCheck(btnBottomRight) && menuAdvance == false)
          menuAdvance = true;
           
        //if (updateScreen > 0 || (updateTimedScreen == true && menuAdvance == true)){  
          //lcd.clear();
        
        if (menuAdvance == false){
          if (updateScreen > 0){
            lcd.clear();
            lcd.print("Test REM Signal ");
            lcd.setCursor(0,1);
            lcd.print("o2 Tuner.  >Next");
          }
        }
        else {
          if (btnCheck(btnTopRight))
            sigOutOverride = !sigOutOverride;
        
                
          static unsigned long ADDtimer;
          static byte ADD = 232; //233 = 5.00v, ecurev = 4.98v
          static bool ADDflip;
          
          if (millis() > ADDtimer + 30 && sigOutOverride == true)
          {
            ADDtimer = millis();
            
            if (ADD > 231)
              ADDflip = true;
            if (ADD < 1)
              ADDflip = false;
          
            if (ADDflip == true)
              ADD--;
            else ADD++;
            
            analogWrite(A14, ADD);
          
            //Serial.print(millis());
            //Serial.print(" ");
            //Serial.println(ADD * 255 / 232);
          }
      
          if (updateScreen > 0 || updateTimedScreen == true){
            float dacVRead;
            lcd.clear();
//Lambda = 2.5;//test
            lcd.setCursor(10,0);
            if (sigOutOverride == false){
              lcd.print("Test?>");
              dacVRead = o2DAC * 4.98 / 233;
            }
            else{
              lcd.print("Stop?>");
              dacVRead = ADD * 4.98 / 233;
            }
            lcd.setCursor(0,1);
            floatPrint(dacVRead, 4, 2);
            lcd.print("Vout ");
            floatPrint(Lambda, 4, 2);
            lcd.print("Vin");

            float o2Compare;
            o2Compare = 100 + ((Lambda-dacVRead) / 5 * 100); //difference between in to out converted to 100%
//RPM = 1000;//test
            
            lcd.setCursor(0,0);
            if (RPM < 400)
              lcd.print("*Start Engine!*>");
            else{
              intPrint(o2Compare, 3);
              lcd.print("%");
              if (o2Compare < 97 || o2Compare > 103)
                lcd.print(":FAIL");
              else
                lcd.print(":PASS");
            }
          }
        }
      break;
      case 5: //DMM Meter*************************************
        menuOrder = DMMmenu;
      break; 
      case 6: //Back******************************************
        menuOrder = DiagnoseMenu;
      break;
    }
  break;
  case NoStartMenu: //*********************************************************************************************************
    static bool dizzyTrip;
    static unsigned long dizzyTimer;

    EEPROM.update(EEnoStartOverride, true); //forces menu to show first incase power is lost temporarily    
    
    if (dizzyCEL == false)
      dizzyTimer = millis();
      
    if (millis() > dizzyTimer + 2000)
      dizzyTrip = true;
    else
      dizzyTrip = false;

      
    if (btnCheck(btnTopLeft))
      menuOrder = SensorTestMenu;
    if (btnRepeat(btnTopRight))
      --listCursorMove;
    if (btnRepeat(btnBottomRight))
      ++listCursorMove;

    static byte noStartArray[7];
    
    if (btnCheck(btnBottomLeft)){
      for (byte i = 0; i < 7; i++){
        noStartArray[i] = 0; //reset 
      }
    }

    if (ecuStreamUpdate == true){
      if (bitRead(dataStream[29], 4) == true && noStartArray[0] < 5){ //False = No Starter Signal
        noStartArray[0] += 1; 
      }
      if (Volts > 9.4 && noStartArray[1] < 5){ //Battery Voltage drops under 10
        noStartArray[1] += 1; 
      }
      if (RPM > 350 && noStartArray[2] < 5){ //RPM too Low or zero
        noStartArray[2] += 1; 
      }
      if (InjPulse > 1.0 && noStartArray[3] < 5){ //Injector pulse too low
        noStartArray[3] += 1; 
      }
      if (SparkADV > 2 && noStartArray[4] < 5){ //Spark Advance too low?
        noStartArray[4] += 1; 
      }
      if (dizzyTrip == false && noStartArray[5] < 5){ //No Dizzy Movement?
        noStartArray[5] += 1; 
      }
      if (MAP < Baro && noStartArray[6] < 5){ //No Cranking Vacuum 
        noStartArray[6] += 1; 
      }
    }
      
    if (updateTimedScreen == true || updateScreen > 0){
      listReset();
      
      lcd.clear();

      upDownArrows();

      if (listCheck() == true){
        leftArrow();
        floatPrint(Volts, 4, 1);
        lcd.print("V");
        intPrint(RPM, 4);
        lcd.print("R");
        floatPrint(InjPulse, 4, 1);
        lcd.print("I");
      }

      if (listCheck() == true){
        //lcd.setCursor(1,1);                   //X if True
        lcd.print(" |");
        tPrint('I', !bitRead(dataStream[30], 0));  //False = ICM Fault
        tPrint('P', bitRead(dataStream[29], 7));   //True = NSS Drive/Reverse
        tPrint('S', !bitRead(dataStream[29], 4));  //False = No Starter Signal
        tPrint('C', !bitRead(dataStream[17], 6));  //False = Not in Cranking Mode
        tPrint('B', BaroRaw < 85 || BaroRaw > 253);//Baro Too Low or Maxed
        tPrint('V', Volts < 9.0);                 //Battery Voltage drops under 10
        tPrint('R', RPM < 350);                    //RPM too Low or zero
        tPrint('i', InjPulse < 1.0);               //Injector pulse too low
        tPrint('A', SparkADV < 2);                 //Spark Advance too low?
        tPrint('D', dizzyTrip);                    //No Dizzy Movement?
        tPrint('v', MAP >= Baro);                  //No Cranking Vacuum 
        tPrint('m', bitRead(dataStream[17], 2));   //True = Engine Off Mode
        lcd.print("|");
      }

      prevCursorBlock = listCursor; //saves current list value for "No Show" messages if no other checks pass
 
      listError(!bitRead(dataStream[30], 0), "ICM Signal Fault"); //False = ICM Fault
     
      listError(bitRead(dataStream[29], 7), "Not in Park/Neutral"); //True = NSS Drive/Reverse
      
      listError(noStartArray[0] < 5,"No Starter Sig"); //False = No Starter Signal
      
      listError(BaroRaw < 85 || BaroRaw > 253, "Baro OutOf Range"); //Baro Too Low or Maxed
      
      listError(noStartArray[1] < 5, "Low Crank Volts");
      
      listError(noStartArray[2] < 5, "No CPS Signal");
      
      listError(noStartArray[3] < 5, "No Injectr Pulse");
      
      listError(noStartArray[4] < 5, "No Spark Advance");
      
      listError(noStartArray[5] < 5, "No Distrib Sig");
      
      listError(noStartArray[6] < 5, "No MAP Vacuum");

      if (listCursor == prevCursorBlock && listCheck()){ //"No Show" message if no extra list checks ran
        lcd.print("No Faults Found");
      }

      if (listCursor == listCursorMove && listCheck() == true){
        lcd.print("< Reset");
      }
      
    }
  break;
  case SensorList: //***************************************************************************************
    if (updateScreen == menu) //resets to bring you back to main menu
      sensorMenu = 0;
      
    if (sensorMenu == 0){
      //listCursorMove = 1; //reset
      
      if (btnCheck(btnTopLeft))
        menuOrder = DiagnoseMenu;

      if (btnCheck(btnTopRight))
        sensorMenu = engine;

      if (btnCheck(btnBottomLeft))
        sensorMenu = 3; //ABS

      if (btnCheck(btnBottomRight))
        sensorMenu = 1; //TCU
    }
    else{
      if (btnCheck(btnTopLeft))
        sensorMenu = 0;
      if (btnRepeat(btnTopRight))
        --listCursorMove;
      if (btnRepeat(btnBottomRight))// &&  listCursor > 1)
        ++listCursorMove;
    }
    
     
    
    if (updateTimedScreen == true || updateScreen > 0){
      //listCursor = 0 - listCursorMove; 
      listReset();
      lcd.clear();
      
      /*  
        ________________
        B1143FFEFDF3PROM
         1.23V       MAP
         12.3"hG     MAP
         12.3"hG  Vacuum
         12.3"hG    Baro
         123F    Coolant
         123F Intake Air
         12.3V   Battery
         1.23V  o2 Bank1
         1234 Engine RPM
         1.23V       TPS
         12%    Throttle
         12º Spark Advnc
         Closed Exh Loop
         Lean    Exhaust
         Off  EGR Solend
         12.3mS Inj Puls
         Partial Throttl
         + 0 Distributor
         123 Short FTrim
         123  Long FTrim
         123  Knock Sens
         Off  A/C Switch
         Yes A/C Request
         Drive/Rever NSS

        ________________
         82.3MPH LFWheel
         82.3MPH RFWheel
         82.3MPH LRWheel
         82.3MPH RRWheel
        BuildDecay LFSol
        BuildDecay RFSol
        BuildDecay  RSol
        Closed   GSwitch
        Closed DiffPress
        Closed BoostPres
        Yes    Low Accum
        Off     ABS Pump
        Yes ModulatorRly
        Yes Sol Undrvolt
        Yes P-Brk Lo Flu
        Yes    ABS Brake


        
                                        ________________*/
        if (sensorMenu != 0){                                
          upDownArrows();
        }
            
        switch(sensorMenu)
        {
          default: //Selection Menu
            lcd.print("Back      Engine");
            lcd.setCursor(0,1);
            lcd.print("ABS   Auto Trans");  
          break;
          case 2: //2.5L Engine ***********************
            if (listCheck() == true){
              lcd.print("<---ECU DATA---*");}

            if (listCheck() == true){
              floatPrint(Vacuum, 4, 1);
              lcd.print(" Vacuum ");
              printPressureText();}
              
            if (listCheck() == true){
              floatPrint(MAP, 4, 1);
              lcd.print("    MAP ");
              printPressureText();}

            if (listCheck() == true){
              float mapVolts = MAPRaw / 51.0;
              floatPrint(mapVolts, 4, 2);
              lcd.print("    MAP   V");} 
              
            if (listCheck() == true){
              floatPrint(Baro, 4, 1);
              lcd.print("   Baro ");
              printPressureText();}

            if (listCheck() == true){
              intPrint(CTS, 3);
              lcd.print(" Water Temp ");
              tempSymbol();}

            if (listCheck() == true){
              intPrint(IAT, 3);
              lcd.print("  Air Temp ");
              tempSymbol();}

            if (listCheck() == true){
              floatPrint(Volts, 4, 1);
              lcd.print("  Battery V");}

            if (listCheck() == true){
              intPrint(Lambda, 4);
              lcd.print(" Exhast o2mV");}

            if (listCheck() == true){
              if (Exhaust == true)
                lcd.print("Rich");
              else
                lcd.print("Lean");
              lcd.print("    Exhaust");}
              
            if (listCheck() == true){
              if (LoopStatus == Clsd)
                lcd.print("Closed");
              else if (LoopStatus == Dcel)
                lcd.print("Decel");
              else lcd.print("Open ");
              lcd.print(" Loop Mode");}

            if (listCheck() == true){
              ofPrint(EGR);
              lcd.print(" EGR Solenoid");}

            if (listCheck() == true){
              intPrint(engineRPM, 4);
              lcd.print(" Engine RPM");}

            if (listCheck() == true){
              intPrint(TPS, 2);
              lcd.print("   Throttle %");}

            if (listCheck() == true){
              float tpsVolts = dataStream[12] / 51.2;
              floatPrint(tpsVolts, 4, 2);
              lcd.print(" Throttle V");}

            if (listCheck() == true){
              if (ThrottleSwitch == Clsd)
                lcd.print("Closed");
              else if (ThrottleSwitch == WOT)
                lcd.print("WOT   ");
              else lcd.print("Part  ");
              lcd.print("TPS Switch");}

            if (listCheck() == true){
              floatPrint(mystery7, 4, 1);
              lcd.print(" Idle Offset");}

            if (listCheck() == true){
              ofPrint(PSSwitch);
              lcd.print(" Pwr/Steer Sw");}

            if (listCheck() == true){
              floatPrint(InjPulse, 4, 2);
              lcd.print(" Injector ms");}

            if (listCheck() == true){
              intPrint(STFT, 3);
              lcd.print(" Short TermFT");}

            if (listCheck() == true){
              intPrint(LTFT, 3);
              lcd.print(" Long Term FT");}

                
            if (listCheck() == true){
              intPrint(SparkADV, 3);
              lcd.print(" Spark Adv ");
              lcd.write(B11011111);}//degree


            if (listCheck() == true){
              ofPrint(Starter);
              lcd.print(" Starter Sig");}

            if (listCheck() == true){
              ynPrint(!NSS);
              lcd.print(" NSS Prk/Neu");}

            if (listCheck() == true){
              ofPrint(ACSwitch);
              lcd.print(" A/C Select");}

            if (listCheck() == true){
              ynPrint(ACRequest);
              lcd.print(" A/C Request");}

            if (listCheck() == true){
              ofPrint(ACClutch);
              lcd.print(" A/C Clutch");}

            if (listCheck() == true){
              displayPROM();
              lcd.print("        PROM");  
            }

            //if (listCheck() == true){}
          break;
          case 4: //4.0L Engine ***********************            
            if (listCheck() == true){
              lcd.print("<---ECU DATA---*");}

            if (listCheck() == true){
              floatPrint(Vacuum, 4, 1);
              lcd.print(" Vacuum ");
              printPressureText();}
              
            if (listCheck() == true){
              floatPrint(MAP, 4, 1);
              lcd.print("    MAP ");
              printPressureText();}

            if (listCheck() == true){
              float mapVolts = MAPRaw / 51.0;
              floatPrint(mapVolts, 4, 2);
              lcd.print("    MAP   V");}                   
              
            if (listCheck() == true){
              floatPrint(Baro, 4, 1);
              lcd.print("   Baro ");
              printPressureText();}

            if (listCheck() == true){
              intPrint(CTS, 3);
              lcd.print(" Water Temp ");
              tempSymbol();}

            if (listCheck() == true){
              intPrint(IAT, 3);
              lcd.print("  Air Temp ");
              tempSymbol();}

            if (listCheck() == true){
              floatPrint(Volts, 4, 1);
              lcd.print("  Battery V");}

            if (listCheck() == true){
              floatPrint(LambdaHeater, 4, 1);
              lcd.print(" o2 Heater V");}
            
            if (listCheck() == true){
              floatPrint(Lambda, 4, 2);
              lcd.print("   Oxygen V");}//Exhaust o2V

            if (listCheck() == true){
              if (EEPROM.read(EEwidebandPin) == 0){ //Fake AFR from Inverse of L/(1+e^(-k*(x-x0))) 
                floatPrint(estAFR, 4, 1);
              }
              else{
                if (AFRV < 0.5 && smartWideband()) //special math for AEM X Series Errors
                  lcd.print("HEAT");
                else if (AFRV > 4.5 && smartWideband())
                  lcd.print("ERRO");
                else
                  floatPrint(AFR, 4, 1);
              }
              lcd.print("   Air/Fuel");}//Exhaust o2V

            if (listCheck() == true){
              if (Exhaust == true)
                lcd.print("Rich");
              else
                lcd.print("Lean");
              lcd.print("   Exhaust");}
              
            if (listCheck() == true){
              if (LoopStatus == Clsd)
                lcd.print("Closed");
              else if (LoopStatus == Dcel)
                lcd.print("Decel ");
              else lcd.print("Open  ");
              lcd.print(" Exh Loop");}

            if (listCheck() == true){
              ofPrint(EGR);
              lcd.print(" EGR Solenoid");}

            if (listCheck() == true){
              intPrint(engineRPM, 4);
              lcd.print(" Engine RPM");}

            if (listCheck() == true){
              if (IACtimer + 500 > millis()){ //display for minimum time 
                if (IACdir == true)
                  lcd.print(">"); //open
                else
                  lcd.print("<"); //closed
              }
              else lcd.print(" ");
              intPrint(IAC, 3);
              lcd.print("  IAC Turns");}

            if (listCheck() == true){
              intPrint(TPS, 2);
              lcd.print("   Throttle %");}

            if (listCheck() == true){
              float tpsVolts = dataStream[12] / 51.2;
              floatPrint(tpsVolts, 4, 2);
              lcd.print(" Throttle V");}

            if (listCheck() == true){
              if (ThrottleSwitch == Clsd)
                   lcd.print("Closed ");
              else if (ThrottleSwitch == WOT)
                   lcd.print("WOT    ");
              else lcd.print("Part   ");
              lcd.print("TPS Mode");}

            if (listCheck() == true){
              floatPrint(InjPulse, 4, 1);
              lcd.print(" Injector ms");}

            if (listCheck() == true){
              floatPrint(mystery6, 4, 1);
              lcd.print(" Cold Enrich");}

            if (listCheck() == true){
              intPrint(STFT, 3);
              lcd.print(" Short TermFT");}

            if (listCheck() == true){
              intPrint(LTFT, 3);
              lcd.print(" Long Term FT");}

            if (listCheck() == true){
              intPrint(Knock, 3);
              lcd.print(" Knock Sensor");}
                
            if (listCheck() == true){
              intPrint(SparkADV, 3);
              lcd.print(" Spark Adv ");
              lcd.write(B11011111);}//degree

            if (listCheck() == true){
              /*if (bitRead(mystery5, 7) == true) //Knock Mask
                  lcd.print("K");
                else lcd.print(" ");
                */ 
                intPrint(SparkRTD, 3);           //M5 IGN Knock Mask
                lcd.print(" Spark Retard");}

            if (listCheck() == true){
              lcd.print("1");
              if (FuelSync == true)
                lcd.print("-");
              else
                lcd.print("+");
              lcd.write(2); 
              lcd.print(" Distributor");//Dis Fuel Sync
              createDizzyChar();}

            if (listCheck() == true){
              ofPrint(Starter);
              lcd.print(" Starter Sig");}

            if (listCheck() == true){
              ynPrint(!NSS);
              lcd.print(" NSS Prk/Neu");}

            if (listCheck() == true){
              ofPrint(ACSwitch);
              lcd.print(" A/C Select");}

            if (listCheck() == true){
              ynPrint(ACRequest);
              lcd.print(" A/C Request");}

            if (listCheck() == true){
              displayPROM();
              lcd.print(" ecu");  
            }

            if (listCheck() == true){
              lcd.print("*--ECU CODES---*");}

            ecuCodeList(); //keeps code updates tidy
            /*listError(!bitRead(dataStream[11], 2), "Injector 1 Open");
            listError(!bitRead(dataStream[11], 6), "Injector 2 Open");
            listError(!bitRead(dataStream[11], 4), "Injector 3 Open");
            listError(!bitRead(dataStream[11], 7), "Injector 4 Open");
            listError(!bitRead(dataStream[11], 3), "Injector 5 Open");
            listError(!bitRead(dataStream[11], 5), "Injector 6 Open");
            listError(bitRead(dataStream[20], 1), "Coolant Temp Sen");
            listError(bitRead(dataStream[30], 3), "Fuel Pump Relay");
            listError(!bitRead(dataStream[30], 0), "ICM Signal Open");
            listError(!bitRead(dataStream[30], 2), "EGR Soleno Open");
            listError(!bitRead(dataStream[30], 4), "B+ Relay Open");
            listError(!bitRead(dataStream[30], 5), "o2 Relay Open");
            listError(!bitRead(dataStream[30], 6), "A/C Relay Open");
*/
            //if (listCheck() == true){}
          break;
          case 1: //TCU *******************************
            if (listCheck() == true){
              lcd.print("<---TCU DATA---*");}

            if (transType == true)
            {
              if (listCheck() == true){
                lcd.print(tcuDataStream[0]);
                lcd.print("     Module ID");}
  
              if (listCheck() == true){
                lcd.print(tcuDataStream[1]);
                lcd.print("     TPS Steps");}
  
              if (listCheck() == true){
                intPrint(tcuRPM, 4);
                lcd.print(" Output RPM");}
  
              if (listCheck() == true){
                intPrint(MPH, 3);
                lcd.print("   Speed ");
                if (speedUnit == false)
                  lcd.print("KPH");
                else
                  lcd.print("MPH");}
  
              if (listCheck() == true){
                ofPrint(tcuBrake);
                lcd.print("    Brake Sw");}
              
              if (listCheck() == true){
                if (tcuMode == true)
                  lcd.print("Power  ");
                else
                  lcd.print("Comfort");
                  
                lcd.print(" Mode Sw");}
  
              if (listCheck() == true){
                switch(tcuPRNDL)
                {
                  case 1: //1-2
                    lcd.print("1-2 ");
                  break;
                  case 3: //3rd
                    lcd.print("D3  ");
                  break;
                  case 4: //PRND
                    lcd.print("PRND");
                  break;
                  default: //????
                    lcd.print("??? ");
                  break;
                }
                lcd.print("   PRNDL Sw");}
  
              if (listCheck() == true){
                ofPrint(solenoid1);
                lcd.print("  Solenoid 1");}
  
              if (listCheck() == true){
                ofPrint(solenoid2);
                lcd.print("  Solenoid 2");}
  
              if (listCheck() == true){
                ofPrint(solenoid3);
                lcd.print("  TC Lock-Up");}
  
              if (listCheck() == true){
                lcd.print(tcuGear);
                printNumText(tcuGear);
                lcd.print(" Current Gear");}
  
              if (listCheck() == true){
                ofPrint(tcuShiftLogic);
                lcd.print(" Shift Logic");}
  
              if (listCheck() == true){
                ofPrint(tcuMystery);
                lcd.print(" Mystery C12");}
  
              if (listCheck() == true){
                lcd.print("*--TCU CODES---*");}
  
              listError(bitRead(SolenoidFaults, 5), "700 Sol1 Current");
              listError(bitRead(SolenoidFaults, 6), "700 Sol2 Current");
              listError(bitRead(SolenoidFaults, 7), "700 Sol3 Current");
              listError(bitRead(SolenoidFaults, 1), "700 Sol 1 Stored");
              listError(bitRead(SolenoidFaults, 2), "700 Sol 2 Stored");
              listError(bitRead(SolenoidFaults, 3), "700 Sol 3 Stored");
              listError(bitRead(TPSFaults, 0), "705 TPS Fault");
            }
            else
            {
              if (listCheck() == true)
                lcd.print(" Not Available");
            }            

            //if (listCheck() == true){}
          break;
          case 3: //ABS*****************************
            if (listCheck() == true){
              lcd.print("<---ABS DATA---*");
            }

            if (engine == 3)
            {
              if (listCheck() == true){
                floatPrint(LFWheel, 4, 1);
                lcd.print("MPH LFWheel");
              }
              
              if (listCheck() == true){
                floatPrint(RFWheel, 4, 1);
                lcd.print("MPH RFWheel");
              }
      
              if (listCheck() == true){
                floatPrint(LRWheel, 4, 1);
                lcd.print("MPH LRWheel");
              }
      
              if (listCheck() == true){
                floatPrint(RRWheel, 4, 1);
                lcd.print("MPH RRWheel");
              }
              
              if (listCheck() == true){
                solenoidPrint(LFSolenoid);
                lcd.print(" LFSol");
              }
              
              if (listCheck() == true){
                solenoidPrint(RFSolenoid);
                lcd.print(" RFSol");
              }
      
              if (listCheck() == true){
                solenoidPrint(RearSolenoid);
                lcd.print("  RSol");
              }
      
              if (listCheck() == true){
                ocPrint(GSwitch);
                lcd.print("  GSwitch");
              }
      
              if (listCheck() == true){
                ocPrint(DiffPressure);
                lcd.print(" DiffPress");
              }
      
              if (listCheck() == true){
                ocPrint(BoostPressure);
                lcd.print(" BoostPres");
              }
      
              if (listCheck() == true){
                ofPrint(ABSPump);
                lcd.print("    ABS Pump");
              }
      
              if (listCheck() == true){
                ynPrint(ABSBrake);
                lcd.print("   ABS Brake");
              }
      
               if (listCheck() == true){
                ynPrint(LowAccum);
                lcd.print("   Low Accum");
              }
              
              if (listCheck() == true){
                ynPrint(ParkingBrakeFluidLow);
                lcd.print(" P-Brk Lo Flu");
              }       
      
              if (listCheck() == true){
                ynPrint(ModulatorRelay);
                lcd.print(" ModulatorRly");
              }
              
              if (listCheck() == true){
                ynPrint(SolenoidUndervolt);
                lcd.print(" Sol Undrvolt");
              }
  
              if (listCheck() == true){
                displayPROM();
                lcd.print("       PROM");  
              }
      
              if (listCheck() == true){
                lcd.print("*--ABS CODES---*");
              }

              absCodeList(); //displays full code list, keeps things tidy

            }
            else
            {
              if (listCheck() == true)
                lcd.print(" Not Available");
            }
            //if (listCheck() == true){} //helpful to show end of list gap
          break;
        }
    }
  break;
  case Diagnose://Diagnoses Screen***************************************************************************************    
    byte DiagTotal;
    if (EEPROM.read(EEwidebandPin) > 0)
      DiagTotal = 14;
    else DiagTotal = 13;
    celManualFlag = true; //disables Main CEL light trip code
      
    if (btnCheck(btnTopLeft)){ //info button
      if (diagnoseMinMax == 1)
        diagnoseMinMax = 3;
      else
        ++diagnoseMode; 
    }
    if (diagnoseMode > 3)
      diagnoseMode = 0;
      
    if (btnCheck(btnTopRight)) //scroll up
      --diagnoseMenu;
    if (diagnoseMenu < 1)
      diagnoseMenu = DiagTotal;
    if (diagnoseMenu == 9 && engine ==2)
      diagnoseMenu = 8;

    if (btnCheck(btnBottomLeft)) //min/max button
      ++diagnoseMinMax;
    if (diagnoseMinMax > 2)
      diagnoseMinMax = 0;
   
    if (btnCheck(btnBottomRight)) //scroll down
      ++diagnoseMenu;
    if (diagnoseMenu > DiagTotal)
      diagnoseMenu = 1;
    if (diagnoseMenu == 9 && engine ==2)
      diagnoseMenu = 10;
 

    if (updateScreen > 0){
        lcd.clear();

        lcd.setCursor(0,0);
        if (diagnoseMinMax == 1)
          lcd.print("r");
        else
          lcd.print("i");
        if (diagnoseMode == 0){//Normal Overlay
          lcd.setCursor(15,0);
          lcd.print("^");
          lcd.setCursor(0,1);
          lcd.print("m");
          lcd.setCursor(15,1);
          lcd.print("v");
        }
      }
      
    if (updateTimedScreen == true || updateScreen > 0){ //adds delay while still allowing buttons to registure  
      celOff();
    switch (diagnoseMenu){
      case 1://Errors***********************************************
        if (countCELCode(true) > 0)
            celOn();
        switch (diagnoseMode)
        {
          case 0://Readout            
            if (diagnoseMinMax == 3){
              resetCEL(true);     //reset current array checker
              resetCEL(false);     //reset prev array checker
              diagnoseMinMax = 1;
            }
              
            lcd.setCursor(3,0);
            lcd.print("REM Codes ");
            //lcd.print(engineRunCount); //test
            lcd.setCursor(2,1);
            lcd.print("Cur:");
            lcd.print(countCELCode(true));
            lcd.print(" Prev:");
            lcd.print(countCELCode(false));
          break;
          default:
            diagnoseMode = 0; //reset menu to prevent looping
            menuOrder = CELMenu;//ECUErrors;
          break;
          /*case 1://Description
            diagnoseMode = 0; //reset menu to prevent looping
            menuOrder = CELMenu;//ECUErrors;
          break;
          case 2://Location
            diagnoseMode = 0; //reset menu to prevent looping
            menuOrder = CELMenu;//ECUErrors;
          break;
          case 3://Pinout
            diagnoseMode = 0; //reset menu to prevent looping
            menuOrder = CELMenu;//ECUErrors;
          break;
          */
        }//diagnoseMode Switch Case end    
      break;
      case 2://MAP**************************************************
        if (engineRunFlag == true && MAPRaw >= BaroRaw)
            celOn();
        switch (diagnoseMode){//selects which main screen text to display
          case 0://Readout
            lcd.setCursor(2,0);
            lcd.print(((MAPRaw / 5.1)/10), 2);//MAPRaw/51 but byte variable can't do that correctly
            lcd.print("v");
            displayMAP();
          
          if (diagnoseMinMax == 3){//resets min an max values
            MAPMin = MAP;
            MAPMax = MAP;
            diagnoseMinMax = 1;
          }
          switch(diagnoseMinMax)
          {
            case 0: //normal
              lcd.setCursor(1,1);
              displayBaro();
              displayVacuum();
            break;
            case 1: //min/max
              lcd.setCursor(1,1);
              lcd.print(" Mn     Mx    ");
              lcd.setCursor(4,1);
              lcd.print(MAPMin,1);
              lcd.setCursor(11,1);
              lcd.print(MAPMax,1);
            break;
            case 2://graphing
              printLongScroll(MAPRaw, 0, 255, 4, 1, 8);
            break;
          }
          
          
            /*lcd.setCursor(5,0);
            displayMAP();
            lcd.setCursor(2,0);
            lcd.print(F("MAP"));
            lcd.setCursor(10,0);
            switch(pressureUnit)
            {
              case 1://Bars Calc
                lcd.print(F("Volts"));
                lcd.setCursor(2,1);
                lcd.print(F("Idle:1.0-4.0"));
              break;
              case 2://inHg
                lcd.print(F("\"Hg"));// the forwardslash allows the " to be printed without interpeting it as code
                lcd.setCursor(2,1);
                lcd.print(F("Idle: 10-25"));
              break;
              case 3://KPA
                lcd.print(F("kPa"));
                lcd.setCursor(2,1);
                lcd.print(F("Idle: 34-85"));
              break;
              case 4://PSI
                lcd.print(F("psi"));
                lcd.setCursor(2,1);
                lcd.print(F("Idle: 5-12"));
              break;
              }*/
          
          break;
          case 1://Description
            lcd.setCursor(1,0);
            lcd.print(F("Manifold Abso-"));
            lcd.setCursor(1,1);
            lcd.print(F("lute Pressure"));
          break;
          case 2://Location
            lcd.setCursor(3,0);
            lcd.print(F("Center of"));
            lcd.setCursor(4,1);
            lcd.print(F("Firewall"));
          break;
          case 3://Pinout
            lcd.setCursor(1,0);
            lcd.print("A:GND B:Output");
            lcd.setCursor(1,1);
            lcd.print("C:5V");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 3://CTS**************************************************
        if (CTS < -38 || CTS > 240)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(2,0);
            lcd.print(F("CTS"));
            
            intPrint(CTS, 4);
            tempSymbol();

            if (engine == 4)
            {
              lcd.print(" ");
              if (mystery2 < 10)
                lcd.print(" ");
              lcd.print("v");
              lcd.print(mystery2); //CTS offset to 212f?
            }            
            
            if (diagnoseMinMax == 3){
              CTSMin = CTS;
              CTSMax = CTS;
              diagnoseMinMax = 1;
            }
              
            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(2,1);
                if (tempUnit == false)
                  lcd.print(F("Norm: 80-105"));
                else
                  lcd.print(F("Norm:180-220"));
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(CTSMin);
                lcd.setCursor(11,1);
                lcd.print(CTSMax);
              break;
              case 2://graphing
                printLongScroll(CTSRaw, 0, 255, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Coolant Temp"));
            lcd.setCursor(2,1);
            lcd.print(F("/ Water Temp"));
          break;
          case 2://Location
            lcd.setCursor(2,0);
            lcd.print(F("Left Side of"));
            lcd.setCursor(1,1);
            if (engine == 2)
              lcd.print("Intake Manifold");
            else
              lcd.print(F(" Engine Block"));
          break;
          case 3://Pinout
            lcd.setCursor(1,0);
            lcd.print("A:GND B:Output");
            lcd.setCursor(1,1);
            lcd.print("100k - 0 Ohms");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 4://IAT**************************************************
        if (IATRaw < 2 || IATRaw > 200)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(2,0);
            lcd.print("IAT");
            
            intPrint(IAT, 4);
            tempSymbol();
            
            lcd.print(" ");
            byte filler;
            if (engine == 2)
              filler = mystery9;
            else filler = mystery7;
            
            if (filler < 10)
              lcd.print(" ");
            lcd.print("v");
            lcd.print(filler); //IAT Offset?

              if (diagnoseMinMax == 3){
                IATMin = IAT;
                IATMax = IAT;
                diagnoseMinMax = 1;
              }
            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(2,1);
                lcd.print(F(">Outside Air"));
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(IATMin);
                lcd.setCursor(11,1);
                lcd.print(IATMax);
              break;
              case 2: //graphing
                printLongScroll(IATRaw, 0, 255, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(3,0);
            lcd.print(F("Intake Air"));
            lcd.setCursor(2,1);
            lcd.print(F("Temperature"));
          break;
          case 2://Location
            lcd.setCursor(1,0);
            lcd.print(F("Intake Manifold"));
            lcd.setCursor(1,1);
            lcd.print(F("Behind Thr Body"));
          break;
          case 3://Pinout
            lcd.setCursor(1,0);
            lcd.print("A:GND B:Output");
            lcd.setCursor(1,1);
            lcd.print("100k - 0 Ohms");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 5://RPM**************************************************
        if (engineRunFlag == true && ThrottleSwitch == Clsd && (RPM < 570 || RPM > 930))
          celOn();
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(5,0);
            displayRPM();

            if (engine == 2)
            {
              lcd.setCursor(2,0);
              intPrint(mystery8, 3);   //M8 RPM offset?
            }
  
            if (diagnoseMinMax == 3){
              RPMMin = RPM;
              RPMMax = RPM;
              diagnoseMinMax = 1;
            }
            
            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(2,1);
                lcd.print(F("Idle:600-900"));
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(RPMMin);
                lcd.setCursor(11,1);
                lcd.print(RPMMax);
              break;
              case 2: //graphing
                printLongScroll(RPM, 0, 5000, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Revolutions"));
            lcd.setCursor(3,1);
            lcd.print(F("Per Minute"));
          break;
          case 2://Location
            lcd.setCursor(2,0);
            lcd.print(F("CPS Top Left"));
            lcd.setCursor(0,1);
            lcd.print(F("Trns Bellhousing"));
          break;
          case 3://Pinout
            lcd.setCursor(2,0);
            lcd.print(F("A&B:A/C Signal"));
            lcd.setCursor(0,1);
            lcd.print(F("or 125-275 Ohms"));
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 6://Volts**************************************************
        if (engineRunFlag == true && (Volts < 12.9 || Volts > 15))
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(5,0);
            displayVolts();
            
            if (diagnoseMinMax == 3){
              VoltsMin = Volts;
              VoltsMax = Volts;
              diagnoseMinMax = 1;
            }

            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(2,1);
                lcd.print(F("Idle: 13-15V"));
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(F(" Mn     Mx    "));
                lcd.setCursor(4,1);
                lcd.print(VoltsMin,1);
                lcd.setCursor(11,1);
                lcd.print(VoltsMax,1);
              break;
              case 2: //graphing
                printLongScroll(Volts * 10, 70, 160, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Battery Volts"));
            lcd.setCursor(2,1);
            lcd.print(F("/ Alternator"));
          break;
          case 2://Location
            lcd.setCursor(2,0);
            lcd.print(F("May Read 0 w/"));
            lcd.setCursor(1,1);
            lcd.print(F("Key On, Eng Off"));
          break;
          case 3://Pinout
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 7://TPS**************************************************
        if ((engine == 4 && ThrottleSwitch == Clsd && (TPS < 14 || TPS > 20)) || TPS < 3 || TPS > 96)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            if (engine == 4)
            {
              lcd.setCursor(6,0);
              displayTPS();
              
              lcd.setCursor(2,0);
              lcd.print(TPS/20.08);
              lcd.print("v ");
            }
            if (engine == 2)
            {
              lcd.setCursor(7,0);
              displayTPS();
              
              lcd.setCursor(1,0);
              lcd.print(TPS/20.08);
              lcd.print("v");

              if (mystery7 < 10)
              lcd.print(" ");
              lcd.print("+");
              lcd.print(mystery7);
            }
            
            if (diagnoseMinMax == 3){
              TPSMin = TPS;
              TPSMax = TPS;
              diagnoseMinMax = 1;
            }

            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(1,1);
                displayThrottleSwitch();
                
                lcd.setCursor(6,1);
                if  (engine == 4)
                  lcd.print(" Cls:17%");
                else 
                  lcd.print(" WOT:94%");
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(TPSMin);
                lcd.setCursor(11,1);
                lcd.print(TPSMax);
              break;
              case 2: //graphing
                printLongScroll(TPS, 0, 100, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(1,0);
            lcd.print(F("Throttle Posit-"));
            lcd.setCursor(3,1);
            lcd.print(F("ion Sensor"));
          break;
          case 2://Location
            lcd.setCursor(4,0);
            lcd.print(F("Front of"));
            lcd.setCursor(1,1);
            lcd.print(F("Throttle Body"));
          break;
          case 3://Pinout
            lcd.setCursor(2,0);
            lcd.print("A:5v B:GND");
            lcd.setCursor(2,1);
            lcd.print("C:Output 0-5V");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 8://Lambda**************************************************
        if (Lambda == LambdaPrev){
            if (LambdaCounter == false){
              LambdaPrevTime = millis();
              LambdaCounter = true;
            }
            if (millis() > (LambdaPrevTime + 10000))
              celOn();
          }
          else{
            LambdaPrev = Lambda; //check for new number
            LambdaCounter = false; //Reset Counter
          }
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(1,0);
            if (LoopStatus == Clsd)
              lcd.print("C");
            else if (LoopStatus == Dcel)
              lcd.print("D");
            else lcd.print("O");
            
            displayExhaust();
            lcd.setCursor(7,0);
            displayLambda();
              
            if (diagnoseMinMax == 3){
              LambdaMin = Lambda;
              LambdaMax = Lambda;
              diagnoseMinMax = 1;
            }
              
            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(1,1);;
                
                intPrint(STFT, 4);
                
              if (engine == 2)
                lcd.print(F("s 1V Swing"));
              else    
                lcd.print(F("s 5V Swing"));
              break;
              case 1: //min/max
                byte fillerDec;
                if (engine == 4)
                  fillerDec = 2;
                  
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(LambdaMin, fillerDec);
                lcd.setCursor(11,1);
                lcd.print(LambdaMax, fillerDec);
              break;
              case 2: //graphing
                if (engine == 2)
                  printLongScroll(Lambda, 0, 1100, 4, 1, 8);
                else
                  printLongScroll(Lambda * 100, 0, 500, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Oxygen Sensor"));
            lcd.setCursor(4,1);
            lcd.print(F("Voltage"));
          break;
          case 2://Location
            lcd.setCursor(1,0);
            lcd.print("Exhaust Manifo-");
            lcd.setCursor(2,1);
            lcd.print("ld Collector");
          break;
          case 3://Pinout
            lcd.setCursor(2,0);
            lcd.print("A:12v B:GND");
            lcd.setCursor(2,1);
            if (engine == 2)
              lcd.print("C:Output 0-1V");
            else
              lcd.print("C:Output 0-5V");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 9://Knock**************************************************
        if (engineRunFlag == true && Knock > 100)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(7,0);
            displayKnock();
            lcd.setCursor(1,0);
            intPrint(engineRPM, 5);
            lcd.print("RPM");

            if (diagnoseMinMax == 3){
              KnockMin = Knock;
              KnockMax = Knock;
              diagnoseMinMax = 1;
            }

            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(1,1);
                intPrint(SparkADV, 5);
                lcd.print("IGN");

                //lcd.setCursor(8,1);
                
                intPrint(SparkRTD, 3);           //M5 IGN Knock Mask
                lcd.print("RTD");
                
                //lcd.print(F("2.5kRPM:10-100"));
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(KnockMin);
                lcd.setCursor(11,1);
                lcd.print(KnockMax);
              break;
              case 2: //graphing
                printLongScroll(Knock, 0, 255, 4, 1, 8);
              break;
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Knock Sensor"));
          break;
          case 2://Location
            lcd.setCursor(2,0);
            lcd.print(F("Left Side of"));
            lcd.setCursor(2,1);
            lcd.print(F("Engine Block"));
          break;
          case 3://Pinout
            lcd.setCursor(2,0);
            lcd.print("A:GND B:Output");
            lcd.setCursor(1,1);
            lcd.print(F("Piezo-Electric"));
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 10://Fuel Trims**************************************************
        switch (diagnoseMode){
          case 0://Readout
            
            lcd.setCursor(9,0);
            intPrint(STFT, 4);
            lcd.print("ST");

            if (engine == 4) //m6 is only Inj WU for 4.0L
            {
              lcd.setCursor(1,0);
              if (InjPulse < 9.95)
                lcd.print(" ");
              lcd.print(mystery6, 0);    //Injector Warmup Offset
            } 
            else lcd.setCursor(3,0);
            lcd.print(" ");
            lcd.print(InjPulse, 1);
            lcd.print("ms");

            if (diagnoseMinMax == 3){
              STFuelMin = STFuel;
              STFuelMax = STFuel;
              diagnoseMinMax = 1;
            }

            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(9,1);
                intPrint(LTFT, 4);
                lcd.print("LT");
                 
                lcd.setCursor(1,1);
                displayLoopStatus();
              break;
              case 1: //min/max
                lcd.setCursor(1,1);
                lcd.print(" Mn     Mx    ");
                lcd.setCursor(4,1);
                lcd.print(STFuelMin);
                lcd.setCursor(11,1);
                lcd.print(STFuelMax);
              break;
              case 2: //graphing
                printLongScroll(STFuel, 0, 255, 4, 1, 8);
              break;
            }
            
          break;
          case 1://Description
            lcd.setCursor(1,0);
            lcd.print(F("Short/Long Term"));
            lcd.setCursor(3,1);
            lcd.print(F("Fuel Trims"));
          break;
          case 2://Location
            lcd.setCursor(1,0);
            lcd.print(F("Correction Fac-"));
            lcd.setCursor(1,1);
            lcd.print(F("tor used by ECU"));
          break;
          case 3://Pinout
            lcd.setCursor(2,0);
            lcd.print("< 128 is Lean");
            lcd.setCursor(2,1);
            lcd.print("> 128 is Rich");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 11://ECU type
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(2,0);
            lcd.print(F("Detected ECU"));
            lcd.setCursor(0,1);
            lcd.print("  ");
            if (engine == 4 && bitRead(dataStream[1], 7) == false) // centering print for auto
              lcd.print(" ");
            
            if (dataStream[0] == 177) 
              lcd.print("89-90");
            else if (dataStream[0] == 176) 
              lcd.print("87-88");
            else if (dataStream[0] == 32)
              lcd.print("  2.5L  ");
            else lcd.print("  ???");

            if (dataStream[1] == 0)
              lcd.print(" ???");
            else if (engine == 4)
            {
              if (bitRead(dataStream[1], 7) == false) //4.0L A/T
                lcd.print(F(" Auto"));
              else if (bitRead(dataStream[1], 7) == true) //4.0L M/T
                lcd.print(" Manual");
            }
            else
            { 
              lcd.print(bitRead(dataStream[1], 7));
              lcd.print(bitRead(dataStream[1], 1));
              lcd.print(bitRead(dataStream[1], 0));
            }
            /*
            if (dataStream[1] == 98)
              lcd.print(" New");
            else if (dataStream[1] == 97)
              lcd.print(" Mid");
            else if (dataStream[1] == 225)
              lcd.print(" Old");
            else lcd.print(" ???");
            */
              
          break;
          case 1:
              lcd.setCursor(2,0);
              lcd.print(F("PROM Number:"));
              lcd.setCursor(2,1);
              displayPROM();
          break;
          case 2:
            diagnoseMode = 0;
          break;
          case 3:
            diagnoseMode = 0;
          break;
        }   
      break;
      case 12://Mysteries**************************************************
        switch (diagnoseMode){
          case 0://Readout
            if (engine == 2) //2.5L mysteries
            {
              drawBinChar(mystery3, 1);                  //M3 Bits
              drawBinChar(dataStream[18], 2);            //Byte 18, Exhaust
              
              lcd.setCursor(0,0);//14 15 17 20 22 23 25 28
              if (dataStream[14] < 100)
                lcd.setCursor(1,0);                     //doesn't overwrite I unless nessisary
              intPrint(mystery1, 2);                    //M1 Zero?
              intPrint(mystery2, 4);                    //M2 slow increase
              lcd.print("  ");
              printBinChar(1);                          //M3 Bits
              lcd.print(" ");
              printBinChar(2);                          //Byte 18, Exhaust
              
              lcd.setCursor(0,1);
              intPrint(mystery4, 3);                    //M4 Zero?
              intPrint(mystery5, 4);                    //M5 Zero?
              intPrint(mystery6, 4);                    //M6 small Idle offset?                                         
              intPrint(mystery10, 4);                   //M10 128

              //intPrint(mystery7, 4);                    //M7 ISM WarmUp offset
              
              //intPrint(mystery8, 4);                    //M8 RPM offset?
  
              //intPrint(mystery9, 4);                    //M9 IAT offset?
              }
            else //4.0L Mysteries
            {
              //14 15 17 20 22 23 25 28
              drawBinChar(mystery1, 1);                  //M1 Bits                        
              drawBinChar(mystery3, 2);                  //M3 Bits
              drawBinChar(dataStream[21], 3);            //Throttle Bits
              drawBinChar(dataStream[29], 4);            //AC Bits
              
              lcd.setCursor(3,0);                     
              printBinChar(1);                            //M1 Bits
              lcd.print("  ");
              printBinChar(2);                            //M3 Bits
              lcd.print(" ");
              intPrint(mystery4, 4);                      //M4 zero?
              
              lcd.setCursor(3,1);
              printBinChar(3);                            //TPS/Sync Bits
              lcd.print("  ");
              printBinChar(4);                            //AC Bits
              lcd.print(" ");
              intPrint(mystery8, 4);                      //M8 Zero or 128

              /*
              //intPrint(mystery2, 4);                    //M2, CTS target offset
              
              if (bitRead(mystery5, 7) == true)
                lcd.print("K");
              else lcd.print(" ");
              bitClear(mystery5, 7); 
              intPrint(mystery5, 2);                    //M5 IGN Knock Mask
              
              floatPrint(mystery6, 4, 1);               //M6 Warmup Offset
              
              intPrint(mystery7, 4);                    //M7 IAT target offset
              */
              
            }
          break;
          case 1://Description
            lcd.setCursor(2,0);
            lcd.print(F("Mystery Byte"));
            lcd.setCursor(5,1);
            lcd.print(F("Values"));
          break;
          case 2://Location
            lcd.setCursor(3,0);
            if (engine == 4)
            {
              lcd.print(F("14  17  20"));
              lcd.setCursor(3,1);
              lcd.print(F("21  29  28"));
            }
            else
            {
              lcd.print(F("14 15 17 18"));
              lcd.setCursor(3,1);
              lcd.print(F("19 20 22 28"));
            }
          break;
          case 3:
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 13://Fuel Tracking**************************************************
        switch (diagnoseMode){
          case 0://Readout
            /*if (diagnoseMinMax == 3){ //tank reset code
              EEPROM.put(EEdistanceTrack, 0.00);
              EEPROM.put(EEfuelTrack, 0.00);
              diagnoseMinMax = 1;
            }*/
            
            switch(diagnoseMinMax)
            {
              case 0: //trip history****************
                lcd.setCursor(2,0);
                lcd.print("Trip History");
                
                lcd.setCursor(1,1);
                if (distanceHistory > 9.995)
                  floatPrint(distanceHistory, 6, 2);
                else
                  floatPrint(distanceHistory, 5, 2);
                if (speedUnit == false)
                  lcd.print("K ");
                else lcd.print("M ");
                
                floatPrint(fuelHistory, 5, 3);
                if (speedUnit == false)
                  lcd.print("L");
                else lcd.print("G");
              break;
              case 1: //tank history**************
                lcd.setCursor(2,0);
                lcd.print("Tank History");
                
                lcd.setCursor(1,1);
                //if (distanceHistory > 9.995)
                  //lcd.setCursor(1,2);
                floatPrint(EEPROM.get(EEdistanceTrack, dTemp), 6, 1);
                if (speedUnit == false)
                  lcd.print("K ");
                else lcd.print("M ");
                
                floatPrint(EEPROM.get(EEfuelTrack, fTemp), 3, 1);
                if (speedUnit == false)
                  lcd.print("L");
                else lcd.print("G");
              break;
              case 2: //tank to empty***************
                lcd.setCursor(2,0);
                lcd.print("Tank To Empty");

                float tankSize;
                if (EEPROM.read(EEtankSize) == false)
                  tankSize = 13;
                else tankSize = 20;
                
                float fuelLeft = tankSize - EEPROM.get(EEfuelTrack, fTemp);
                float distanceLeft = fuelLeft * (EEPROM.get(EEdistanceTrack, dTemp) / EEPROM.get(EEfuelTrack, fTemp));
                
                lcd.setCursor(1,1);
                //if (distanceHistory > 9.995)
                  //lcd.setCursor(1,2);
                if (isfinite(distanceLeft) == false)
                  lcd.print(" ---.-");
                else
                  floatPrint(distanceLeft, 6, 1);
                if (speedUnit == false)
                  lcd.print("K ");
                else lcd.print("M ");
                
                floatPrint(fuelLeft, 4, 1);
                if (speedUnit == false)
                  lcd.print("L");
                else lcd.print("G");
              break;
            }
          break;
          case 1://Description
            diagnoseMode = 0;
          break;
          case 2://Location
            diagnoseMode = 0;
          break;
          case 3://Pinout
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 14://AFR Tuning**************************************************
        switch (diagnoseMode){
          case 0://Readout
            lcd.setCursor(0,0);
            lcd.print("e");
            lcd.setCursor(2,0);
            floatPrint(AFR, 5, 2);
            lcd.print("AF ");

            if (engine == 2)
              intPrint(Lambda, 4);
            else  
              floatPrint(Lambda, 4, 2);
            lcd.print("v");

            switch(diagnoseMinMax)
            {
              case 0: //normal
                lcd.setCursor(2,1);
                floatPrint(AFRtarget, 5, 2);
                lcd.print("TG ");
                intPrint(STFT, 3);
                lcd.print("ST");
                //floatPrint(AFRrange, 3, 1);
                //lcd.print("RG");
              break;
              case 1:
                printLongScroll(Lambda * 100, 0, 500, 4, 1, 8);
              break;
              case 2: //graphing
                printLongScroll(AFR * 100, 1300, 1600, 4, 1, 8);
              break;
            }
                
          break;
          case 1://Description
            diagnoseMode = 0;
            menuOrder = AFRmenu; 
          break;
          case 2://Location
            diagnoseMode = 0;
          break;
          case 3://Pinout
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
     }//diagnoseMenu Switch Case end
    }//Delay If End
    //delay(menuDelay);
  break;
  case AFRmenu://AFR Tuning Menu **************************************************************************************
    static bool AFRcursor;
    AFRtarget = EEPROM.get(EEAFRtarget, AFRtarget); //grab fresh EE value
    //AFRtarget = 14.85;
    
    if (btnCheck(btnTopLeft)) 
      menuOrder = Diagnose;

    if (btnRepeat(btnTopRight)){ 
      if (AFRcursor == true)
        AFRrange += 0.1;
      else  
        AFRtarget += 0.01;
    }

    if (btnCheck(btnBottomLeft))
      AFRcursor = !AFRcursor;

    if (btnRepeat(btnBottomRight)){ 
      if (AFRcursor == true)
        AFRrange -= 0.1;
      else  
        AFRtarget -= 0.01;
    }

    
    if (updateScreen > 0 || updateTimedScreen == true){
      lcd.setCursor(0,0);
      lcd.print("^ ");
      floatPrint(AFR, 5, 2);
      lcd.print("AF ");
  
      floatPrint(Lambda, 4, 2);
      lcd.print("v+");
      
      lcd.setCursor(0,1);
      lcd.print("> ");
      floatPrint(AFRtarget, 5, 2);
      lcd.print("TG");
      if (AFRcursor == true)
        lcd.print(">");
      else  
        lcd.print("<");
      floatPrint(AFRrange, 3, 1);
      lcd.print("RG-");
    }
    EEPROM.put(EEAFRtarget, AFRtarget);
    EEPROM.put(EEAFRrange, AFRrange);
  break;
  case Home://Home Selection Screen ************************************************************************************ 
//120mhz = 321us
//96mhz = 331us
//72mhz = 332us
//48mhz = 372us
//24mhz = 456us
    
// + 2-4us
    InOutOrder = 0;//reset diagnose in/out menu
//--

// 7667us  
    if (updateScreen > 0){
      if (homeScreen == true){//clock home screen, V3 stuff
        lcd.setCursor(0,0);
        lcd.print(F("CEL ")); //spaces used as a half-assed screen clear
        lcd.setCursor(12,0);
        lcd.print(F(" GAU"));
        lcd.setCursor(0,1);
        lcd.print(F("DIA "));
        lcd.setCursor(12,1);
        lcd.print(F(" MOR"));   
      }
      else{ //regular screen
        lcd.setCursor(0,0);  
        lcd.print(F("Codes     Gauges"));
        lcd.setCursor(0,1);
        lcd.print(F("Diagnose    More"));
                   //----------------
      }
    }//end update screen
// ---

// 5904us
    if (homeScreen == true && (updateTimedScreen == true || updateScreen > 0)){    
      lcd.setCursor(4,0);
      displayTime();
      lcd.setCursor(4,1);
      displayDate(driftTimeNow());
    }
// ---
    static bool bootFlag = false;
    
    if (homeFlag == true && lcdKey != btnNone)
      bootFlag = true;
    if (homeFlag == true && bootFlag == true && lcdKey == btnNone) 
      homeFlag = false;

    if (homeFlag == false){
      if (btnCheck(btnTopLeft))
        menuOrder = CELMenu;//TCUGauges;
  
      if (btnCheck(btnTopRight))
        menuOrder = Gauges;
  
      if (btnCheck(btnBottomLeft))
        menuOrder = DiagnoseMenu;
  
      if (btnCheck(btnBottomRight))
        menuOrder = MoreMenu;
    }
// ---
  break;
  case MoreMenu:// More Options menu*****************************************************************************************
   if (updateScreen > 0){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print(F("Fans"));
      lcd.setCursor(9,0);
      lcd.print(F("Fill-Up"));
      lcd.setCursor(0,1);
      lcd.print(F("Vehicle"));
      lcd.setCursor(8,1);
      lcd.print(F("Settings"));
    }
    
    if (btnCheck(btnTopLeft))
      menuOrder = InOutMenu;

    if (btnCheck(btnTopRight))
      menuOrder = FillUpMenu;

    if (btnCheck(btnBottomLeft))
      menuOrder = Vehicle;

    if (btnCheck(btnBottomRight))
      menuOrder = SettingsMenu;

  break;
  case FillUpMenu://Fuel Refill Menu*****************************************************************************************
    static byte fillMode = 1;
    static byte saveCheck = 0;
    static float fillAmount;
    static float newCal;
    static float tempCal;
    static float tankAmount;
    
    if (updateScreen == menu) //grab initial value
      fillAmount = EEPROM.get(EEfuelTrack, fillAmount);
 
    tempCal = fillAmount / EEPROM.get(EEfuelTrack, floaty); //compares the fill up to the recorded fuel used for a cal percentage

    newCal = EEPROM.get(EEfuelCal, floaty) - (1 - tempCal); // Calibration is updated with new percentage of itself

    if (btnCheck(btnTopLeft)){ //Mode
      if (saveCheck != 1){
      ++fillMode;
      if (fillMode > 3)
        fillMode = 1;
      }
    }

    if (btnCheck(btnTopRight)) //Save
      saveCheck = 1;

    if (btnRepeat(btnBottomLeft)){ //Decrease
      if (saveCheck == 1) //No save
          saveCheck = 0;
      else //adjust fill *************************************************************
        fillAmount -= 0.1;
    }

   if (btnRepeat(btnBottomRight)){ //Increase / Save
      if (saveCheck == 1){ //Yes save *********************************************
        switch(fillMode)                      
        {
          case 1: //full
            if (EEPROM.read(EEfillupCheck) != 1){ // first full fill
              EEPROM.update(EEfillupCheck, 1); //set to true for next time
              if (fillAmount > EEPROM.read(EEtankSize))
                tankAmount = fillAmount; //because you can always fit more if you try
              else 
                tankAmount = EEPROM.read(EEtankSize);
              EEPROM.put(EEtankLevel, tankAmount);
            }
            else{// conescutive fill
              if (isfinite(newCal) == true) // only save if it's a real number
                EEPROM.put(EEfuelCal, newCal); 
            //So notice the code does nothing to the tank if it's on a consecutive fill. The tank variable doesn't actively change, so if it use to be full,
            //and then was filled again, then the variable hasn't change. Only the Calibration Offset is modified for next trip.
            }
          break;
          case 2: //part
            tankAmount = EEPROM.get(EEtankLevel, floaty) - EEPROM.get(EEfuelTrack, floaty) + fillAmount; //subtracts used fule, then addes current fill to leftover tank
            tankAmount = constrain(tankAmount, fillAmount, EEPROM.read(EEtankSize) + 2); //helps to adjust calculated tank value
            EEPROM.put(EEtankLevel, tankAmount);
            EEPROM.update(EEfillupCheck, 0); //set to false
          break;
          case 3: //missed
            tankAmount = fillAmount; //unknown level, so just use was what added
            EEPROM.put(EEtankLevel, tankAmount);
            EEPROM.update(EEfillupCheck, 0); //set to false
          break;
        }
        
        EEPROM.put(EEfuelTrack, 0.00); //reset tank tracking variables
        EEPROM.put(EEdistanceTrack, 0.00);
        saveCheck = 0;
        menuOrder = MoreMenu;
      }
      else{ //adjust fill *************************************************************
        fillAmount += 0.1;
        //updateScreen =  buttons;        
      }
   }
 
/*
    20 tank
    -11 drive
    20 - 11 = 9 curr tank 
    9 + 7 = 16 part fill
    -10 drive
    16 - 10 = 6 curr tank
    6 + 15 = 21 full fill
    -18 drive
    21 - 18 = 3 curr tank
    3 + 18 = 21 full fill
*/
    if (updateScreen > 0){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print("Md   ");

      if (saveCheck == 1)
        lcd.print("SAVE?");
      else{
        switch(fillMode)                      
        {
          case 1:
            lcd.print("FILL-UP");
          break;
          case 2:
            lcd.print("PARTIAL");
          break;
          case 3:
            lcd.print("MISSED");
          break;
        }
      }
      
      lcd.setCursor(14,0);
      lcd.print("Sv");

      if (saveCheck == 1){
        lcd.setCursor(0,1);
        lcd.print("NO");
        lcd.setCursor(13,1);
        lcd.print("YES");
      }
      else{
        lcd.setCursor(0,1);
        lcd.print("<");
        lcd.setCursor(15,1);
        lcd.print(">");
      }
      
      lcd.setCursor(3,1);
      floatPrint(fillAmount, 4, 1);
      if (speedUnit == false)
        lcd.print("L  ");
      else lcd.print("G  ");
      if (fillMode == 1 && EEPROM.read(EEfillupCheck) == 1 && isfinite(newCal) == true)
      {
        int printCal = newCal * 100 - 100;
        if (printCal > 0)
          lcd.print("+");
        lcd.print(printCal);
      }
      else
      {
        int printCal = EEPROM.get(EEfuelCal, floaty) * 100 - 100;
        if (printCal > 0)
          lcd.print("+");
        lcd.print(printCal);
      }
      lcd.print("%");      
      
    }
/*
        REM readings
        189.4M 12.5G / 190M 10.493G Partial
        
        EEfuelTrack = 12.5

        fuelLeft = 20 - 12.5 = 7.5

        EEtankFuel = 7.5

        fillAmount = 10.493G Partial

        EEtankFuel = 7.5 + 10.493 = 17.993


       Tank offset;

        
       //fill-up
       EEtankFuel = Tanksize //first fill eetank = 20
       
       fueltrack = 12.5gal // eetank = 7.5
       used 10.5g actual
       
       fillAmount = fueltrack //second fillup 12.5
       +- fillAmount //12.5 - 2 = 10.5
       fillAmount / fueltrack = calibration 10.5 / 12.5 = 0.84%
       Calibrate?
       fueltrack = fillamount 10.5

       eetankFuel += fillamount

       //third fuelup
       GPH * cal = GPH
       
       fueltrack = 14.28gal

       fillAmount = fueltrack//third fillup 14.28
       +- fillAmount //14.28 - 0.2 = 14.08
       fillAmount / fueltrack = calibration 14.08 / 14.28 = 0.985%
       Calibrate?

       cal -= (1 - newcal)
       
       gph *= cal

       17 * 0.84 = 14.28
       17 * 0.828 = 14.08
       //fueltrack = fillamount 10.5

       eetankFuel += fillamount


       //partial
       fillAmount = fueltrack
       EEtankFuel += fillAmount

       //missed
       EEtankFuel = fillAmount

      */
         
  break;
  case SettingsMenu: //Main Settings menu **********************************************************************************
      static byte index = 1;
      /*if (btnCheck(btnTopRight))
        --index;
      if (btnCheck(btnBottomRight))
        ++index;

      rollover(index, 1, 8);
*/
      upDownArrowScroller(index, 1, 8);
        
      if (updateScreen > 0){
        lcd.clear();

        rightArrow();
        upDownArrows();
        
        scrollPrint(1, "Vehicle", index);
        scrollPrint(2, "Units", index);
        scrollPrint(3, "Display", index);
        scrollPrint(4, "Clock", index);
        scrollPrint(5, "Options", index);
        scrollPrint(6, "Wideband", index);
        scrollPrint(7, "Advanced", index);
        scrollPrint(8, "Back", index);
      }
      
      if (btnCheck(btnTopLeft)){
        switch (index){
          case 1:
            menuOrder = Vehicle;
          break;
          case 2:
            menuOrder = Units;
          break;
          case 3:
            menuOrder = DisplayMenu;//PickColor;
          break;
          case 4:
            menuOrder = TimeMenu;
          break;
          case 5:
            menuOrder = Settings;
          break;
          case 6:
            menuOrder = WidebandMenu;
          break; 
          case 7:
            menuOrder = AdvancedMenu;
          break;
          case 8:
            menuOrder = MoreMenu;
          break;
        }
      }
  break;
  case Vehicle://Vehicle Selection Screen***********************************************************************************
    if (btnCheck(btnTopLeft))
        --vehicleOrder;
    if (btnCheck(btnTopRight))
        ++vehicleOrder;   
    rollover(vehicleOrder, 1, 9);
    
    if (updateScreen > 0)
      lcd.clear();
    if (updateScreen > 0 || (updateTimedScreen == true)){ //&& vehicleOrder == 5)){ //Speed Adjust updater
      menuArrows();
   
      switch(vehicleOrder){
        case 1://Engine Type
          if (btnCheck(btnBottomLeft))
            --engine;
          if (btnCheck(btnBottomRight))
            ++engine;
          rollover(engine, 2, 4); //keep in check
          
          centerPrint("Engine", 0);
          switch(engine){
            case 1:
              centerPrint("Auto Detect", 1);
            break;
            case 2:
              centerPrint("2.5L 4cyl", 1);
            break;
            case 3:
              centerPrint("ABS Switch", 1);
            break;
            case 4:
              centerPrint("4.0L 6cyl", 1);
            break;
          }      
        break;
        case 2://Trans Type
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            transType = !transType;
          centerPrint(F("Transmission"), 0);
          if (transType == true)
            centerPrint("Automatic", 1);
          else
            centerPrint("Manual", 1);
        break;    
        case 3://Tire Size********************************
            if (btnCheck(btnBottomLeft))
              --TireSize;
            if (btnCheck(btnBottomRight))
              ++TireSize;
  
            TireSize = constrain(TireSize, 16, 52);
  
            centerPrint(F(" Tire Size"), 0);
            lcd.setCursor(5,1);
            lcd.print(TireSize);
            lcd.print(F(" Inch"));
        break;
        case 4://Gear Ratio******************************
          if (btnCheck(btnBottomLeft))
            --GearRatioCounter;

          if (btnCheck(btnBottomRight))
            ++GearRatioCounter;
  
          GearRatioCounter = constrain(GearRatioCounter, 1, 10);
          
          switch (GearRatioCounter){
            case 1:
              GearRatio = 3.07;
            break;
            case 2:
              GearRatio = 3.55;
            break;
            case 3:
              GearRatio = 3.73;
            break;
            case 4:
              GearRatio = 3.91;
            break;
            case 5:
              GearRatio = 4.11;
            break;
            case 6:
              GearRatio = 4.27;
            break;
            case 7:
              GearRatio = 4.56;
            break;
            case 8:
              GearRatio = 4.88;
            break;
            case 9:
              GearRatio = 5.13;
            break;
            case 10:
              GearRatio = 5.38;
            break;
            }
            
          centerPrint(F(" Gear Ratio"), 0);
          lcd.setCursor(6,1);
          lcd.print(GearRatio,2);       
        break;
        case 5://Speed Correction************************
          if (btnRepeat(btnBottomLeft))
            --SpeedCorr;
            
          if (btnRepeat(btnBottomRight))
            ++SpeedCorr;
          
          centerPrint(F("Speed Adjust"), 0);
          lcd.setCursor(2,1);
          floatPrint(MPH, 4, 1);
          if (speedUnit == false)
            lcd.print("KPH ");
          else
            lcd.print("MPH ");
          intPrint(SpeedCorr, 3);
          lcd.print("%");
          if (MPH < 99.9)
            lcd.print(" ");
        break;
        case 6://Fuel Tank**************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            EEPROM.update(EEtankSize, !EEPROM.read(EEtankSize));

          centerPrint(F(" Tank Size"), 0);
          if (EEPROM.read(EEtankSize) == true){
            if (speedUnit == true)
              centerPrint("20 Gal", 1);
            else
              centerPrint("75 Ltr", 1);
          }
          else{
            if (speedUnit == true)
              centerPrint("13 Gal", 1);
            else
              centerPrint("50 Ltr", 1);
          }
        break;
        case 7://Fuel Calibrate Type*******************              
          if (btnCheck(btnBottomLeft) && fuelCalMode > 0) //Decrease case**********
            --fuelCalMode;
   
          if (btnCheck(btnBottomRight) && fuelCalMode < 2) //Increase case*********
            ++fuelCalMode;
    
          centerPrint(F("Fuel Cal Mode"), 0);
          lcd.setCursor(3,1);
          switch(fuelCalMode)
          {
            case 0:
              lcd.print(F("Stock +0.0%"));
            break;
            case 1:
              lcd.print(F("Auto  "));
              if (EEPROM.get(EEfuelCal, floaty) >= 0)
                lcd.print("+");
              floatPrint(EEPROM.get(EEfuelCal, floaty), 3, 1);
              lcd.print("%");
            break;
            case 2:
              lcd.print(F("User  "));
              if (InjCorr >= 0)
                lcd.print("+");
              floatPrint(InjCorr, 3, 1);
              lcd.print("%");
            break;
            default:
              fuelCalMode = 0;
            break;
          }
        break;
        case 9://Back************************************* IDK why this can't go below, issues with injFloat?
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
        case 8://Fuel Correction************************
          if (btnRepeat(btnBottomLeft))
            InjCorr -= 0.5;

          if (btnRepeat(btnBottomRight))
            InjCorr += 0.5;
          
          float injFlow = 18.927;          //4.0L Injector Flow Rate
          if (engine == 2)
            injFlow = 33.15;               //2.5L, 1 big injector vs 6 small ones
          
          centerPrint(F("User Adjust"), 0);
          lcd.setCursor(2,1);
          floatPrint(injFlow * (InjCorr / 100 + 1), 4, 1);
          lcd.print("lb ");
          if (InjCorr >= 0)
            lcd.print("+");
          floatPrint(InjCorr, 3, 1);
          lcd.print("%");
        break;
      }//end menu switch case
    }//update screen end
    EEPROM.update(EEengine, engine);
    EEPROM.update(EEtransType, transType);
    EEPROM.update(EETireSize, TireSize);
    EEPROM.update(EEGearRatioCounter, GearRatioCounter);
    EEPROM.put(EEGearRatio, GearRatio);//like update but will store the whole float, 4 adresses
    EEPROM.update(EESpeedCorr, SpeedCorr);
    EEPROM.update(EEfuelCalMode, fuelCalMode);
    byte InjCorrSave;
    InjCorrSave = InjCorr * 2 + 128;
    InjCorrSave = constrain(InjCorrSave, 0, 255);
    EEPROM.update(EEInjCorr, InjCorrSave);  
  break;
  case Units: //Unit Selection Screen ****************************************************************************************************              
    if (btnCheck(btnTopLeft)) //goes back 1 menu
      --unitOrder;

    if (btnCheck(btnTopRight)) //goes forward 1 menu
      ++unitOrder;
    
    rollover(unitOrder, 1, 9);
    
    if (updateScreen > 0){
      lcd.clear();
      menuArrows();
      
      switch(unitOrder)
      {
        case 1://Pressure Unit Screen*******************
          pressureUnit = EEPROM.read(EEpressureUnit);
                        
          if (btnCheck(btnBottomLeft)) //Decrease case**********
            --pressureUnit;
  
          if (btnCheck(btnBottomRight)) //Increase case********* 
            ++pressureUnit;

          rollover(pressureUnit, 2, 4);  
                    
          centerPrint("Pressure", 0);
          switch(pressureUnit)
          {
            /*case 1:
              lcd.print(F("   Voltage"));//fun fact, spaces take up less bytes then multiple setCursor command
            break;*/
            case 2:
              centerPrint("Inches Mercury", 1);
            break;
            case 3:
              centerPrint("kPa", 1);
            break;
            case 4:
              centerPrint("PSI", 1);
            break;
          }
               
          EEPROM.update(EEpressureUnit, pressureUnit);
        break;
        case 2://Temperature Unit Screen*******************************          
          eeBoolUpdate(EEtempUnit, tempUnit);

          centerPrint("Temperature", 0);
          
          if (tempUnit == false)
            centerPrint("Celsius", 1);
          else 
            centerPrint("Fahrenheit", 1);
        break;
        case 3://Speed Unit Screen*******************************
          eeBoolUpdate(EEspeedUnit, speedUnit);

          centerPrint("Speed", 0);
          
          if (speedUnit == false)
            centerPrint("KPH", 1);
          else 
            centerPrint("MPH", 1);
        break;
        case 4://RPM*******************************
          eeBoolUpdate(EErpmUnit, rpmUnit);

          centerPrint("Engine RPM", 0);
          
          if (rpmUnit == false)
            centerPrint("Absolute", 1);
          else 
            centerPrint("Rounded", 1);
        break;
        case 5://Fuel Trims*******************************
          eeBoolUpdate(EEfuelTrimUnit, fuelTrimUnit);

          centerPrint("Fuel Trims", 0);
          
          if (fuelTrimUnit == false)
            centerPrint("Old School", 1);
          else 
            centerPrint("Zeroed", 1);
        break;
        case 6://MPG Combo Unit Screen*************************
          eeBoolUpdate(EEmpgMode, mpgMode);

          lcd.setCursor(3,0);
          if (speedUnit == false)
            lcd.print(F("LHK"));
          else
            lcd.print(F("MPG"));
                         
          lcd.print(F(" Gauge"));
          
          if (mpgMode == false)
            centerPrint("Combined", 1);
          else 
            centerPrint("Seperate", 1);
        break;
        case 7://AVG Mode Screen*******************************              
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            EEPROM.update(EEAVGmode, !EEPROM.read(EEAVGmode)); 
          lcd.setCursor(3,0);
          lcd.print(F("AVG Gauge"));
          lcd.setCursor(4,1);
          if (EEPROM.read(EEAVGmode) == true)
            lcd.print(F("Tank AVG"));
          else lcd.print(F("Trip AVG"));

          
        break;
        case 8://TPS Unit Screen*******************************          
          eeBoolUpdate(EEtpsMode, tpsMode);

          centerPrint("TPS Gauge", 0);
          
          if (tpsMode == false)
            centerPrint("Advanced", 1);
          else 
            centerPrint("Normal", 1);
        break;
        case 9://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
      }//unitOrder switch end
    }//update screen end
  break;
  case DisplayMenu://****************************************************************************************************
    static byte displayOrder = 2;
    
    if (displayOrder != 1){ //goes back 1 menu
      if (btnCheck(btnTopLeft))
        --displayOrder;
    }
    else{ //since repeat doesn't work in nested screen update, for custom screen
      if (btnRepeat(btnTopLeft)){
        switch (RGBCustomOrder)
        {
          case 0:                 //Increase Red
            if (redCustom < 255)
              hundredAdjust(redCustom, 1);//++redCustom;
            break;
          case 1:                 //Increase Green
            if (greenCustom < 255)
              hundredAdjust(greenCustom, 1);//++greenCustom;
            break;
          case 2:                 //Increase Blue
            if (blueCustom < 255)
              hundredAdjust(blueCustom, 1);//++blueCustom;
            break;    
        }
      }

      if (btnRepeat(btnBottomLeft)){    
        switch (RGBCustomOrder)
        {
          case 0:                 //Decrease Red
            if (redCustom > 0)
              hundredAdjust(redCustom, -1); //--redCustom;             
            break;
          case 1:                 //Decrease Green
            if (greenCustom > 0)
              hundredAdjust(greenCustom, -1);//--greenCustom;
            break;
          case 2:                 //Decrease Blue
            if (blueCustom > 0)
              hundredAdjust(blueCustom, -1);//--blueCustom;  
            break;    
        }
      }
    }
      
    if (btnCheck(btnTopRight)){ //goes forward 1 menu
      if (displayOrder == 1){ //sets custom RGB color back to RGBOrder     
          EEPROM.update(EEredCustom,   redCustom);
          EEPROM.update(EEgreenCustom, greenCustom);
          EEPROM.update(EEblueCustom,  blueCustom);
      
          if(RGBOrder == 10){ //custom
            EEPROM.update(EEredValue,   redCustom);
            EEPROM.update(EEgreenValue, greenCustom);
            EEPROM.update(EEblueValue,  blueCustom);
          } 
          else{ //normal value
            redValue   = EEPROM.read(EEredValue);
            greenValue = EEPROM.read(EEgreenValue);
            blueValue  = EEPROM.read(EEblueValue);
          }
      }
      ++displayOrder;
    }
      
    rollover(displayOrder, 1, 5);
    
    if (updateScreen > 0){
      lcd.noCursor();
      lcd.clear();
      menuArrows();
      
      switch(displayOrder)
      {
        case 1://Custom Color Screen******************                         
          //adjusting code above switch to work around repeat issue
     
          if (btnCheck(btnBottomRight))
            ++RGBCustomOrder;
          if (RGBCustomOrder > 2)  
            RGBCustomOrder = 0;                     //sets it back to 0 if above is true
            
          
          //if (updateScreen > 0){      
            lcd.cursor(); //turns on underline cursor
            centerPrint("^ Custom Color S", 0);
            lcd.setCursor(0,1);
            lcd.print("vR");
            leftPrint(hundredConvert(redCustom), 4);
            lcd.print("G");
            leftPrint(hundredConvert(greenCustom), 4);
            lcd.print("B");
            leftPrint(hundredConvert(blueCustom), 3);
            rightArrow();
           
           //Set Final Underline Cursor Position**********************************
            switch (RGBCustomOrder)
            {
              case 0:                 //Red
                lcd.setCursor(1,1);
              break;  
              case 1:                 //Green
                lcd.setCursor(6,1);  
              break;
              case 2:                 //Blue
                lcd.setCursor(11,1);
              break;  
            }
          //}
          //Set custom variables to current variables to show previously saved color 
          redValue = redCustom;
          greenValue = greenCustom;
          blueValue = blueCustom;
        break;    
        case 2://Pick Color*******************************                       
          if (btnCheck(btnBottomLeft))    //Decrease case*****
            --RGBOrder;
                             
          if (btnCheck(btnBottomRight))   //Increase case*****
            ++RGBOrder;
          
          rollover(RGBOrder, 1, 10);  
          
          lcd.setCursor(1,0);
          lcd.print("Color:");
        
          //case statment to display selected color ******************
          lcd.setCursor(8,0);
          switch(RGBOrder) 
          {
            case 1://Red
              redValue   = 255;
              greenValue = 0; 
              blueValue  = 0;
              lcd.print("Red");
            break;
            case 2://Orange
              redValue   = 255;
              greenValue = 24; 
              blueValue  = 0;
              lcd.print("Orange");   
            break;
            case 3://Yellow
              redValue   = 255;
              greenValue = 75;//old was 50 
              blueValue  = 0;
              lcd.print("Yellow");   
            break;     
            case 4://Green
              redValue   = 0;
              greenValue = 255; 
              blueValue  = 0;
              lcd.print("Green");   
            break;
            case 5://Cyan
              redValue   = 0;
              greenValue = 255; 
              blueValue  = 255;
              lcd.print("Cyan");   
            break;  
            case 6://Blue
              redValue   = 0;
              greenValue = 0; 
              blueValue  = 255;
              lcd.print("Blue");   
            break;
            case 7://Purple
              redValue   = 255;
              greenValue = 0; 
              blueValue  = 180;
              lcd.print("Purple");   
            break;  
            case 8://Pink
              redValue   = 255;
              greenValue = 0; 
              blueValue  = 50;
              lcd.print("Pink");   
            break;  
            case 9://White
              redValue   = 255;
              greenValue = 120;//60 was old 
              blueValue  = 100;//70 was old
              lcd.print("White");   
            break;  
            case 10://Custom
              redValue   = redCustom;
              greenValue = greenCustom; 
              blueValue  = blueCustom;
              lcd.print("Custom");   
            break;       
           }
    
          lcd.setCursor(1,1);
          lcd.print("R");
          leftPrint(hundredConvert(redValue), 4);
          lcd.print("G");
          leftPrint(hundredConvert(greenValue), 4);
          lcd.print("B");
          leftPrint(hundredConvert(blueValue), 3);
          
          EEPROM.update(EEredValue, redValue); //Saves selection to memory
          EEPROM.update(EEgreenValue, greenValue);
          EEPROM.update(EEblueValue, blueValue);
          EEPROM.update(EERGBOrder, RGBOrder);
        break;
        case 3://RGB Dimmer Screen ****************************************************************************************************************
          if (btnCheck(btnBottomLeft))
            --RGBDimOrder; 
        
          if (btnCheck(btnBottomRight))
            ++RGBDimOrder;
          
          rollover(RGBDimOrder, 2, 5);                 
            
          centerPrint("Backlight", 0);
      
          //if (updateScreen > 0){ 
            switch(RGBDimOrder)//dim selection case****
            {
              /*case 1:
                RGBDim = 0;
                centerPrint("Off", 1);
              break;*/
              case 2:
                RGBDim = 3;
                centerPrint("Low", 1);
              break;
              case 3:
                RGBDim = 20;
                centerPrint("Med", 1);
              break;
              case 4:
                RGBDim = 100;
                centerPrint("High", 1);
              break;  
              case 5:
                centerPrint("Auto", 1);
              break;
            }
          //}
          EEPROM.update(EERGBDimOrder, RGBDimOrder); //saves selection to memory 
          EEPROM.update(EERGBDim, RGBDim);
        break;
        case 4://Dim menu*******************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = AutoBrightness;
          centerPrint(F("Auto Dim"), 0);
          centerPrint(F("Calibrate?"), 1);
        break;
        case 5://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
      }//displayOrder switch end
    }//update screen end
  break;
  case AutoBrightness://********************************************************************************************************************       

  if (btnRepeat(btnTopLeft)){ //for button re-press   
    switch(AutoDimOrder)
    {
      case 1: //Trigger
        if (lowDim < 95)
          ++lowDim;
      break;
      case 2: //Dim
        if (autoDim < 99)
          ++autoDim;
      break;
      /*case 3: // High
        if (highDim < 99)
          ++highDim;
      break;*/
    }
  }

    if (btnCheck(btnTopRight))
      menuOrder = DisplayMenu;//Backlight;

    if (btnRepeat(btnBottomLeft)){
      switch(AutoDimOrder)
      {
        case 1: //Trigger
          if (lowDim > 0)
            --lowDim;
        break;
        case 2: //Dim
          if (autoDim > 1)
            --autoDim;
        break; 
        /*case 3: // High
          if (highDim > 0 && highDim > lowDim)
            --highDim;
        break;*/
      }
    }
 
    if (btnCheck(btnBottomRight))
      ++AutoDimOrder;
    if (AutoDimOrder > 2)  
      AutoDimOrder = 1;                    

    
    if (updateScreen == menu){
      lcd.clear();
      lcd.cursor();
      lcd.setCursor(0,0);
                 //________________
      lcd.print(F("+Trig__ Light__^"));
      lcd.setCursor(0,1);
      //lcd.print(F("-Low:__ High:__"));
      lcd.print(F("- Screen Dim__%"));
      //lcd.setCursor(15,1);
      rightArrow();
    }
  if (updateScreen > 0 || updateTimedScreen == true){
    lcd.setCursor(5,0);
    intPrint(lowDim, 2);
      
    lcd.setCursor(13,0);
    intPrint(lightSensorAvg, 2);

    //lcd.setCursor(5,1);
    //intPrint(highDim, 2);

    lcd.setCursor(12,1);
    intPrint(autoDim, 2);
     
    switch(AutoDimOrder)
    {
      case 1: //Trigger
        lcd.setCursor(6,0);
      break;
      case 2: //Dim
        lcd.setCursor(13,1);
        RGBDim = autoDim;
      break;
      /*case 3: //Off
        lcd.setCursor(14,1);
      break;*/
    }
  }
    if (AutoDimOrder == 2)
      autoDimTestFlag = true;
      
    EEPROM.update(EEautoDim, autoDim); //see AutoBrightness Menu
    EEPROM.update(EElowDim, lowDim);
    //EEPROM.update(EEhighDim, highDim);
  break;
  /*case Debug:// ***************************************************************************************************************************** 
    lcd.clear();
    lcd.setCursor(0,0);
        switch(debugStreamOrder)
        {
        case 1:
          lcd.print(dataStream[0]);
          lcd.setCursor(3,0);
          lcd.print(dataStream[1]);
          lcd.setCursor(6,0);
          lcd.print(dataStream[2]);
          lcd.setCursor(9,0);
          lcd.print(dataStream[3]);
          lcd.setCursor(12,0); 
          lcd.print(dataStream[4]);
          
          lcd.setCursor(0,1);
          lcd.print(dataStream[5]);
          lcd.setCursor(3,1);
          lcd.print(dataStream[6]);
          lcd.setCursor(6,1);
          lcd.print(dataStream[7]);  
          lcd.setCursor(9,1);
          lcd.print(dataStream[8]);
          lcd.setCursor(12,1); 
          lcd.print(dataStream[9]);
          lcd.setCursor(15,1);
          lcd.print("1");
        break;
        case 2:
          lcd.print(dataStream[10]);
          lcd.setCursor(3,0);
          lcd.print(dataStream[11]);
          lcd.setCursor(6,0);
          lcd.print(dataStream[12]);
          lcd.setCursor(9,0);
          lcd.print(dataStream[13]);
          lcd.setCursor(12,0); 
          lcd.print(dataStream[14]);
          
          lcd.setCursor(0,1);
          lcd.print(dataStream[15]);
          lcd.setCursor(3,1);
          lcd.print(dataStream[16]);
          lcd.setCursor(6,1);
          lcd.print(dataStream[17]);  
          lcd.setCursor(9,1);
          lcd.print(dataStream[18]);
          lcd.setCursor(12,1); 
          lcd.print(dataStream[19]);
          lcd.setCursor(15,1);
          lcd.print("2");
        break;
        case 3:  
          lcd.print(dataStream[20]);
          lcd.setCursor(3,0);
          lcd.print(dataStream[21]);
          lcd.setCursor(6,0);
          lcd.print(dataStream[22]);
          lcd.setCursor(9,0);
          lcd.print(dataStream[23]);
          lcd.setCursor(12,0); 
          lcd.print(dataStream[24]);
          
          lcd.setCursor(0,1);
          lcd.print(dataStream[25]);
          lcd.setCursor(3,1);
          lcd.print(dataStream[26]);
          lcd.setCursor(6,1);
          lcd.print(dataStream[27]);  
          lcd.setCursor(9,1);
          lcd.print(dataStream[28]);
          lcd.setCursor(12,1); 
          lcd.print(dataStream[29]);
          lcd.setCursor(15,1);
          lcd.print("3");
        break;
        case 4:  
          lcd.print(dataStream[30]);
          lcd.setCursor(3,0);
          lcd.print(dataStream[31]);
          
          lcd.setCursor(15,1);
          lcd.print("4");               
        break;
        }//debugStreamOrder Switch
        lcd.setCursor(15,1);
        lcd.blink();
     
    //lcdKey = readLcdButtons();//read bottom buttons to change value               
        switch(lcdKey)                          
        {
        case btnTopLeft://Decrease case**********
          if (btnCheck())
            --debugStreamOrder;
          if (debugStreamOrder < 1)                 
             debugStreamOrder = 4;  
        break;
        case btnTopRight://Increase case*********       
          if (btnCheck())
            ++debugStreamOrder;
          if (debugStreamOrder > 4)  
            debugStreamOrder = 1;                
        break;  
        }
      //btnPrev = lcdKey;
    delay(menuDelay);
  break;*/
  case Settings://Settings Selection Screen (Scrolling)***********************************************************************************
    if (btnCheck(btnTopLeft))
      --settingsOrder;

    if (btnCheck(btnTopRight))
      ++settingsOrder;
      
    rollover(settingsOrder, 1, 6);
      
    if (updateScreen > 0){
      lcd.clear();
      menuArrows();
    }
    
      switch(settingsOrder)
      {
        case 1://Gauge Update Speed*******************              
          if (btnCheck(btnBottomLeft))
            --updateSpeedMenu;
            
          if (btnCheck(btnBottomRight))
            ++updateSpeedMenu;  
            
          rollover(updateSpeedMenu, 1, 4);

          if (updateScreen > 0){
            updateSpeedMenu = EEPROM.read(EEupdateSpeedMenu);
            updateSpeed = EEPROM.read(EEupdateSpeed);
            lcd.setCursor(2,0);
            lcd.print(F("Update Speed"));
            lcd.setCursor(4,1);
            switch(updateSpeedMenu)//Gauge Update Speed selection case****
            {         
              case 1:
                updateSpeed = slow;
                lcd.print(F("  Slow"));
              break;
              case 2: 
                updateSpeed = med;
                lcd.print(F(" Medium"));
              break;
              case 3:
                updateSpeed = fast;
                lcd.print(F("  Fast"));
              break;
              case 4:
                updateSpeed = ludi;
                lcd.print(F("Ludicrous"));
              break;  
             }
          }
          
          EEPROM.update(EEupdateSpeed, updateSpeed);
          EEPROM.update(EEupdateSpeedMenu, updateSpeedMenu);
        break;
        case 2://Check Engine Light Option
          if (btnCheck(btnBottomLeft))
            --cel;
          if (btnCheck(btnBottomRight))
            ++cel;
            
          rollover(cel, 1, 4);                 
   
          if (updateScreen > 0){
            cel = EEPROM.read(EEcel);
            lcd.setCursor(1,0);
            lcd.print(F("Chk Eng Light"));
            lcd.setCursor(2,1);
            switch(cel){
              case 1:
                lcd.print(F("    Off"));
              break;
              case 2:
                lcd.print(F("  Failures"));
              break;
              case 3:
                lcd.print(F("F & Warnings"));
              break;
              case 4:
                lcd.print(F("Shift Light"));
              break;
            }
          }
          
          EEPROM.update(EEcel, cel);
        break;
        case 3://Splash Screen*************              
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            EEPROM.update(EEsplashScreen, !EEPROM.read(EEsplashScreen));
            
          if (updateScreen > 0){
            lcd.setCursor(1,0);
            lcd.print(F("Splash Screen"));
            lcd.setCursor(6,1);
            if (EEPROM.read(EEsplashScreen) == true)
              lcd.print("Yes");
            else lcd.print("No");
          }
          
        break;
        case 4://Reset Screen*************            
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight)){
            if (EEPROM.read(EEreset) == 0)
              EEPROM.update(EEreset, 255);
            else EEPROM.update(EEreset, 0);
          } 
          if (updateScreen > 0){
            lcd.setCursor(1,0);
            lcd.print(F("Reset Settings"));
            lcd.setCursor(2,1);
            if (EEPROM.read(EEreset) == 255)
              lcd.print("Yes (Restart)");
            else lcd.print("    No");
          }

        break;
        case 5://Info Screen, match this to print statment above
          if (updateScreen > 0){
            lcd.setCursor(1,0);
            lcd.print(F("Software Info"));
            lcd.setCursor(0,1);
            lcd.print("V");
            lcd.print(softwareVersion,2);
            lcd.print("+ Unit:");
            if (EEPROM.read(EEModelNumberHi) == 255)
              intPrint(EEPROM.read(EEModelNumberLo), 3);
            else intPrint(word(EEPROM.read(EEModelNumberHi),EEPROM.read(EEModelNumberLo)), 3);
          }
        break;
        case 6://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
      }//Settings Order Case Switch End
  break;
  case AdvancedMenu://Menu for advanced options *******************************************************************************************            

    if (btnCheck(btnTopLeft))
      --advSettingsOrder;

    if (btnCheck(btnTopRight))
      ++advSettingsOrder;
      
    rollover(advSettingsOrder, 1, 7);
      
    if (updateScreen > 0){
      lcd.noCursor(); 
      lcd.clear();
      menuArrows();
    }
      
    switch(advSettingsOrder)
      {
        case 1://Bluetooth*************                      
          if (btnCheck(btnBottomLeft) && EEPROM.read(EEbluetooth) > 0) //Decrease
            EEPROM.update(EEbluetooth, EEPROM.read(EEbluetooth) - 1);
            
          if (btnCheck(btnBottomRight) && EEPROM.read(EEbluetooth) < 2)
            EEPROM.update(EEbluetooth, EEPROM.read(EEbluetooth) + 1);

        if (updateScreen > 0){
          lcd.setCursor(3,0);
          lcd.print(F("Bluetooth"));
          lcd.setCursor(4,1);
          switch (EEPROM.read(EEbluetooth))
            {
              case 0:
                lcd.print("Disabled");
              break;
              case 1:
                lcd.print("On: Fast");
              break;
              case 2:
                lcd.print("On: Slow");
              break;
            }
          //lcd.print(btDelay);
        }

        break;
        case 2://Gyroscope*************          
          if (btnCheck(btnBottomLeft) && EEPROM.read(EEgyroscope) > 0)
            EEPROM.update(EEgyroscope, EEPROM.read(EEgyroscope) - 1);

          if (btnCheck(btnBottomRight) && EEPROM.read(EEgyroscope) < 2)
            EEPROM.update(EEgyroscope, EEPROM.read(EEgyroscope) + 1);
          
          if (updateScreen > 0){
            lcd.setCursor(3,0);
            lcd.print(F("Gyroscope"));
            lcd.setCursor(2,1);
            switch (EEPROM.read(EEgyroscope))
            {
              case 0:
                lcd.print("  Disabled");
              break;
              case 1:
                lcd.print("On: Standard");
              break;
              case 2:
                lcd.print(" On: Clock");
              break;
            }
          }

        break;
        case 3://gyroscope Calibrate*************              
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = GyroCalibrateMenu;

          if (updateScreen > 0){
            lcd.setCursor(3,0);
            lcd.print(F("Gyroscope"));
            lcd.setCursor(3,1);
            lcd.print("Calibrate?");
          }
        break;
        case 4://Fuel Pressure Sensor Pin Select
          if (btnCheck(btnBottomLeft))//decrease
            EEPROM.update(EEfuelPressurePin, voltPin(SUB, EEPROM.read(EEfuelPressurePin)));

          if (btnCheck(btnBottomRight))//increase
            EEPROM.update(EEfuelPressurePin, voltPin(ADD, EEPROM.read(EEfuelPressurePin)));


          if (updateScreen > 0){            
            lcd.setCursor(2,0);
            lcd.print(F("Fuel PSI Pin"));
            lcd.setCursor(5,1);
            voltPin(PRINT, EEPROM.read(EEfuelPressurePin));
          }
          break;
        case 5://usb Output*************              
          if (btnCheck(btnBottomLeft) && EEPROM.read(EEusbOutput) > 0)
            EEPROM.update(EEusbOutput, EEPROM.read(EEusbOutput) - 1);

          if (btnCheck(btnBottomRight) && EEPROM.read(EEusbOutput) < 3)
            EEPROM.update(EEusbOutput, EEPROM.read(EEusbOutput) + 1);

          if (updateScreen > 0){
            lcd.setCursor(3,0);
            lcd.print(F("USB Output"));
            lcd.setCursor(3,1);
            switch (EEPROM.read(EEusbOutput))
            {
              case 0:
                lcd.print(" Disabled");
              break;
              case 1:
                lcd.print("  Normal");
              break;
              case 2:
                lcd.print("   Raw");
              break;
              case 3:
                lcd.print("Passthrough");
              break;
            }
          }
        break;
        case 6://usb upload reboot*************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            _reboot_Teensyduino_();//invokes Teensy Reboot to allow TeensyLoader access without having to press the button TEENSY

        if (updateScreen > 0){
          lcd.setCursor(1,0);
          lcd.print(F("USB REM Update"));
          lcd.setCursor(4,1);
            lcd.print("Reboot?");
        }  
        break;
        case 7://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
    }//update Screen end
  break;
  case WidebandMenu://wideband settings menu**************************************************************             
    if (btnCheck(btnTopLeft))
      --advSettingsOrder;

    if (btnCheck(btnTopRight))
      ++advSettingsOrder;
      
    rollover(advSettingsOrder, 1, 5);
      
    if (updateScreen > 0){
      lcd.clear();
      menuArrows();
      lcd.noCursor(); 
    }
      
    switch(advSettingsOrder)
      {
        case 1://Wideband o2 pin*************                     
          if (btnCheck(btnBottomLeft))//decrease
            EEPROM.update(EEwidebandPin, voltPin(SUB, EEPROM.read(EEwidebandPin)));

          if (btnCheck(btnBottomRight))//increase
            EEPROM.update(EEwidebandPin, voltPin(ADD, EEPROM.read(EEwidebandPin)));


          if (updateScreen > 0){            
            lcd.setCursor(2,0);
            lcd.print(F("Wideband Pin"));
            lcd.setCursor(5,1);
            voltPin(PRINT, EEPROM.read(EEwidebandPin));
          }
        break;
        case 2://Wideband o2 range*************                      
          if (btnCheck(btnBottomLeft))
            EEPROM.update(EEwideband, bitRanger(SUB, EEPROM.read(EEwideband), B11)); //does math to specific bit range
          
          if (btnCheck(btnBottomRight))
            EEPROM.update(EEwideband, bitRanger(ADD, EEPROM.read(EEwideband), B11)); //does math to specific bit range
            
          if (updateScreen > 0){ 
            centerPrint(F("Wideband Range"),0);
            lcd.setCursor(1,1);
            switch (EEPROM.read(EEwideband) & B11) //bitmask to only read first 2 bits
            {
              case B00:
                lcd.print(" 8.5 - 18 AFR");
              break;
              case B01:
                lcd.print(" 9.0 - 16 AFR");
              break;
              case B10:
                lcd.print("  10 - 20 AFR");
              break;
              case B11:
                lcd.print("7.4 - 22.4 AFR");
              break;
            }
          }
        break;
        case 3://Wideband o2 tuner*************                      
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight)){ //bit flip
            EEbitFlipper(EEwideband, 2);
          }

          if (updateScreen > 0){
            centerPrint(F("Wideband Tuner"),0);
            switch (bitRead( EEPROM.read(EEwideband), 2))
            {
              case 0:
                centerPrint("Off", 1);
              break;
              case 1:
                centerPrint("On (Sig Out)", 1);
              break;
            }
          }
        break;
        case 4://Wideband o2 loop helper*************                      
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight)){ //bit flip
            EEbitFlipper(EEwideband, 3);
          }

          if (updateScreen > 0){
            centerPrint(F("CLS-Loop Saver"),0);
            switch (bitRead( EEPROM.read(EEwideband), 3))
            {
              case 0:
                centerPrint("Off", 1);
              break;
              case 1:
                centerPrint("On", 1);
              break;
            }
          }
        break; 
        case 5://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
    }//update Screen end
  break;
  case GyroCalibrateMenu://Gyro calibration menu**********************************************************        
    if (btnCheck(btnTopLeft)) //Return Case****
      menuOrder = AdvancedMenu;

    if (btnCheck(btnTopRight)){ //Increase case****
      if (gyroCaliOrder == false) //Low
        EEPROM.update(EErollOffset, EEPROM.read(EErollOffset) + 1);
      else //if (gyroCaliOrder == true)
        EEPROM.update(EEpitchOffset, EEPROM.read(EEpitchOffset) + 1);
    }       

    if (btnCheck(btnBottomLeft)) //Move case**********
        gyroCaliOrder = !gyroCaliOrder;
 
    if (btnCheck(btnBottomRight)){ //Decrease case********* 
      if (gyroCaliOrder == false) //Low
        EEPROM.update(EErollOffset, EEPROM.read(EErollOffset) - 1);
      else //if (gyroCaliOrder == true)
        EEPROM.update(EEpitchOffset, EEPROM.read(EEpitchOffset) - 1);
    }                 

    if (EEPROM.read(EErollOffset) == 255)
      EEPROM.update(EErollOffset, 128);
    if (EEPROM.read(EEpitchOffset) == 255)
      EEPROM.update(EEpitchOffset, 128);

    
    if (updateScreen == menu){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print(F("^ Level Offset +"));
      lcd.setCursor(0,1);
      rightArrow();
      lcd.setCursor(15,1);
      lcd.print("-");
    }

    if (updateScreen > 0 || updateTimedScreen == true){
      lcd.cursor();        
      lcd.setCursor(1,1);
      if ((EEPROM.read(EErollOffset)-128) >= 0)
        lcd.print(" ");
      lcd.print((EEPROM.read(EErollOffset)-128));
      if (abs((EEPROM.read(EErollOffset)-128)) < 10)
        lcd.print(" ");

      displayGyro();

      if ((EEPROM.read(EEpitchOffset)-128) >= 0)
        lcd.print(" ");
      lcd.print((EEPROM.read(EEpitchOffset)-128));
      if (abs((EEPROM.read(EEpitchOffset)-128)) < 10)
        lcd.print(" ");

      if (gyroCaliOrder)
        lcd.setCursor(13,1);
      else
        lcd.setCursor(2,1);
     
    }
  break;
  case TimeMenu://Menu for setting the Real Time Clock and Options ************************************************************************              

    if (timeMenuOrder < 8){ //don't interact in time menu
      if (btnCheck(btnTopLeft)){
        if (timeMenuOrder <= 1)
          timeMenuOrder = 7; //skip time menu
        else
          --timeMenuOrder;
        lcd.clear();
      }
    }

    if (timeMenuOrder < 8) {
      if (btnCheck(btnTopRight)){
        if (timeMenuOrder == 7)
            timeMenuOrder = 1; //skip time menu
          else
            ++timeMenuOrder;
        lcd.clear();
      }
    }
    rollover(timeMenuOrder, 1, 8);

    if (updateScreen == menu)
      lcd.clear();
      
    if (updateScreen > 0){      
      lcd.setCursor(0,0);
      lcd.print("<");
      lcd.setCursor(0,1);
      leftArrow();
      
      lcd.setCursor(15,0);
      lcd.print(">");
      lcd.setCursor(15,1);
      rightArrow();
    } 
                 
    switch(timeMenuOrder){
      case 8: //Time edit menu, skip in main scroll
        if (btnCheck(btnTopRight)){ 
              setTimeSetpoint(now()); //save setpoint to current time
              timeMenuOrder = 1; //go back
              lcd.clear();
            }

            rtcTimeAdjustMenu(); 
            break;
      case 1:          
         if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
          timeMenuOrder = 8;//jump to skipped time menu
        
        if (updateScreen > 0 || updateTimedScreen){
          lcd.noCursor();
          lcd.setCursor(4,0);
          displayTime();
          lcd.setCursor(4,1);
          lcd.print(F("Set Time?"));
        }
      break;
      case 2: //time drift edit window
        if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
          menuOrder = timeDriftMenu;
        
        if (updateScreen > 0){
          lcd.noCursor();
          lcd.setCursor(2,0);
          lcd.print(F("Drift Adjust"));
          lcd.setCursor(5,1);
          lcd.print("Edit?");
        }
      break;
      case 3://24 hour               
        if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
          show12Hours = !show12Hours;//Boolean variable, neat trick to switch the value to true or false
        
        if (updateScreen > 0){
          lcd.noCursor();
          lcd.setCursor(2,0);
          lcd.print(F("Hour Format"));
          lcd.setCursor(4,1);
          if (show12Hours == true)
            lcd.print("12 Hour");
          else 
            lcd.print("24 Hour");
        }
        
        EEPROM.update(EEhourSetting, show12Hours);
      break;
      case 4://home screen clock              
        if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
          homeScreen = !homeScreen;

        if (updateScreen > 0){
          lcd.noCursor();
          lcd.setCursor(3,0);
          lcd.print("Home Clock");
          lcd.setCursor(4,1);
          if (homeScreen == true)
            lcd.print("Enabled ");//that space is important
          else 
            lcd.print("Disabled");
        }
        
        EEPROM.update(EEhomeScreen, homeScreen);
      break;
      case 5://clockMode
        if (btnCheck(btnBottomLeft)  && EEPROM.read(EEclockMode) > 0)
          EEPROM.update(EEclockMode, EEPROM.read(EEclockMode) - 1);

        if (btnCheck(btnBottomRight)){           
          if (EEPROM.read(EEclockMode) < 4)
            EEPROM.update(EEclockMode, EEPROM.read(EEclockMode) + 1);
          else
            EEPROM.update(EEclockMode, 4);
        }

        if (updateScreen > 0){
          lcd.setCursor(2,0);
          lcd.print("Clock Display");
          lcd.setCursor(4,1);

          switch (EEPROM.read(EEclockMode))
          {
            case 0://off
              lcd.print("  Off  ");
              asWrite(0x0C, 0x00); //display off command
            break;
            case 1://low
              lcd.print("  Low  ");
              asWrite(0x0C, 0x01); //display on command
              asWrite(0x0A, 0x01); // set intensity,XA is global, 0 - F
            break;
            case 2://med
              lcd.print("  Med  ");
              asWrite(0x0C, 0x01);
              asWrite(0x0A, 0x07);
            break;
            case 3://high
              lcd.print("  High  ");
              asWrite(0x0C, 0x01);
              asWrite(0x0A, 0x0F);
            break;
            case 4://auto dim
              lcd.print("Auto Dim");
              asWrite(0x0C, 0x01);
            break;
          }           
        }  
      break;
      case 6://Dim menu*******************************
        if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
          menuOrder = clockDimMenu;
        centerPrint(F("Auto Dim"), 0);
        centerPrint(F("Calibrate?"), 1);
      break;
      case 7://Back*************************************
          if (btnCheck(btnBottomLeft) || btnCheck(btnBottomRight))
            menuOrder = SettingsMenu;
          centerPrint(F("Menu"), 0);
          centerPrint(F(" Back?"), 1);
        break;
    }//timeOrder switch case end
  break;
  case clockDimMenu://Clock Display Dim menu**********************************************************        
    if (btnCheck(btnTopRight)) //Return Case****
      menuOrder = TimeMenu;

    if (btnRepeat(btnTopLeft)){ //Increase case****
      if (clockDimOrder == false && EEPROM.read(EEclockLowDim) < 15) //Low
        EEPROM.update(EEclockLowDim, EEPROM.read(EEclockLowDim) + 1);
      else if (clockDimOrder == true && EEPROM.read(EEclockHighDim) < 15)
        EEPROM.update(EEclockHighDim, EEPROM.read(EEclockHighDim) + 1);
      btnPrev = lcdKey;
    }       

    if (btnCheck(btnBottomRight)) //Move case**********
      clockDimOrder = !clockDimOrder; 
  
    if (btnRepeat(btnBottomLeft)){ //Decrease case*********
      if (clockDimOrder == false && EEPROM.read(EEclockLowDim) > 0)
        EEPROM.update(EEclockLowDim, EEPROM.read(EEclockLowDim) - 1);
      else if (clockDimOrder == true && EEPROM.read(EEclockHighDim) > 0)
        EEPROM.update(EEclockHighDim, EEPROM.read(EEclockHighDim) - 1);
      btnPrev = lcdKey;
    }                 

    if (EEPROM.read(EEclockHighDim) > 15)
      EEPROM.update(EEclockHighDim, 15);
    if (EEPROM.read(EEclockLowDim) > 15)
      EEPROM.update(EEclockLowDim, 15);
    
    if (updateScreen == menu){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print("+  Dimmed:");
      lcd.setCursor(0,1);
      lcd.print("-  Bright:");
      lcd.setCursor(15,0);
      lcd.print("^");
      lcd.setCursor(15,1);
      lcd.print(">");
    }
    
    if (updateScreen > 0 || updateTimedScreen == true){
      if (clockDimOrder){ //High
        lcd.setCursor(2,0);
        lcd.print(" ");
        lcd.setCursor(2,1);
        rightArrow();
        asWrite(0x0A, EEPROM.read(EEclockHighDim));
      }
      else{
        lcd.setCursor(2,1); //High
        lcd.print(" ");
        lcd.setCursor(2,0);
        rightArrow();
        asWrite(0x0A, EEPROM.read(EEclockLowDim));
      }
        
      lcd.setCursor(11,0);
      intPrint(EEPROM.read(EEclockLowDim) + 1, 2); //Display 1 to 16
      
     lcd.setCursor(11,1);
      intPrint(EEPROM.read(EEclockHighDim) + 1, 2); //Display 1 to 16
    }
    autoDimTestFlag = true;
  break;
  case timeDriftMenu://RTC Time Drift Adjust menu********************************************************** 
    const byte DRIFTHOME = 0;
    const byte SYNCADJUST = 1;
    const byte DRIFTADJUST = 2;
    const byte RESETMENU = 3;

    static byte driftMenuSelector = 0; //main menu selector
    static byte syncMenuSelector = 1; //sync menu selector
    
    switch(driftMenuSelector) {   
      case DRIFTHOME: //home menu
        static byte index = 1;          
        upDownArrowScroller(index, 1, 4);

        if (updateScreen > 0){
          lcd.clear();

          rightArrow();
          upDownArrows();

          scrollPrint(1, "Edit Sync Mark", index);
          scrollPrint(2, "Edit Drift Sec", index);
          scrollPrint(3, "Reset Values?", index);
          scrollPrint(4, "Back?", index);
        
        }
        
        if (btnCheck(btnTopLeft)) {
          switch(index) {
            case 1:
              driftMenuSelector = SYNCADJUST;
              syncMenuSelector = 1; //reset just incase
            break;
            case 2:
              driftMenuSelector = DRIFTADJUST;
            break;
            case 3:
              driftMenuSelector = RESETMENU;
            break;
            case 4:
              menuOrder = TimeMenu;
            break;
          }
        }
      break;
      case SYNCADJUST:
      /*
      1. Sync Mark View
      2. Set Time Dialog
      3. Time Adjust Menu
      4. 1 Week Dialog
      */
        switch(syncMenuSelector){
          case 1: //Sync Mark viewer
            if (btnCheck(btnTopLeft))
               driftMenuSelector = DRIFTHOME;
            if (btnCheck(btnBottomRight)) 
              syncMenuSelector += 1; //go to next screen
              
            if (updateScreen > 0){
              lcd.clear();

              lcd.print("^Last Sync ");
              if (getTimeSetpoint() == 0)
                lcd.print("__:__"); //show blank if 0
              else
                displayTimeCustom(getTimeSetpoint(), false, false);
              
              lcd.setCursor(1,1);
              if (getTimeSetpoint() == 0)
                lcd.print("__/__/__");
              else
                displayDate(getTimeSetpoint());
              lcd.print(" Edit?");
              rightArrow(); 
              //----------------
              //^Last Sync 11:22
              //11/22/33  Edit?>
                                 
            }
            break;
          case 2: //New Setpoint needed
            if (btnCheck(btnTopLeft))
               syncMenuSelector -= 1; //go to prev screen
            if (btnCheck(btnBottomRight)) 
              syncMenuSelector += 1; //go to next screen
              
            if (updateScreen > 0){
              lcd.clear();
              lcd.print("Set Current Time");
              lcd.setCursor(0,1);
              lcd.print("to the Second  ");
              rightArrow();                      
            }
            break;
          case 3: //set correct time and save setpoint
            if (btnCheck(btnTopRight)){ 
              setTimeSetpoint(now()); //save setpoint to current time
              syncMenuSelector += 1; //go to next screen
            }

            rtcTimeAdjustMenu(); 
            break;
          case 4: //wait screen
            if (btnCheck(btnBottomRight)) 
              driftMenuSelector = DRIFTHOME; //go home
              
            if (updateScreen > 0){
              lcd.clear();
              lcd.noCursor();
              lcd.print("Edit Drift after");
              lcd.setCursor(0,1);
              lcd.print("one week.  [OK]");
              rightArrow();                      
            }
            break;
        }   
      break;
      case DRIFTADJUST:
        if (btnCheck(btnTopLeft)) //go back
          driftMenuSelector = DRIFTHOME;

        if (btnRepeat(btnBottomLeft)) //decrease
          setTimeDriftRate(-0.5);
        if (btnRepeat(btnBottomRight)) //increase
          setTimeDriftRate(0.5); //BUG, when set to 0.1, can't move past 2.1 or -2.1, no idea why so 0.5 it is...

        if (updateTimedScreen > 0 || updateScreen > 0){
          lcd.clear();

          lcd.print("^New T= ");
          displayTimeCustom(driftTimeNow(), true, true);

          lcd.setCursor(0,1);
          leftArrow();
          lcd.setCursor(2,1);
          floatPrint(getTimeDriftRate(), 5, 1);
          lcd.print(" sec/wk");
          lcd.setCursor(15,1);
          rightArrow();
        }
      break;  
      case RESETMENU:
        if (btnCheck(btnTopLeft) || btnCheck(btnBottomLeft)) //go back
          driftMenuSelector = DRIFTHOME;

        if (btnCheck(btnBottomRight)) { //reset
          setTimeDriftRate(0); //resets value
          setTimeSetpoint(0);
          driftMenuSelector = DRIFTHOME;
        }

        if (updateScreen > 0){
          lcd.clear();

          lcd.print("^ Reset Values?");
          lcd.setCursor(0,1);
          leftArrow();
          lcd.print(" [NO]   [YES] ");
          rightArrow();
        }
      break;
    }
    
    //if (updateScreen > 0 || updateTimedScreen == true){  
   // }
  break;
  }//Root Menu System Case Switch End

//Update Speed option time based screen refresh
  if (millis() > screenTimer + updateSpeed*10){
    screenTimer = millis();
    updateTimedScreen = true;
  }
  else updateTimedScreen = false;

//menu and button change based screen refresh    
  if (menuPrev != menuOrder){ //used to refresh screen only during menu change
    menuPrev = menuOrder;
    updateScreen = menu;
  }
  else if (lcdKey != btnNone && screenBtnFlag == false){//button based screen refresh, this will cause screen to flicker if held continously, menudelay prevents that
    updateScreen = buttons;
    screenBtnFlag = true;//used to prevent flip-flop update loop 
  }
  else updateScreen = 0;

  if (lcdKey == btnNone && screenBtnFlag == true)
    screenBtnFlag = false;

  if (lcdKey == btnNone)//resets button variable if nothing is pressed
    btnPrev = lcdKey; //used to debounce button press
    
}//Loop End
/* 
 *  lcd.print(F) Macro notes: Great way to free up RAM when lots of lcd.print commands are used but requires selective use.
 *  Usually you are trading a little bit of Program Space to free up a little bit more Ram. After a bit you may notice PS doesn't change
 *  but the Ram can keep going down drastically but one command may sky rocket the PS and not change Ram at all. I feel like text inside 
 *  if statements usually don't help and symbols, long spaces, and 1 letter prints usually don't help either. Brute Force 1 by 1 and check
 *  results saved over 600 bytes of ram by carefully choosing which ones to use, and thats after use of some previous (F) Macros.
  
  //lcdKey = readLcdButtons();//blank button template
  switch(lcdKey)
  {
    case btnTopLeft:
      if (btnCheck()){
        
      }
    break;
    case btnTopRight:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
    case btnBottomLeft:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
    case btnBottomRight:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
  }
    */
/*center of 16 line screen  
         ________________
               1        =7
               22       =7
              333       =6
              4444      =6
             55555      =5
             666666     =5
            7777777     =4
            88888888    =4
           999999999    =3
           1010101010   =3
          11111111111   =2
          121212121212  =2
         1313131313131  =1
         14141414141414 =1
        151515151515151 =0
        1616161616161616=0
 */
  /*
    //Debug bamf- /t is insert tab. Prints binary version (marking print() with x,BIN doesn't print preceding zeroes), hex and denary. Needs a lot of Terminal window lines.
    for (Position=0;Position<31;Position++){
    Serial.print("Byte ");
    Serial.print(Position);
    Serial.print("\t");
    Serial.print(bitRead(dataStream[Position],7));
    Serial.print(bitRead(dataStream[Position],6));
    Serial.print(bitRead(dataStream[Position],5));
    Serial.print(bitRead(dataStream[Position],4));
    Serial.print(bitRead(dataStream[Position],3));
    Serial.print(bitRead(dataStream[Position],2));
    Serial.print(bitRead(dataStream[Position],1));
    Serial.print(bitRead(dataStream[Position],0));
    Serial.print("\t");
    Serial.print(dataStream[Position],HEX);
    Serial.print("  \t");
    Serial.print(dataStream[Position]);
    Serial.println("\e[K");  // clear to end of line
    }
    //End debug
  */
  /*
    Glossary
      From what I have researched, this is the framing- it isn't correct for some on the GTA. Still working on it. 
      Jeep Data points updated by Nick Risley. *'s indicate Phils old vlaues that i have not been able to verify 
    Byte   : 4.0L Jeep              / 4 cyl renix (R21 turbo)   / 13,32 2.0 F3R AMC GTA (confirmed)
    Byte 0 : Program Version  1 & 2 / Program Version           / Program Version
    Byte 1 : PROM Version     3 & 4 / PROM Version              / PROM version
    Byte 2 : Calibration code 5 & 6 / Engine run flags (bin)    / Switch values. C = engine off, nothing selected. 4 = off idle stop
    Byte 3 : MAP                    / MAP                       / MAP
    Byte 4 : CTS                    / CLT                       / CLT
    Byte 5 : IAT                    / IAT                       / IAT
    Byte 6 : Battery Volts          / Battery Volts             / Battery Volts
    Byte 7 : Oxygen sensor          / Oxygen sensor
    Byte 8 : RPM LO byte            / RPM LO Byte               / RPM LO
    Byte 9 : RPM HI byte            / RPM HI byte               / RPM HI
    Byte 10: 9th & 10th PROM        / Inj pulsewidth LO byte    / Injector Pulse LO
    Byte 11: 7th & 8th PROM         / Inj pulsewidth HI byte    / Injector Pulse HI
    Byte 12: Throttle position      / Knock sensor
    Byte 13: Advance degrees        / Advance degrees           / Throttle Position
    Byte 14: *unknown               / Control
    Byte 15: *ECT_ADC               / Turbo correction value
    Byte 16: Baro before start      / unknown
    Byte 17: *Mode                  / Failure flags  %
    Byte 18: Loop/Exhaust/EGR, *ALFA - (byte/10=air ratio) {14.7:1) / Road speed
    Byte 19: Pulse width            / throttle stop
    Byte 20: *..?                   / Throttle position
    Byte 21: Throt Sw/Fuel Sync     / System Board Error flags %%
    Byte 22: *Advance + knock mask  / ..?
    Byte 23: *warmup                / warmup
    Byte 24: ST Fuel Trim           / Stored errors %%%
    Byte 25: *temperature adc errors / recent errors %%%
    Byte 26: LT Fuel Trim           / Advance + knock correction
    Byte 27: Knock                  / Barometric pressure before start
    Byte 28: *..?                   / Adjustment off MAP
    Byte 29: A/C Sw/Request         / Switch values %%%%         / Switches possibly. changes when air is selected, makes sense
    Byte 30: 11th & 12th PROM       / Errors %%%%%
    For bitRead(x,y) x=value byte, y= position where bit 7 = 128/msb, bit 0 = 1/lsb
    % 7:Bad injector/6:TDC unable to be found/5:Roadspeed/4:Fuel pump/3:MAP bad/2:Knock sensor bad/1:Crank Pos Sens bad/0:unkown
    %% 7:Bad PROM version/6:Injector circuit fault/5:CPS variance/4:EEPROM CRC/3:ROM CRC/2~0:unknown
    %%% 7:TPS open/6:TPS short/5:CTS open/4:CTS short/3:IAT open/2:IAT short/1:EGR open/0:EGR short
    %%%% 7:Unknown/6:unknown/5:Sync(cam pos on 6pot?)/4:unknown/3:starter/2:AC engage/1:AC request/0:PARK (gears)
    %%%%% 7:Ignition module bad/6~4:unknown/3:oxygen relay/2:latch relay/1:aircon relay/0:unknown
  */
