//Code to do with activating the Check Engine Light goes here.

byte celCurrArray[celArrayTotal / 8 + 1]; //currently active CEL
byte celPrevArray[celArrayTotal / 8 + 1]; //previously tripped CEL
 

// will set true or false for selected cel number****************************
/*void setCELCode(byte input)
{
  byte aSPOT = input / 8;
  byte aBIT  = input % 8;

  bitSet(celCurrArray[aSPOT], aBIT); //currently active CEL 
  bitSet(celPrevArray[aSPOT], aBIT); //previously tripped CEL
}*/

// will clear whole array for reset****************************
void resetCEL(bool TYPE)
{
  for(byte count = 0; count < celArrayTotal; count++)
  {
    if (TYPE == true)
      celBitmapArray[count] = 0; //currently active CEL Checks
    else{
      celFaultArray[count] = 0; //previously tripped CEL
      celGlitchArray[count] = 0;
    } 
  }
}


/*
byte celBitmapArray[celArrayTotal]; //7-0,  Fault, Glitch, L2, L1, L0
unsigned long celStopwatchArray[celArrayTotal]; //last initial trigger time 
//word celPrevTimeArray[celArrayTotal]; //last final active time
byte celFaultArray[celArrayTotal]; //Fault Count
byte celGlitchArray[celArrayTotal]; //Glitch Count
*/

// CEL timer and glitch check function**********************************
void celTester(byte ArraySpot, bool Test, int WaitTime, byte Gauge){
  if (Test == true){
    //bitSet(celBitmapArray[ArraySpot], 0);             //loop zero, helps prevent resets if called multiple times a loop
    
    if (bitRead(celBitmapArray[ArraySpot], 2) == false && bitRead(celBitmapArray[ArraySpot], 1) == true){ //second loop
      bitSet(celBitmapArray[ArraySpot], 2); //set 2nd loop flag
      bitSet(celBitmapArray[ArraySpot], 3); //set glitch flag
    }
      
    if (bitRead(celBitmapArray[ArraySpot], 1) == false){                                                  //first loop
      bitSet(celBitmapArray[ArraySpot], 1);    //set 1st loop flag
      celStopwatchArray[ArraySpot] = millis(); //record initial trigger time
    }

    //if (bitRead(celBitmapArray[ArraySpot], 2) == true)                                                  //second & > loops
      //celPrevTimeArray[ArraySpot] = millis() / 1000; //record latest active time

    if (bitRead(celBitmapArray[ArraySpot], 4) == false && millis() > celStopwatchArray[ArraySpot] + WaitTime){ //cel delay timer check
      bitClear(celBitmapArray[ArraySpot], 3);  //reset glitch flag
      bitSet(celBitmapArray[ArraySpot], 4);    //set Fault check flag
      if (celFaultArray[ArraySpot] < 255)
        ++celFaultArray[ArraySpot];            //increment fault count
    }
    
  }
  else{
    if (bitRead(celBitmapArray[ArraySpot], 3) == true && celGlitchArray[ArraySpot] < 255)                 //glitch flag check
      ++celGlitchArray[ArraySpot];             //increment glitch fault count
    //if (bitRead(celBitmapArray[ArraySpot], 0) == false) //check global trip flag
      celBitmapArray[ArraySpot] = 0;           //reset all flags 
  }
  
  if (bitRead(celBitmapArray[ArraySpot], 4) == true)
    celStar(Gauge); //Draw * on affected gauge
}

// will return number of true codes in array**********************************
byte countCELCode(bool TYPE) 
{
  byte counter = 0;

  for (int ARRAY = 0; ARRAY < celArrayTotal; ARRAY++) //for loop advances to next array slot
  {
    if (TYPE == true)   //currently active CEL
    {
      if (bitRead(celBitmapArray[ARRAY], 4))// || bitRead(celBitmapArray[ARRAY], 3))  //check bitmap array
        ++counter;                            
    }
    else                //previously active CEL
    {
      if (celFaultArray[ARRAY] > 0)// || celGlitchArray[ARRAY] > 0)  //check counter arrays
        ++counter;                            
    }
  }
  
  return counter;
}

// will return true or false for selected cel number*************************
bool checkCELCode(byte ARRAY, bool TYPE)
{
  celPrevReading = ARRAY; //needed for celExpand in other functions
  
  if (TYPE == true)   //currently active CEL
  {
    if (bitRead(celBitmapArray[ARRAY], 4)) //|| bitRead(celBitmapArray[ARRAY], 3))  //check bitmap array
      return true;
    else
      return false;                            
  }
  else                //previously active CEL
  {
    if (celFaultArray[ARRAY] > 0)// && celBitmapArray[ARRAY] == 0)  //check counter arrays ... || celGlitchArray[ARRAY] > 0  
      return true; 
    else
      return false;                         
  }
}
/*
// CEL ARRAY Master Log Warn  Fail  Wait
     MAPL         = 0;        2     2s
1052 MAPH         = 1;        253   2s
     BARL         = 2;        85    2s
1054 CTSL         = 3;        2     2s
1055 CTSH         = 4;  245   253   2s           
1016 IATL         = 5;        2     2s
1017 IATH         = 6;  232   253   2s
1004 VoltL        = 7;  12.6  12.0  15s    
     VoltH        = 8;  15    15.5  15s
     CrankVL      = 9;        10.0  2s
1065 o2L          = 10;       2     45s
1066 o2H          = 11;       253   45s
1002 o2HeatL      = 12;       10.0  5s
     stftL        = 13;       2     1s
     stftH        = 14;       253   1s
     RPMD         = 15;       0     3s
1050 RPML         = 16;       500   5s
1051 RPMH         = 16;       2000  5s?
     RPMH         = 17;       5020  2s
1037 TPSL         = 18; 25    2     2s
     TPSH         = 19; 245   253   2s
1058 KnockH       = 20; 100   240   1s
     KnockD       = 21;       0     30s
1020 SyncD        = 22;       0     10s
     INJH         = 23; 80          1s

Count times triggered, glitch & long
last millis triggered



sensor ranges
map 2 - 253
cts 2 - 253
iat 2 - 253
tps 2 - 253
batt 195 - 253
low crank voltage < 10 when starter
Knock no response 0
knock too high 100  
o2 stuck high
o2 heater < 10v    
closed loop fails
dizzy no response   
RPM 500 - 2000 idle
RPM 5000 max
*/

boolean celRequest = false;
//boolean celFlag = false;
unsigned long celTimer = 0;

void updateCEL (){ 
  celStarBitmap = 0;
  //celStar(TPSGauge);
  //celTester(TPSH, dataStream[12] > 80, 10, TPSGauge); //test
  if (cel == 3) //CEL Warning Mode Differences ONLY
  {
    celTester(CTSH, CTSRaw > 245,  2000, CTSGauge);
    celTester(IATH, IATRaw > 232,  2000, IATGauge);
    celTester(TPSL, dataStream[12] < 25,  2000, TPSGauge);
    celTester(TPSH, dataStream[12] > 245, 2000, TPSGauge); //245
    //celTester(TPSH, true, 2000, TPSGauge); //test
    
    if (engineRunFlag == true) //CEL's for Engine Running
    {
      celTester(VoltL, Volts < 12.6, 2000, voltGauge);
      celTester(VoltH, Volts > 15.0, 2000, voltGauge);
      celTester(INJH, InjDuty > 80.0, 1000, IDCGauge);
      if (engine == 4)
        celTester(KnockH, Knock > 100, 1000, knockGauge);
    }
  }
  else //CEL Faliure Mode Differences ONLY
  {
    celTester(CTSH, CTSRaw > 253,  2000, CTSGauge);
    celTester(IATH, IATRaw > 253,  2000, IATGauge);
    celTester(TPSL, dataStream[12] < 3,   2000, TPSGauge);
    celTester(TPSH, dataStream[12] > 252, 2000, TPSGauge);
    //celTester(TPSH, dataStream[12] > 80, 2000, TPSGauge); //test
    
    if (engineRunFlag == true) //CEL's for Engine Running
    {
      celTester(VoltL, Volts < 12.0, 2000, voltGauge);
      celTester(VoltH, Volts > 15.5, 2000, voltGauge);
    }
  }
    
  //Standard CELs for both Mode
  celTester(MAPL, MAPRaw < 2,    2000, MAPGauge);
  celTester(MAPH, MAPRaw > 253,  2000, MAPGauge);
  celTester(BARL, BaroRaw < 85,  2000, nullGauge);
  celTester(CTSL, CTSRaw < 2,    2000, CTSGauge);
  celTester(IATL, IATRaw < 2,    2000, IATGauge);
  celTester(CrankVL, Volts < 10.0 && Starter == true, 1500, nullGauge);
  celTester(RPMD, RPM < 350 && Starter == true,  2500, RPMGauge);
  
  if (engineRunFlag == true) //CEL's for Engine Running
  {
    celTester(VoltL, Volts < 12.0, 2000, voltGauge);
    celTester(VoltH, Volts > 15.5, 2000, voltGauge);
    celTester(o2L, dataStream[7] < 2,    45000, lambdaGauge);
    celTester(o2H, dataStream[7] > 253,  45000, lambdaGauge);
    celTester(stftL, STFuel < 3,    500, STFGauge);
    celTester(stftH, STFuel > 252,  500, STFGauge);
    celTester(RPML, RPM < 500,  1000, RPMGauge);
    celTester(RPMH, RPM > 5020, 500, RPMGauge);
    if (engine == 4)
    {
      celTester(KnockH, Knock > 240, 1000, knockGauge);
      celTester(KnockD, Knock < 2 && RPM > 1900, 30000, knockGauge);
      celTester(SyncD, dizzyCEL == true, 10000, fsyncGauge);
      if (bitRead( EEPROM.read(EEwideband), 2) == false) //disable if wideband tuner is used
        celTester(o2HeatL, LambdaHeater < 10.0 && RPM < 2600, 5000, heaterGauge);
    }
  }

  //binSPrint(celBitmapArray[TPSH]);
  //Serial.println();
  if (celManualFlag == false) //disables Main CEL light trip code
  {
    switch (cel)
    {
      case 1: //Disable CEL
        celOff();
      break;
      case 2: //Failures
        if (countCELCode(true) > 0)
          celOn();
        else
          celOff();
      break;
      case 3: //Warnings and Failures
        if (countCELCode(true) > 0)
          celOn();
        else
          celOff();
      break;
      case 4: //Shift Light
        if (engineRunFlag == true && RPM > 2100)
          celOn();
        else
          celOff();
      break;
      default: //else
        celOff();
      break;
    }
  }
  celManualFlag = false; //reset trip

    
}//void end
