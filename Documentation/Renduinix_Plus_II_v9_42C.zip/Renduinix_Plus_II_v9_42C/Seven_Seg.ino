//Stuff for the AS1115 Seven Segment IC driver clock goes here
//Some time formating stuff is in the RTC Tab instead

void asWrite(byte address, byte value) { //for writing to the AS1115 7-seg i2c
  
  // transmit to device #0 (0x00)
  Wire.beginTransmission(0x00);
  
  // Send the register address
  Wire.write(address);
  
  // Send the value
  Wire.write(value);

  // stop transmitting
  Wire.endTransmission();
}

int clockBootAnimation()
{
  int delayCounter = 0; // Keep track of delays used

  asWrite(0x0C, 0x80); //turn off display becasuse changing decode will mess with the display
  
  delay(100);
  delayCounter += 100;
  
  asWrite(0x09, 0x00);    // set decode mode, 0 = none, FF = decode all digits
  
  for (byte i = 0; i < 9; i++)
  {
    byte bitloop;
    bitloop = 0xFF;         //start with all bits on
    bitloop = bitloop >> i; //shift 0s in at counter amount
    bitloop = ~bitloop;     //invert so shifted bits are on
    if (i < 8)              //shift 1 to skip decimals till the end
      bitloop = bitloop >> 1; 
    
    asWrite(0x01, bitloop);
    asWrite(0x02, bitloop);
    asWrite(0x03, bitloop);
    asWrite(0x04, bitloop);
    asWrite(0x05, bitloop);//draws colon

    if (i == 0)
      asWrite(0x0C, 0x81); //turn on display after first blanking is written
    
    delay(75);
    delayCounter += 75;
  }
   
  delay(500);
  delayCounter += 500;
/*
//counter rotate test

  for (int i = 8; i >= 0; i--)
  {
    byte digit1 = B00110000; //1
    byte digit2 = B01101101; //2
    byte digit3 = B01111001; //3
    byte digit4 = B01011111; //6
    byte d1;
    byte d2;
    byte d3;
    byte d4;
    
    byte bitloop;
    bitloop = 0xFF;         //start with all bits on
    bitloop = bitloop >> i; //shift 0s in at counter amount
    bitloop = ~bitloop;     //invert so shifted bits are on
    if (i < 8)              //shift 1 to skip decimals till the end
      bitloop = bitloop >> 1;

    d1 = bitloop | digit1;
    d2 = bitloop | digit2;
    d3 = bitloop | digit3;
    d4 = bitloop | digit4;
    
    asWrite(0x01, d1);
    asWrite(0x02, d2);
    asWrite(0x03, d3);
    asWrite(0x04, d4);
    //asWrite(0x05, bitloop);//draws colon

    //if (i == 0)
      //asWrite(0x0C, 0x81); //turn on display after first blanking is written
    binSPrint(bitloop);
    Serial.println();
    
    delay(75);
    delayCounter += 75;
  }

  delay(1000);
  delayCounter += 1000;
//counter test end
*/  
  asWrite(0x09, 0x0F);//decode 0-3, 4 is left raw
/*  
  asWrite(0x01, 0x08);
  asWrite(0x02, 0x08);
  asWrite(0x03, 0x08);
  asWrite(0x04, 0x08);
  asWrite(0x05, 0xE0);//draws colon
*/
/*  asWrite(0x01, 0x0F); //blanks
  asWrite(0x02, 0x0F);
  asWrite(0x03, 0x0F);
  asWrite(0x04, 0x0F);
  asWrite(0x05, 0xE0);
*/
  asWrite(0x05, 0xE0);
    
  return delayCounter;
}

void clockBegin(){
// Turn off 7 seg chip and reset registers incase of program reboot
  //asWrite(0x0C, 0x00); //turn off and reset
  asWrite(0x0C, 0x01); //turn on and reset
  
// set scan limit, 0 - 3 digits
  asWrite(0x0B, 0x04);//colon is connected to the 5th digit

// set decode mode, 0 = none, FF = decode all digits
  asWrite(0x09, 0x0F);//just 0-3, 4 is left raw

// blank out digits to keep screen "off"  
  for(byte i = 0; i <= 5; i++)
    asWrite(i+1, 0x0F);//prints blank instead of 0

// set intensity,XA is global, 0 - F
  switch (EEPROM.read(EEclockMode))
  {
    case 1://low
      asWrite(0x0A, 0x01);
    break;
    case 2://med
      asWrite(0x0A, 0x07);
    break;
    case 3://high
      asWrite(0x0A, 0x0F);
    break;
    case 4://custom
      asWrite(0x0A, EEPROM.read(EEclockHighDim));
    break;
  }

  //if (EEPROM.read(EEclockMode) > 0)
// Turn on chip
      //asWrite(0x0C, 0x81);
}

void updateClock(){
  static unsigned long clockUpdateTimer;
  unsigned int timePrev = 1;

  if (millis() > clockUpdateTimer + 500 && EEPROM.read(EEclockMode) > 0){ //poll throttling to keep the i2c line free
    clockUpdateTimer = millis();
    easyTime(); //get converted time
  
    if (word(Ehour, Eminute) != timePrev){ //only updates clock if the time has changed
      timePrev = word(Ehour, Eminute);//combo of both values in 1 variable, cool
    
    //update display
      if (hrHi > 0)
        asWrite(0x01, hrHi);
      else asWrite(0x01, 0x0F);//prints blank instead of 0
      
      asWrite(0x02, hrLo);
      asWrite(0x03, minHi);
      asWrite(0x04, minLo);
      asWrite(0x05, 0xE0);//draws colon
    }
  }
}
