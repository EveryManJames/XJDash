//Stuff for controlling the free REM pins will go here 

bool updateFan(byte fanNum, byte EEfanPin, bool fanState, byte EEfanMode, byte EEacTrig, byte EEon, byte EEoff){
  if (fanKill == true || 
  (EEPROM.read(EEdualFan) == 1 && fanNum == 1 && fan2State == HIGH) || 
  (EEPROM.read(EEdualFan) == 2 && fanNum == 2 && fan3State == HIGH) ||
  (EEPROM.read(EEdualFan) == 3 && fanNum == 1 && fan3State == HIGH))
    fanState = LOW;
  else{
    switch(EEPROM.read(EEfanMode)){
      case off:
        fanState = LOW;
      break;
      case on:
        fanState = HIGH;
      break;
      case Auto:
        // If AC is on, overrides temp
        if (EEPROM.read(EEacTrig) == true && ACRequest == true)
           fanState = HIGH; 
        else if (CTSRaw >= EEPROM.read(EEon) && fanState == LOW)
           fanState = HIGH;  
        else if (CTSRaw <= EEPROM.read(EEoff) && fanState == HIGH)
          fanState = LOW;     
      break;
    }
  }
  digitalWrite(EEPROM.read(EEfanPin), fanState);
  return fanState; //pass fanState through, set function equal to desired fanState
}

void updateIO(){
//INPUT is the default state of pins as it is high impedance
//analog read/write will automatically set the pinmode as needed

//function to update fan pin and pass the fanState variable back out, MUST be backwards for 2 speed to work

    if (EEPROM.read(EEfan3Pin) != 0){
      pinMode(EEPROM.read(EEfan3Pin), OUTPUT);
      fan3State = updateFan(3, EEfan3Pin, fan3State, EEfan3Mode, EEac3Trigger, EEtemp3on, EEtemp3off);
    }

    if (EEPROM.read(EEfan2Pin) != 0){
      pinMode(EEPROM.read(EEfan2Pin), OUTPUT);
      fan2State = updateFan(2, EEfan2Pin, fan2State, EEfan2Mode, EEac2Trigger, EEtemp2on, EEtemp2off);
    }

    if (EEPROM.read(EEfan1Pin) != 0){
      pinMode(EEPROM.read(EEfan1Pin), OUTPUT);
      fan1State = updateFan(1, EEfan1Pin, fan1State, EEfan1Mode, EEac1Trigger, EEtemp1on, EEtemp1off);
    }
}

//function to print duplicate menus
void fanMainMenu(byte fanNum, byte fanMode, byte fanState) 
{
  if (updateScreen > 0){ //menu or button update              
      lcd.clear();
      
      lcd.setCursor(0,0);
      lcd.print("^ Fan  :");
      lcd.setCursor(6,0);
      lcd.print(fanNum / 10);

      lcd.setCursor(12,0);
      lcd.print("Edit");

      lcd.setCursor(0,1);
      if (EEPROM.read(fanMode) == on)
        lcd.print(">[On]");
      else if (EEPROM.read(fanMode) == off)
        lcd.print(">[Off]");
      else lcd.print(">On/Off");
    
      lcd.setCursor(10,1);
      if (EEPROM.read(fanMode) == Auto)
        lcd.print("[Auto]");
      else
        lcd.print(" Auto<");
    }

    if (updateTimedScreen == true || updateScreen > 0){
      lcd.setCursor(8,0);
      if (fanState == HIGH)
        lcd.print("ON ");
      else lcd.print("OFF"); 
    }
       
    if (btnCheck(btnTopLeft))
      InOutOrder = 0;

    if (btnCheck(btnTopRight))
      InOutOrder = fanNum;

    if (btnCheck(btnBottomLeft)){
      if (EEPROM.read(fanMode) == on)
        EEPROM.update(fanMode, off);
      else EEPROM.update(fanMode, on);
    }

    if (btnCheck(btnBottomRight))
      EEPROM.update(fanMode, Auto);

}

void fanEditMenu(byte fanNum, byte tempOn, byte tempOff, byte acTrig, byte fanState) 
{
  static byte ioCursor;
         
    if (btnCheck(btnTopLeft)){
      if (ioCursor == 0)
        InOutOrder = fanNum;
      else 
      --ioCursor;
    }
               
    if (btnCheck(btnTopRight)){
      if (ioCursor == 0)
        EEPROM.update(tempOn, EEPROM.read(tempOn) + 1);
      else if (ioCursor == 1)
        EEPROM.update(tempOff, EEPROM.read(tempOff) + 1);
      else if (ioCursor == 2)
        EEPROM.update(acTrig, true);
    }
             
    if (btnCheck(btnBottomLeft) && ioCursor < 2)
      ++ioCursor;
         
    if (btnCheck(btnBottomRight)){
      if (ioCursor == 0)
        EEPROM.update(tempOn, EEPROM.read(tempOn) - 1);
      else if (ioCursor == 1)
        EEPROM.update(tempOff, EEPROM.read(tempOff) - 1);
      else if (ioCursor == 2)
        EEPROM.update(acTrig, false);
    }
    
    if (updateScreen > 0){
      lcd.setCursor(0,0);
      lcd.print("^");

      lcd.setCursor(5,0);
      if (ioCursor == 0)
        lcd.print(">");
      else lcd.print(" ");
      
      lcd.setCursor(10,0);
      intPrint(tempConvert(EEPROM.read(tempOn)), 3);
      tempSymbol();
      lcd.print(" +");

      lcd.setCursor(0,1);
      if (ioCursor < 2)
        lcd.print("v");
      else lcd.print(" ");

      lcd.print("AC:");
      if (EEPROM.read(acTrig) == true)
        lcd.print("Y");
      else
        lcd.print("N");
      
      lcd.setCursor(5,1);
      if (ioCursor == 1)
        lcd.print(">");
      else if (ioCursor == 2)
        lcd.print("<");
      else lcd.print(" ");
      lcd.setCursor(10,1);
      intPrint(tempConvert(EEPROM.read(tempOff)), 3);
      tempSymbol();
      lcd.print(" -");
    }

    if (updateTimedScreen == true || updateScreen > 0){
      lcd.setCursor(1,0);
      intPrint(CTS, 3);
      tempSymbol();

      lcd.setCursor(6,0);
      if (fanState == HIGH)
        lcd.print("ON: ");
      else
        lcd.print("on: ");
      
      lcd.setCursor(6,1);
      if (fanState == LOW)
        lcd.print("OFF:");
      else 
        lcd.print("off:");
    }  
}

void fanSetupMenu(byte fanPin, byte fanNum) 
{
  if (btnCheck(btnBottomLeft)){//decrease
    switch (EEPROM.read(fanPin))
    {
      case port3:
        EEPROM.update(fanPin, port2);
      break;
      case port2:
        EEPROM.update(fanPin, port1);
      break;
      default: //error handling incase no pins match
        EEPROM.update(fanPin, 0);
      break;
    }
  } 
  if (btnCheck(btnBottomRight)){//increase
    switch (EEPROM.read(fanPin))
    {
      case 0:
        EEPROM.update(fanPin, port1);
      break;
      case port1:
        EEPROM.update(fanPin, port2);
      break;
      default:
        EEPROM.update(fanPin, port3);
      break;
    }
  } 
  
  if (updateScreen > 0){
    lcd.noCursor();
    lcd.setCursor(4,0);
    lcd.print(F("Fan   Pin"));
    lcd.setCursor(8,0);
    lcd.print(fanNum);
    switch(EEPROM.read(fanPin))
    {
      case 0:
        centerPrint("Off", 1);
      break;
      case port1:
        centerPrint("Port 1", 1);
      break;
      case port2:
        centerPrint("Port 2", 1);
      break;
      case port3:
        centerPrint("Port 3", 1);
      break;
    }
  }
}

/*Wideband Options Layout:
 * EEwidebandPin = Actual pin to read in
 * EEwideband = Bitmap option storage
 * 
 * EEwidebandPin: 
 * 0 = wideband options off
 * else = use stored value as pin and activate wideband
 * 
 * EEwideband bitmap:
 * 0 = Wideband Profiles pt1
 * 1 = Wideband Profiles pt2
 *  00 = 8.5 - 18 AFR : AEM X Series
 *  01 =   9 - 16 AFR : NGK AFX
 *  10 =  10 - 20 AFR : AEM
 *  11 = ?
 * 2 = Wideband Tuner Bool
 * 3 = Close Loop Helper Bool
 * 4 = WOT Enrichment mode ?
 * 5 = Cruise Leaning mode ?
 * 6 = Idle Leaning mode ?
 * 7 = ?
 * 
*/
//averaging stuff
byte adv2;
const float averageTotal2 = 20; //this changes the amount of averaging
float AFRArray[20]; //this MUST equal averageTotal
float AFRSum; //bigger to hold the total sum
float AFRVRaw;

// short cut to check if AEM Wideband profile is active
bool smartWideband()
{
  return (EEPROM.read(EEwideband) & B11) == B00; // B00 is AEM Profile, Parentheses are REQUIRED, what a dumb bug...
}

void updateO2() //convert a Wideband AFR reading into a 0-5v Renix Narrowband output
{
  if (millis() >= o2UpdateTime + 20) //used to delay averaging and not adjust output too often
  {
    o2UpdateTime = millis();

    AFRV = getVoltage(EEPROM.read(EEwidebandPin));
  
//convert voltage to AFR
    switch (EEPROM.read(EEwideband) & B11) //bitmask to only read first 2 bits
    {
      case B00:
        AFR = (2.375 * AFRV) + 7.3125;//8.5 to 18 AFR
      break;
      case B01:
        AFR = (1.4 * AFRV) + 9;       //9 to 16 AFR
      break;
      case B10:
        AFR = (2 * AFRV) + 10 + 0.01; //10 to 20 AFR
      break;
      case B11:
        AFR = (3.01 * AFRV) + 7.35;   //7.35 to 22.4 AFR
      break;
    } 
  
//Averaging stuff
    ++adv2;//simple counter to update array
    if (adv2 >= averageTotal2)
      adv2 = 0; //reset
  
    AFRArray[adv2] = AFR; //add current reading to array spot
  
    for (byte count = 0; count < averageTotal2; count++){ //for loop to do summing
      if (count == 0)
        AFRSum = 0;//resets number or bad things happen
      AFRSum += AFRArray[count];
    }
  
    AFR = AFRSum / averageTotal2;//final reading

    if (isfinite(EEPROM.get(EEAFRtarget, AFRtarget)) == false)
      EEPROM.put(EEAFRtarget, 14.7);
    if (isfinite(EEPROM.get(EEAFRrange, AFRrange)) == false)
      EEPROM.put(EEAFRrange, 0.5);
    AFRtarget = EEPROM.get(EEAFRtarget, AFRtarget); //grab EE value
    AFRrange = EEPROM.get(EEAFRrange, AFRrange);
    
    static float newAFR = AFRtarget;
    if (STFuel > 2 && STFuel < 8) //Set new target if it's about to fail rich
      newAFR = AFR;

    if (STFuel > 247 && STFuel < 253) //Set new target if it's about to fail lean
      newAFR = AFR;

    if (STFuel > 10 && newAFR < AFRtarget) //overrich correct
      newAFR += 0.01;

    if (STFuel < 245 && newAFR > AFRtarget) //overlean correct
      newAFR -= 0.01;  
    

    newAFR = constrain(newAFR, 8, 18);
    //float AFRtempTarget;
    
    if (newAFR != AFRtarget && bitRead( EEPROM.read(EEwideband), 3)) //change if loop saver is true
      AFRtarget = newAFR;
    //else
      //AFRtempTarget = AFRtarget;
    
    if (LoopStatus == Open) //reset auto targeting if failing to open loop
      newAFR = AFRtarget;

    float AFRcutoff = AFRtarget - (AFRrange / 2); // 14.6 + 0.5 = 15.1
    
    float narrO2 = ((AFR - AFRcutoff) * 233) / AFRrange; //14.8 - 14.6 = 0.2      
  
    o2DAC = constrain(narrO2, 0, 233);

    if (sigOutOverride == false && bitRead( EEPROM.read(EEwideband), 2)){ //skip in test mode or output off
      if ((AFRV <= 0.5 || AFRV >= 4.5) && smartWideband()) //read lean if sensor isn't ready, rich correction is better then lean
        analogWrite(A14, 225);
      else
        analogWrite(A14, o2DAC);
    }
  }
}
//averaging stuff
byte adv3;
const byte averageTotal3 = 20; //this changes the amount of averaging
int array3[20]; //this MUST equal averageTotal
unsigned long sum3; //bigger to hold the total sum

uint32_t getInputVoltage(){ // for Teensy 3.1, only valid between 2.0V and 3.5V. Returns in millivolts.
    
    //uint32_t x = analogRead(39);

    //Averaging stuff
  
    ++adv3;//simple counter to update array
    if (adv3 >= averageTotal3)
      adv3 = 0; //reset
  
    array3[adv3] = analogRead(39); //add current reading to array spot
  
    for (byte count = 0; count < averageTotal3; count++){ //for loop to do summing
      if (count == 0)
        sum3 = 0;//resets number or bad things happen
      sum3 += array3[count];
    }
  
    int x = sum3 / averageTotal3;//final reading
    
    //return (178*x*x + 2688743864 - 1182047 * x) / 371794;
    
    return x;
}

//For use with custom 0-100 PSI analog voltage sensors **********************************************
float getPSISensor(byte Port)
{
  float tempVolts = 0;
  
  tempVolts = getVoltage(Port);       //grab voltage from pin 
      
  tempVolts = (tempVolts - 0.5) * 25; //convert to PSI, 0.5v = 0 psi, 4.5v = 100 psi 
  
  if (tempVolts < 0)                  //range bounding
    tempVolts = 0;
       
  //floatPrint(tempVolts, 5, 1);
  //lcd.print(F("PSI"));

  return tempVolts;
}
