/*
 * Fuel Tracking Code and Stuff
 * 
 * TODO:
 * -Auto Calibration gets wacky
 * -Need manual adjustment of auto calibration
 * -Need manual adjustment of current fuel 
 * -Missed Fuel option only allows full tank
 * 
 * 
 * Program Description:
 * -Program should track fuel used by the engine and save a current tank amount variable for use.
 * 
 * -Convert Injector MS in an instantainous volume of fuel.
 * --Save constant value of currently used fuel locally, periodcially save tank value to eeprom
 * --Don't save false stuck fuel values after a stall or fail to start
 * 
 * -Add an adjustment value for specific vehicle accuracy.
 * --overwrite this onto main value or just add correction for display?
 * --allow user to adjust value manually
 * --?Can use value to calculate actual fuel injector flow?
 * 
 * -Save instant value to update tracked tank value
 * 
 * -Fuel Adjustment menu to allow user to input changes to tank amount
 * -- Total Fuel Added
 * -- ?Tank Filled or Tank Partial?
 * -- ?Previously missed a fill recording?
 * 
 * UML:
 * float getGPH()
 * -calculates instant GPH and returns
 * 
 * float getInjectorCal()
 * -chooses correction value and returns
 * 
 * void setInjectorCal()
 * -update user selected calibration value
 * 
 */

// Calculate Instant GPH and return **********************************************************
float getGPH()
{ 
//Base Value Injector Flow Rate in Pounds per Hour (#/hr)
    float injFlow = 18.927;                                         //4.0L Injector Flow Rate
    if (engine == 2)
      injFlow = 33.15;                                              //2.5L, 1 big injector vs 6 small ones, this is more of a guess until confirmed

//Calculate Injector Duty Cycle
    //InjDuty = RPM * InjPulse / 1200;

//Calculate GPH from Injector duty percentage of base flow rate
    float GPH = 0;
    GPH = injFlow * InjDuty / 100;

    GPH *= getInjectorCal();                                        //Apply Offset Correction by chosen calibration type
    
    GPH = fuelConvert(GPH);                                         //Convert to LPH if needed

    return GPH;
}

//returns Calibration Offset for calculated base injector flowRate **********************************************************
float getInjectorCal()
{
// Check if Saved Value is a real number, else reset to 1
  if (isfinite(EEPROM.get(EEfuelCal, floaty)) == false)           //eeprom inital set if number is invalid
    EEPROM.put(EEfuelCal, 1.00); 

// Decide which fuel calibration offset to use and return
  switch(fuelCalMode)
  {
    default: //0 = stock
      return 1;
    break;
    case 1: //auto
      return EEPROM.get(EEfuelCal, floaty);                       //Fillup Calibration number for more accurate reading
    break;
    case 2: //user
      return (InjCorr / 100.0 + 1);                               //User Calibration, converted into proper decimal
    break;
  }

  return 1;                                                       //just incase something gets skipped
}
