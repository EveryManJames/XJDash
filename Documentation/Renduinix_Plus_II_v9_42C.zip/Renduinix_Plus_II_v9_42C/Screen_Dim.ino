//stuff for running the screen auto dim stuff goes here

/*
 * Compile notes
 * 
 * old finite average code:
 * 10x int array
 * 125348 bytes ps 7676 bytes dm
 * 
 * new infinte avg code
 * 125284 bytes ps 7624 bytes dm
 * 125284          7616
 * 
 * 64 bytes ps & 52 bytes dm saved
 *               60
 */

void updateAutoDim ()
{
  static bool firstLoopFlag = true;
  static unsigned long dimTimer; //poll timer
  float lightSensor; //holds adjusted light sensor value
  const byte triggerHyst = 4; //hysteresis for trigger value
  
  if (millis() > dimTimer + 50){
    dimTimer = millis(); //reset timer
  
  //Read light sensor
    lightSensor = analogRead(lightSensorPin); //raw output
    //lightSensor = (analogRead(lightSensorPin) / 1023.0) * 100.0; //100 scale conversion
    lightSensor = 2.5 * pow(lightSensor, 0.54) - 3; //carefully crafted Power Function to boost dim sensitivity of 100 scale, -3 offset for clocks
    lightSensor = constrain(lightSensor, 0, 100); //keep it in bounds
  
  //Average sensor reading
    if (firstLoopFlag) {
      lightSensorAvg = lightSensor; //fill avg value for more reliable boot dim trigger
      firstLoopFlag = false;        //set flag
    }
    else
      lightSensorAvg = expoAVG(lightSensor, lightSensorAvg, 0.2); //grab new reading and update average

    if (RGBDimOrder == 5 && autoDimTestFlag == false) {
    //Bright Mode
      if (RGBDim <= autoDim && lightSensorAvg > lowDim + triggerHyst) {//highDim * 4
        RGBDim = 100; //0-100 scale, Max RGB Brightness
        celDim = 60;  //0-100 scale, Max CEL Brightness
        if (EEPROM.read(EEclockMode) == 4) //clock auto dimming
          asWrite(0x0A, EEPROM.read(EEclockHighDim));
      }
    //Dim Mode and dim menu fix
      if ((RGBDim >= autoDim && lightSensorAvg < lowDim) || RGBDim == 0) {//lowDim * 4
        RGBDim = autoDim;
        celDim = 10;
        if (EEPROM.read(EEclockMode) == 4){
          asWrite(0x0A, EEPROM.read(EEclockLowDim)); //crash point
        }
      }
    }
  
  /*
  //Serial Debug
      Serial.print(millis());
      Serial.print(" ");
      Serial.print(celDim);
      Serial.print(" ");
      Serial.print(autoDimTestFlag);
      Serial.print(" ");
    for (Position = 0; Position < averageTotal; Position++){
      Serial.print(lightArray[Position]);
      Serial.print(" ");
    }
    Serial.println(lightSensorAvg);
    */
  }
  
}

//updates Screen color values
void updateRGB()
{
  float RGBScaler = RGBDim / 100.0 * (82 / 100.0);  //0 - 1 scaler value, 80% max threshold to cap brightness for longevity

  analogWrite(redPin,   redValue   * RGBScaler);    //turns on RGB backlight to set amount
  analogWrite(greenPin, greenValue * RGBScaler);    //PWM is used to control the brightness
  analogWrite(bluePin,  blueValue  * RGBScaler);
}
