//for use with Adafruit Precision NXP 9-DOF Breakout Board - FXOS8700 + FXAS21002
/*
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_FXAS21002C.h>
#include <Adafruit_FXOS8700.h>*/

/* Assign a unique ID to this sensor at the same time 
Adafruit_FXAS21002C gyro = Adafruit_FXAS21002C(0x0021002C);
Adafruit_FXOS8700 accelmag = Adafruit_FXOS8700(0x8700A, 0x8700B); */

// Mag calibration values are calculated via ahrs_calibration.
// These values must be determined for each baord/environment.
// See the image in this sketch folder for the values used
// below.

// Offsets applied to raw x/y/z mag values
float mag_offsets[3]            = { -42.06F, -21.68F, 31.86F };

// Soft iron error compensation matrix
float mag_softiron_matrix[3][3] = { {  1.108,  -0.024,  0.046 },
                                    {  -0.024,  0.959, -0.040 },
                                    {  0.046, -0.040,  0.945 } };

float mag_field_strength        = 46.21F;

// Offsets applied to compensate for gyro zero-drift error for x/y/z
float gyro_zero_offsets[3]      = { 0.0F, 0.0F, 0.0F };

// Mahony is lighter weight as a filter and should be used
// on slower systems
//Mahony filter;
//Madgwick filter;

//averaging stuff
bool gyroFillFlag = false;

int rollAdv;
const byte rollAdvTotal = 8; //this changes the amount of averaging
int rollArray[8]; //this MUST equal averageTotal
long rollSum; //bigger to hold the total sum
int rollAvg;

int pitchAdv;
const byte pitchAdvTotal = 8; //this changes the amount of averaging
int pitchArray[8]; //this MUST equal averageTotal
long pitchSum; //bigger to hold the total sum
int pitchAvg;

byte gyroUpdateCount = 10; //used for initial startup

void updateGyroMagFilter()
{
  sensors_event_t gyro_event;
  sensors_event_t accel_event;
  sensors_event_t mag_event;

  // Get new data samples
  gyro.getEvent(&gyro_event);
  accelmag.getEvent(&accel_event, &mag_event);

  // Apply mag offset compensation (base values in uTesla)
  float x = mag_event.magnetic.x - mag_offsets[0];
  float y = mag_event.magnetic.y - mag_offsets[1];
  float z = mag_event.magnetic.z - mag_offsets[2];

  // Apply mag soft iron error compensation
  float mx = x * mag_softiron_matrix[0][0] + y * mag_softiron_matrix[0][1] + z * mag_softiron_matrix[0][2];
  float my = x * mag_softiron_matrix[1][0] + y * mag_softiron_matrix[1][1] + z * mag_softiron_matrix[1][2];
  float mz = x * mag_softiron_matrix[2][0] + y * mag_softiron_matrix[2][1] + z * mag_softiron_matrix[2][2];

  // Apply gyro zero-rate error compensation
  float gx = gyro_event.gyro.x + gyro_zero_offsets[0];
  float gy = gyro_event.gyro.y + gyro_zero_offsets[1];
  float gz = gyro_event.gyro.z + gyro_zero_offsets[2];

  // The filter library expects gyro data in degrees/s, but adafruit sensor
  // uses rad/s so we need to convert them first (or adapt the filter lib
  // where they are being converted)
  gx *= 57.2958F;
  gy *= 57.2958F;
  gz *= 57.2958F;

  // Update the filter
  filter.update(gx, gy, gz,
                accel_event.acceleration.x, accel_event.acceleration.y, accel_event.acceleration.z,
                mx, my, mz);
  
  ++gyroUpdateCount;
  if (gyroUpdateCount > 1){ //throttles averaging while still allowing filter to update 
    gyroUpdateCount = 0;
    //Serial.print(millis());
    //Serial.print(" ");
    float roll;
    if (EEPROM.read(EEgyroscope) == 2)
      roll = (filter.getRoll() - 90 - (EEPROM.read(EErollOffset)-128)) * -1; //clock
    else
      roll = filter.getRoll() + 90 - (EEPROM.read(EErollOffset)-128); //standard
    //Serial.print(roll);
    rollAvg = expoAVG(roll, rollAvg, 0.2);
    /*++rollAdv;//simple counter to update array
    if (rollAdv >= rollAdvTotal)
      rollAdv = 0; //reset
    
    rollArray[rollAdv] = roll; //add current reading to array spot
  
    for (byte count = 0; count < rollAdvTotal; count++){ //for loop to do summing
      if (count == 0)
        rollSum = 0;//resets number or bad things happen
      rollSum += rollArray[count];
    }
    rollAvg = rollSum / rollAdvTotal;//final reading*/
    //Serial.print(" ");
      
    float pitch;  
    if (EEPROM.read(EEgyroscope) == 2)
      pitch = (filter.getPitch() - (EEPROM.read(EEpitchOffset)-128)) * -1; //clock
    else 
      pitch = filter.getPitch() - (EEPROM.read(EEpitchOffset)-128); //standard
    //Serial.println(pitch);
    pitchAvg = expoAVG(pitch, pitchAvg, 0.2);
    /*
    ++pitchAdv;//simple counter to update array
    if (pitchAdv >= pitchAdvTotal)
      pitchAdv = 0; //reset
    
      pitchArray[pitchAdv] = pitch; //add current reading to array spot
    
      for (byte count = 0; count < pitchAdvTotal; count++){ //for loop to do summing
        if (count == 0)
          pitchSum = 0;//resets number or bad things happen
        pitchSum += pitchArray[count];
      }
    
      pitchAvg = pitchSum / pitchAdvTotal;//final reading
  */
    
    //float heading = filter.getYaw();
  }
}

void displayGyro()
{
  gyroFlag = true; //begins gyro polling

  gyroPrevTime = millis(); //keeps track of last request time

   lcd.print(" ");
   
  if (rollAvg > 0)
    lcd.print("^");
  else if (rollAvg < 0)
    lcd.print("v");
  else
    lcd.print(" ");
        
  if (abs(rollAvg) < 10)
    lcd.print(" ");  
  lcd.print(abs(rollAvg));

  
  if (pitchAvg < 0)
    leftArrow();
  else
    lcd.print(" ");
    
  if (abs(pitchAvg) < 10)
    lcd.print(" ");  
  lcd.print(abs(pitchAvg));
  
  if (pitchAvg > 0)
    rightArrow();
  else 
    lcd.print(" ");
    

/*  
  float roll = filter.getRoll();
  float pitch = filter.getPitch();
  //float heading = filter.getYaw();
  //lcd.print(heading, 0);
  //lcd.print(" ");
  lcd.print(pitch, 0);
  lcd.print(" ");
  lcd.print(roll, 0);
*/
  
  /* Get a new sensor event 
  sensors_event_t event;
  gyro.getEvent(&event);
  if(event.gyro.x > 0 && event.gyro.x < 10)
    lcd.print(" ");
  lcd.print(event.gyro.x * 10, 0);
  lcd.print("x");
  
  if(event.gyro.y > 0 && event.gyro.y < 10)
    lcd.print(" ");
  lcd.print(event.gyro.y * 10, 0);
  lcd.print("y");
  
  if(event.gyro.z > 0 && event.gyro.z < 10)
    lcd.print(" ");
  lcd.print(event.gyro.z * 10, 0);
  lcd.print("z");
  */
}

int xRoll;
int zRoll;
void displayAccel() //roll, yaw, pitch
{
  sensors_event_t aevent;
  /* Get a new sensor event */
  accelmag.getEvent(&aevent);

  lcd.print(" ");
  xRoll = aevent.acceleration.x * 9;
  if (xRoll < 0)
    xRoll = xRoll * -1;
  if(xRoll < 10)
    lcd.print(" ");
  lcd.print(xRoll);
  if (aevent.acceleration.x < 0)
    rightArrow();
  else leftArrow();
  
  //lcd.print(aevent.acceleration.y, 1);
  //lcd.print("y");
  
  lcd.print(" ");
  zRoll = aevent.acceleration.z * 9;
  if (zRoll < 0)
    zRoll = zRoll * -1;
  if(zRoll < 10)
    lcd.print(" ");
  lcd.print(zRoll);
  if (aevent.acceleration.z < 0)
    lcd.print("^");
  else lcd.print("v");
}

void displayMag()
{
  sensors_event_t mevent;
  /* Get a new sensor event */
  accelmag.getEvent(&mevent);
  if(mevent.magnetic.x > 0 && mevent.magnetic.x < 10)
    lcd.print(" ");
  lcd.print(mevent.magnetic.x * 10, 0);
  lcd.print("x");
  /*if(mevent.magnetic.y > 0 && mevent.magnetic.y < 10)
    lcd.print(" ");
  lcd.print(mevent.magnetic.y, 1);
  lcd.print("y");*/
  if(mevent.magnetic.z > 0 && mevent.magnetic.z < 10)
    lcd.print(" ");
  lcd.print(mevent.magnetic.z * 10, 0);
  lcd.print("z");
}
