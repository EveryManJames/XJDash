//This is where we read in all the data and do stream switching.
//In older versions using ATMEL arduinos with only 1 UART and limited space, this got really complicated. 
//Teensy boards makes this clean and much more efficient due to multiple UARTS.

//________________
//1234R 23.1ms 23%
//14.2M 128C 1.23v 
//________________

//tcu Data Reading Code ************************************************************************************************************************
void tcuDataGrab()
{
  /* The AW-4 TCU data framing is based purely off timing as there is a longer gap between frames. 
   * There are 70ms between the last byte and the first byte vs only 30ms between data bytes. 
   * First byte is module ID which doesn't change and can make for a good checksum.  
   * 
   * FOR PROPER TIMING THIS SHOULD RUN EVERY LOOP
   * 
   * Teensy can do it all simulataneously without timing issues because 3 UARTS. No need for software serial and 
   * sharing a single UART BUT, due to some clock division magic, you have to compile at 48mhz for 500 baud on Serial 1 and 2.
   * Serial 3 is only half the speed of 1 and 2 so safe to compile up to 120mhz if using 3.
   */
   
  tcuStreamUpdate = false;                          //reset

  while (tcuSerialPort.available() > 0){            //live processing, parse as data is available                
  
//time incoming byte    
    //static unsigned long tcuPrevTime = 0;
    
    long byteGap = millis() - tcuPrevTime;          //calculate gap between bytes
    tcuPrevTime = millis();                         //reset prev for next loop

//read incoming byte
    byte currentByte = tcuSerialPort.read();        //pull current byte off serial buffer
    byte Status = 0;                                //for reporting status of incoming byte
    static byte dataIndex = 0;                      //array location to be accessed

//sort byte type
    const byte LONG  = 4; // unknown index
    const byte BEGIN = 3; // 70ms frame start
    const byte DATA  = 2; // 30 ms data
    const byte SHORT = 1; // stacked data

    tcuReadFlag = true;  //ready flag

//LONG, unknown frame index
    if      (byteGap > 300){
      Status = LONG;
      tcuReadFlag = false;
      tcuDataGood = false;
    }

//BEGIN, 70ms frame gap     
    else if (byteGap > 55){
      Status = BEGIN;
      if (dataIndex == 7)
        tcuDataGood = true;   //set success flag
      else
        tcuDataGood = false;
          
      dataIndex = 0;        //resets index count
    }

//DATA, 30ms data gap
    else if (byteGap > 15){
      Status = DATA;
    }

//SHORT, stacked data
    else{                    
      Status = SHORT;
      if (tcuDataGood == false) //only read if confirmed good stream
        tcuReadFlag = false;
    }   
    
//parse data into array*********************
   
    if (tcuReadFlag == true && dataIndex < 7){  //add data to array
      tcuDataStream[dataIndex] = currentByte; 
      ++dataIndex;

      if (dataIndex == 7){                      //read full frame
        tcuStreamUpdate = true;                 //tells screen to refresh with new data
        tcuCalcs();
      }
    }
    else{
      tcuDataGood = false;
      dataIndex = 0;
    }

    if (tcuDebug == true){
      serialPad(currentByte);
      Serial.print("  ");
      Serial.print(byteGap);
      Serial.print(" mS");
      Serial.write(9);
      Serial.print("Index:");
      Serial.print(dataIndex);
      Serial.print("   Stat:");
      Serial.print(Status);
      
      Serial.print("   Read?");
      if (tcuReadFlag == true)
        Serial.print(" Yes");
      else
        Serial.print("    ");

      Serial.print("   Good?");
      if (tcuDataGood == true)
        Serial.print(" Yes");
      else
        Serial.print("    ");

      Serial.print("   Update?");  
      if (tcuStreamUpdate == true)
        Serial.print(" Yes");
      else
        Serial.print("    ");

      Serial.println();
    }
  }

//no data time out
    if (millis() > tcuPrevTime + 2000 && tcuDataGood == true) //reset stream to show loss of data
    {
      tcuStreamUpdate = true;                                 //tells screen to refresh with new data
      tcuReadFlag = false;                                    //reset search flag
      tcuDataGood = false;                                    //reset succesful frame flag
      
      for (byte Position = 0; Position < 7; Position++)       //read 7 bytes into the array straight off the buffer.
        tcuDataStream[Position] = 0;

      tcuCalcs();                                             //reset all the calc values to 0
      
      if (tcuOutput == true)
        Serial.println(" Timeout!");
    }

//for debugging, can comment out.
    if (tcuOutput == true){
      if (tcuStreamUpdate == true)
      {
        for (byte Position = 0; Position < 7; Position++)
        {
          if (Position > 2)
            binSPrint(tcuDataStream[Position]);
          else 
            Serial.print(tcuDataStream[Position]);
          Serial.print(" ");
        }
        if (tcuDataStream[0] != 1)
          Serial.print("ERROR");
        Serial.println();
      }//debug raw stream read end
    }  //**************************
}

//do all tcu stream calculations only when new data is recieved ********************************************************
void tcuCalcs()
{
  //ModuleID = tcuDataStream[0];
  tcuTPS = tcuDataStream[1];
  tcuRPM = (tcuDataStream[2] * 34);
               
  byte PRNDLtemp = bitRead(tcuDataStream[3], 4) * 10 + bitRead(tcuDataStream[3], 5); //transfers bits to a visual number
  switch(PRNDLtemp)
  {
    case 10: //1-2
      tcuPRNDL = 1;
    break;
    case 01: //3rd
      tcuPRNDL = 3;
    break;
    case 11: //PRND
      tcuPRNDL = 4;
    break;
    default: //????
      tcuPRNDL = 0;
    break;
  }
  
  tcuBrake   = !bitRead(tcuDataStream[3], 0);              //inverted
  tcuShiftLogic = !bitRead(tcuDataStream[3], 2);
  tcuMystery = !bitRead(tcuDataStream[3], 6);
  tcuMode    = !bitRead(tcuDataStream[3], 7);              //inverted
  
  solenoid1 = !bitRead(tcuDataStream[4], 5);              //inverted
  solenoid2 = !bitRead(tcuDataStream[4], 6);              //inverted 
  solenoid3 = !bitRead(tcuDataStream[4], 7);              //inverted
   
  byte gearTemp = solenoid1 * 10 + solenoid2;             //transfers bits to a visual number                
  switch(gearTemp)
  {
    case 10: //1st
      if (solenoid3 == true)  //??? Error if 1st and TC are on
        tcuGear = 0;
      else
        tcuGear = 1;
    break;
    case 11: //2nd
      tcuGear = 2;
    break;
    case 01: //3rd
      tcuGear = 3;
    break;
    case 00: //4th
      tcuGear = 4;
    break;
  }
    
  SolenoidFaults = tcuDataStream[5];     
  TPSFaults = tcuDataStream[6];

  MPH = 0.00595 * tcuRPM * TireSize / 2 / GearRatio / 100 * SpeedCorr;   //(RPM*Tire Radius/Gear Ratio)*Speed Correction
  MPH = distanceConvert(MPH);                                     //used to convert to kph if needed
}

//ecu data reading code *****************************************************************
void ecuDataGrab()
{
  /* After many years, I have finally been able to write new parsing code from the ground up
   * and it's much simplier and effective then the previous version
   * This revision can handle non-specific Program Version numbers, as well as process any 
   * stream length provided the array is large enough to fit a full frame
   * 
   * The main focus here is handeling value 255. 
   * Frame start will look like: X, 255, 0, X. If this is detected, reset stream index
   * Data bytes that send 255 will need to repeat itself to prevent an accidental 0 detection, remove duplicate
   * If neither pattern are seen then the 255 can be infered as an error, as any little voltage blip will read as 255
   */
    
  ecuStreamUpdate = false;
   
  while (Serial1.available() > 0)      //live processing, parse as data is available                
  { 
    const byte START = 1;
    const byte DATA  = 2;
    const byte DUP   = 3;
    const byte WAIT  = 4;
    const byte ERRO  = 5;
    
    byte Status = 0;                //for reporting status of incoming byte
    static byte dataIndex;          //array location to be accessed
    static byte prev;               //remembers previous state
    byte current = Serial1.read();  //pull current byte off serial buffer
    //static unsigned long prevGap;
    //word gap = micros() - prevGap;
    //prevGap += gap;
    
    if (EEPROM.read(EEusbOutput) == 3) //USB Passthrough
      Serial.write(current);        //echo to serial monitor
   
    if (prev == 255) {              //255 handeling *****************************
      switch (current) {
        case 0:             //frame start
          Status = START; 
        break;
        case 255:           //data case
          Status = DUP;
        break;
        default:            //fallback error
          Status = ERRO;
        break;
      }
      prev = 0;             //clear used result
    }
    else if (current != 255){        //usual case, data is compliant ************
      Status = DATA;
    }
    else{                            //save 255 and wait for next loop **********
      prev = current;
      Status = WAIT;
    }

    switch(Status)                   //parse data into array*********************
    {
      case START: //start
        dataIndex = 0; //resets index count
        
        if (ecuFirstDataFlag == true)
          ecuStreamUpdate = true;       //successful ecu data update flag
        ecuFirstDataFlag = true;        //one time trip to wait for first data capture
      
        ecuStreamTime = millis() - ecuPrevTime; //calculate gap between streams for
        ecuPrevTime = millis();       //set prev for next loop

        //Serial.println();
      break;
      case DUP: //data duplicate
        //no special instructions yet, runs Data case under it w/o break
      case DATA: //data  
        if (ecuFirstDataFlag == true){ //only process data if stream start was found
          //gapStream[dataIndex] = gap;
          dataStream[dataIndex] = current;
          ++dataIndex;
          /*Serial.print(millis());
          Serial.print(" ");
          Serial.print(current);
          Serial.print(" ");
          if (dataIndex == 8){
            float AFRt = getVoltage(EEPROM.read(EEwidebandPin));
            AFRt = (2.375 * AFRt) + 7.3125;
            Serial.print(AFRt,2);
            Serial.print(" ");
          }*/
        }
      break;
      case WAIT: //wait
      break;
      case ERRO: //error
      break;
    } 
  }//read if available end
}

//do base ecu stream calculations only when new data is recieved ********************************************************
void ecuCalcs()
{
  if (engine == 2) //for 2.5L *******************************************************************************************
  {
    //ProgramVersion = dataStream[0]; 
    //PROMversion = dataStream[1]; 
    //PROM = (dataStream[0], dataStream[1]);

    Starter  = bitRead(dataStream[2], 0);
    NSS      = bitRead(dataStream[2], 1);                              //True = Drive/Reverse, False = Park/Neutral
    ACSwitch = bitRead(dataStream[2], 2);                         //0 indexed, 3rd bit (2) will set this true or false

    if (bitRead(dataStream[2], 3) != bitRead(dataStream[2], 4))   //checks both outputs are different(XOR) to weed out P 
      ThrottleSwitch = !bitRead(dataStream[2], 3);                //True = Closed, False = WOT
    else ThrottleSwitch = Part;                                   //else P if both are equal
    
    ACRequest = bitRead(dataStream[2], 5);
       
    MAPRaw = dataStream[3];                                       //value before calculations, useful for other functions
    MAP = pressureConvert(MAPRaw);                                //function to convert into desired pressure
    
    CTSRaw = dataStream[4];
    CTS = tempConvert(CTSRaw);     
    
    IATRaw = dataStream[5];    
    IAT = tempConvert(IATRaw);
    
    Volts = (dataStream[6] / 31.875 + 8);                         //converts to Volts (8 - 16)
    Lambda = (dataStream[7] * 4.34);                              //converts to mV (0 - 1,106.7)

    RPM = word(dataStream[9], dataStream[8]);                     //9 & 8 are a 16 bit number, = gap between spark pulses in uS
    if (RPM > 255 && RPM < 65280)                                 //calibrated to MS1700 Math     
      RPM = 30000000 / RPM;                                       //1,000,000 * 60 / Pulses per Rotation(Cyl/2) / #                                  
    else RPM = 0;

    InjPulse = word(dataStream[11], dataStream[10]);              //pulse Width in mS (0 - 65.5), word doesn't allow decimal so divide later
    InjPulse /= 1000;
    
    TPS = (dataStream[12] / 2.55);                                //throttle position sensor in Percentage. (0 - 100)
    SparkADV = dataStream[13];                                    //ignition Timing in degrees (0 - 255)
    mystery1 = dataStream[14];                                    //Mystery 1, Zero?
    mystery2 = dataStream[15];                                    //Mystery 2, Slow Increase
    BaroRaw = dataStream[16];                                     //initial MAP reading before Startup
    Baro = pressureConvert(BaroRaw);
    
    Vacuum = Baro - MAP;                                          //pressure conversion gives wrong reading 
    
    mystery3 = dataStream[17];                                    //Mystery 3, Digital Bits
    EngineRun = bitRead(dataStream[17], 0);                       //CPS Signal? True = On, False = Off

    if (bitRead(dataStream[18], 1) == true)                       //Decel is default for Bit 1
      LoopStatus = Dcel;
    else LoopStatus = bitRead(dataStream[18], 6);                 //True = Closed, False = Open
    PSSwitch = bitRead(dataStream[18], 4);                        //Power Steering Pressure Switch, True = Closed, False = Open
    Exhaust = bitRead(dataStream[18], 7);                         //True = Rich, False = Lean
    
    mystery4 = dataStream[19];                                    //Mystery 4, Zero?  
    mystery5 = dataStream[20];                                    //Mystery 5, Zero? 
    
    EGR = bitRead(dataStream[21], 3);                             //MT2500 uses Bit 5, but no data seems present there
    ACClutch = bitRead(dataStream[21], 6);
    
    mystery6 = dataStream[22];                                    //Mystery 6, Small Offset 
    mystery7 = dataStream[23] / 2.55;                             //Mystery 7, ISM Idle Offset 
    STFuel = dataStream[24];                                      //short term fuel trim (0 - 255)
    mystery8 = dataStream[25];                                    //Mystery 8, RPM Offset? 
    LTFuel = dataStream[26];                                      //long term fuel trim (0 - 255)
    mystery9 = dataStream[27];                                    //Mystery 9, IAT Offset? 
    mystery10 = dataStream[28];                                   //Mystery 10, 128 
  }
  
  else{ //for 4.0L ****************************************************************************************************************
    //ProgramVersion = dataStream[0];
    //PROMversion = dataStream[1];
    //CalibrationCode = dataStream[2];
    //PROM = (dataStream[0], dataStream[1], dataStream[2], dataStream[11], dataStream[10], dataStream[30]);
      
    MAPRaw = dataStream[3];                                       //value before calculations, useful for other functions
    MAP = pressureConvert(MAPRaw);                                //function to convert into desired pressure
    
    CTSRaw = dataStream[4];
    CTS = tempConvert(CTSRaw);     
    
    IATRaw = dataStream[5];    
    IAT = tempConvert(IATRaw);
    
    Volts = (dataStream[6] / 16.24);                              //converts to Volts (0 - 15.7)
    Lambda = (dataStream[7] / 51.2);                              //converts to V (0 - 4.98)

    RPM = word(dataStream[9], dataStream[8]);                     //9 & 8 are a 16 bit number, = gap between spark pulses in uS
    if (RPM > 255 && RPM < 65280)                                 //calibrated to MS1700 Math     
      RPM = 20000000 / RPM;                                       //1,000,000 * 60 / Pulses per Rotation(Cyl/2) / #                                            
    else RPM = 0;                                                 //helps for clean zero without errors
        
    //PROM9_10 = dataStream[10];
    //PROM7_8 = dataStream[11];
    TPS = (dataStream[12] / 2.55);                                //throttle position sensor in Percentage. (0 - 100)
    SparkADV = dataStream[13];                                    //ignition Timing in degrees (0 - 255)
    
    mystery1 = dataStream[14];                                    //Mystery 1, Digital Bits        
    //ACClutch = bitRead(dataStream[14], 1);                      //not actually clutch, just A/C idle comp
    if (bitRead(dataStream[14], 4) == true)                       //IAC Moving
      IACtimer = millis();
    if (bitRead(dataStream[14], 5) == true){                       //IAC Opening
      ++IACcount;
      IACdir = true;
    }
    else if (bitRead(dataStream[14], 6) == true){                  //IAC Closing
      --IACcount;
      IACdir = false;
    }
    IACcount = constrain(IACcount, 0, 2550);                      // # / 10 roughly keeps track of iac rotations
    IAC = IACcount / 10;      
      
    mystery2 = tempConvert(dataStream[15]) + 40;                  //Mystery 2, CTS target offset (100C, 212F)
    BaroRaw = dataStream[16];                                     //initial MAP reading before Startup
    Baro = pressureConvert(BaroRaw);
    
    Vacuum = Baro - MAP;                                          //pressure conversion gives wrong reading
    
    mystery3 = dataStream[17];                                    //Mystery 3, Engine Flags?
    EngineRun = !bitRead(dataStream[17], 2);                      //CPS Signal? True = Off, False = On
    
    if (bitRead(dataStream[18], 1) == true)                       //Decel is default for Bit 1
      LoopStatus = Dcel;
    else LoopStatus = bitRead(dataStream[18], 6);                 //True = Closed, False = Open   
    EGR = bitRead(dataStream[18], 3);                             //True = On, False = Off
    //Exhaust = bitRead(dataStream[18], 7);                         //True = Rich, False = Lean, this does not change in open loop
    if (dataStream[7] > 127)
      Exhaust = Lean;
    else
      Exhaust = Rich;
        
    InjPulse = dataStream[19] * 0.128;                            //Pulse Width in mS (0 - 32.7) 
    mystery4 = dataStream[20];                                    //Mystery 4, Zero?   
 
    if (bitRead(dataStream[21], 1) != bitRead(dataStream[21], 3)) //checks both outputs are different(XOR) to weed out P 
      ThrottleSwitch = bitRead(dataStream[21], 3);                //True = Closed, False = WOT
    else ThrottleSwitch = Part;                                   //Else P if both are equal

    mystery5 = dataStream[22];                                    //Mystery 5, IGN Knock Mask
    if (bitRead(mystery5, 7) == true){                            //due to time sync issues, only calc when bitmask is active
      SparkRTD = mystery5;
      bitClear(SparkRTD, 7); 
      SparkRTD -= SparkADV;
    }
    else
      SparkRTD = 0;
                   
    mystery6 = dataStream[23] * 0.128;                            //Mystery 6, INJ Warmup Offset
    STFuel = dataStream[24];                                      //short term fuel trim (0 - 255)
    mystery7 = tempConvert(dataStream[25]);                       //Mystery 7, IAT target offset?
    LTFuel = dataStream[26];                                      //long term fuel trim (0 - 255)
    Knock = dataStream[27];                                       //knock sensor (0 - 255)
    mystery8 = dataStream[28];                                    //Mystery 8, Zero or 128 

    FuelSync = bitRead(dataStream[29], 2);                        //True = -, False = +
    Starter  = bitRead(dataStream[29], 4);                        //True = On, False = Off
    ACSwitch = bitRead(dataStream[29], 5);
    ACRequest = bitRead(dataStream[29], 6);
    NSS = bitRead(dataStream[29], 7);                             //True = Drive/Reverse, False = Park/Neutral
    
    //PROM11_12 = dataStream[30]; 

    //Fake AFR from Inverse of L/(1+e^(-k*(x-x0)))
    //Lambda = 0.43; //test math
    if (Lambda < 0.56) //14 limit, don't try to calculate past
      estAFR = 13.5;
    else if (Lambda > 4.44) //16 limit
      estAFR = 16;
    else
      estAFR = -log( (4.45 - Lambda) / (Lambda - 0.55) ) / 4.5 + 14.9; // -ln( (MAX - x) / (x - MIN) ) / Steepness + Midpoint;
  }
}

void absCalcs(){
 //for ABS ****************************************************************************************************************
    //ProgramVersion = dataStream[0];
    //PROMversion = dataStream[1];
    
    LFWheel = dataStream[2] / 3.1;                                //MPH
    RFWheel = dataStream[3] / 3.1;
    LRWheel = dataStream[4] / 3.1;
    RRWheel = dataStream[5] / 3.1;
      
    if      (bitRead(dataStream[6], 6) == true)
      LFSolenoid = 4;                                             //6 = Isolate, takes priority
    else if (bitRead(dataStream[6], 0) == true && bitRead(dataStream[6], 3) == true)
      LFSolenoid = 3;                                             //0 & 3 = Build & Decay
    else if (bitRead(dataStream[6], 0) == true) 
      LFSolenoid = 2;                                             //3 = Decay                    
    else if (bitRead(dataStream[6], 3) == true)
      LFSolenoid = 1;                                             //0 = Build
    else
      LFSolenoid = 0;                                             //False = Off

    if      (bitRead(dataStream[7], 0) == true)
      RFSolenoid = 4;                                             //0 = Isolate, takes priority
    else if (bitRead(dataStream[6], 1) == true && bitRead(dataStream[6], 4) == true)
      RFSolenoid = 3;                                             //1 & 4 = Build & Decay
    else if (bitRead(dataStream[6], 4) == true) 
      RFSolenoid = 2;                                             //4 = Decay                    
    else if (bitRead(dataStream[6], 1) == true)
      RFSolenoid = 1;                                             //1 = Build
    else
      RFSolenoid = 0;                                             //False = Off

    if      (bitRead(dataStream[7], 1) == true)
      RearSolenoid = 4;                                             //1 = Isolate, takes priority
    else if (bitRead(dataStream[6], 2) == true && bitRead(dataStream[6], 5) == true)
      RearSolenoid = 3;                                             //2 & 5 = Build & Decay
    else if (bitRead(dataStream[6], 5) == true) 
      RearSolenoid = 2;                                             //5 = Decay                    
    else if (bitRead(dataStream[6], 2) == true)
      RearSolenoid = 1;                                             //2 = Build
    else
      RearSolenoid = 0;   

    GSwitch =      !bitRead(dataStream[7], 3);                    //true = closed, false = open
    DiffPressure =  bitRead(dataStream[7], 4);                    //true = closed, false = open
    BoostPressure = bitRead(dataStream[7], 5);                    //true = closed, false = open
    
    LowAccum =             bitRead(dataStream[8], 0);             //true = true, false = false
    ABSPump =              bitRead(dataStream[8], 2);             //true = on, false = off
    ModulatorRelay =       bitRead(dataStream[8], 3);             //true = true, false = false
    SolenoidUndervolt =    bitRead(dataStream[8], 4);             //true = true, false = false
    ParkingBrakeFluidLow = bitRead(dataStream[8], 5);             //true = true, false = false
    ABSBrake =             bitRead(dataStream[8], 6);             //true = true, false = false                      
}

// displays active ECU codes, requires other listing functions in main loop ******************************************
void ecuCodeList()
{
  if (engine == 4) //4.0L codes
  {
    if (ecuFirstDataFlag == true) //prevents blank stream misdisplays
    {
//Injector Codes
      if (dataStream[11] == 255)
        listError(true, "No Injector 12V");
        
      else if (dataStream[11] == 252)
        listError(true, "12V Injector Hot");
        
      else if (dataStream[11] == 0)
        listError(true, "No Injector GND");
        
      else{             //only allow if no "global" errors are being shown
        listError(!bitRead(dataStream[10], 2), "Injector 1 Short");
        listError(!bitRead(dataStream[10], 6), "Injector 2 Short");
        listError(!bitRead(dataStream[10], 4), "Injector 3 Short");
        listError(!bitRead(dataStream[10], 7), "Injector 4 Short");
        listError(!bitRead(dataStream[10], 3), "Injector 5 Short");
        listError(!bitRead(dataStream[10], 5), "Injector 6 Short");
        
        listError(!bitRead(dataStream[11], 2), "Injector 1 Open");
        listError(!bitRead(dataStream[11], 6), "Injector 2 Open");
        listError(!bitRead(dataStream[11], 4), "Injector 3 Open");
        listError(!bitRead(dataStream[11], 7), "Injector 4 Open");
        listError(!bitRead(dataStream[11], 3), "Injector 5 Open");
        listError(!bitRead(dataStream[11], 5), "Injector 6 Open");
      }
      
      listError(bitRead(dataStream[20], 1), "Water Temp Sensr");

  //Relay Codes
      if (dataStream[30] == 255)
        listError(true, "KO Tests Not Run");
      
      else if (bitRead(dataStream[30], 7) == false){  
        listError(true, "Fuel Not Primed");
        listError(!bitRead(dataStream[30], 0), "ICM Signal Open"); //seperate feed, still reports properly
      }
       
      else{  
        listError(!bitRead(dataStream[30], 0), "ICM Signal Open");
        listError(!bitRead(dataStream[30], 2), "EGR Solenod Open");
        listError(!bitRead(dataStream[30], 4), "B+ Relay Open");
        listError(!bitRead(dataStream[30], 5), "o2 Relay Open");
        listError(!bitRead(dataStream[30], 6), "A/C Relay Open");
      }
    }
  }
  else // engine == 2 or engine == 3 (abs)
  {
    if (listCheck() == true)
      lcd.print(" Not Available");
  }
}

// displays active ABS codes, requires other listing functions in main loop ******************************************
void absCodeList()
{
  if (engine == 3){ //ABS
    listError(bitRead(dataStream[13], 4), "805 Diff Pressur");
    listError(bitRead(dataStream[13], 5), "806 Boost Pressu");
    listError(bitRead(dataStream[13], 6), "807 Low Accumula");
    listError(bitRead(dataStream[12], 1), "808 ModulatorFlt");
    listError(bitRead(dataStream[12], 0), "809 ECU-Test Flt");
    listError(bitRead(dataStream[12], 2), "810 Sol UnderVlt");
    listError(bitRead(dataStream[12], 5), "811 System Relay");
    listError(bitRead(dataStream[12], 6), "812 Motor Pump");
    listError(bitRead(dataStream[12], 3), "813 Brake Switch");
    listError(bitRead(dataStream[12], 4), "814 Low-Fluid");
    listError(bitRead(dataStream[13], 0), "815 RR Speed Sen");
    listError(bitRead(dataStream[13], 1), "816 LR Speed Sen");
    listError(bitRead(dataStream[13], 2), "817 RF Speed Sen");
    listError(bitRead(dataStream[13], 3), "818 LF Speed Sen");
  }
  else
  {
    if (listCheck() == true)
      lcd.print(" Not Available");
  }
}

// main data grabbing hub is here **************************************************************************************
void getData (){//void to create the data grabbing function  

  byte ecuLength = 31;              //1 indexed, 4.0L Stream is longer then 2.5L
  if (engine == 2)
    ecuLength = 29;
  if (engine == 3)
    ecuLength = 14;
    
  tcuDataGrab(); //Reads in AW-4 TCU datastream and does calculation

  ecuDataGrab(); //Reads in Benix ECU datastream
  
  if (ecuStreamUpdate == true) //only update with fresh data, this saves 22uS per loop when not used
  { 
    if (engine == 3) //ABS
      absCalcs();
    else{
      ecuCalcs(); //updates ecu base calcs

    //other stream based calculations go here ***************************

      if (transType == false) //speed calc guess for manual trans, uses engine rpm in final gear for wheel speed
      {
        float ManualRPM; //fills in for auto trans tail shaft rpm
        float ManualGear;//trans gear ratio used to do speed calc

        if (engine == 2)
          ManualGear = 1.0; //final gear ratio, 4 spd = 1.0, 5 speed = 0.79
        else
          ManualGear = 0.79;
        
        if (RPM < 1000)
          ManualRPM = 0; //cutoff to show 0 mph at idle
        else          
          ManualRPM = RPM / ManualGear; //= Engine / Trans gear ratio
        
        MPH = 0.00595 * ManualRPM * TireSize / 2 / GearRatio / 100 * SpeedCorr;   //(RPM*Tire Radius/Gear Ratio)*Speed Correction
        MPH = distanceConvert(MPH);                                     //used to convert to kph if needed
      }
      
      engineRPM = RPM;
      if (rpmUnit == true){
        engineRPM = RPM / 10;
        engineRPM *= 10; //trunicating for easier reading
      }

      STFT = STFuel;
      LTFT = LTFuel;
      if (fuelTrimUnit == true){
        STFT = STFT - 128; //zeroed
        LTFT = LTFT - 128; //zeroed
      }
      
      LambdaHeater = getVoltage(o2HeaterPin);
      //BatterySense = getVoltage(battSense);
  
      InjDuty = RPM * InjPulse / 1200;
  
      GPH = getGPH();
      
      MPG = MPH / GPH;                                                //:^) personal end goal here...
      if (speedUnit == false)                                         //LHK conversion
        MPG = 100 / MPG;                                              //remember MPG is really KPL when set to KPH
  
    //counting code for SYN Animation
      if (FuelSync != dizzyPrev){
        dizzyCEL = false; 
        dizzyPrev = FuelSync;
        dizzyFlag = true;
      }
      else dizzyCEL = true;
    }    
  }//ecu stream update end

//educated guess if engine is running, values can get stuck when key is turned off and on quickly *******************************
    engineRunCount = 0;         //reset
    if (EngineRun == true && ecuFirstDataFlag == true) //Bit seems to be related to engine running 
      engineRunCount += 4;       
    if (RPM != RPMPrev)           //can get stuck at 303
      ++engineRunCount;
    if (InjPulse != InjPulsePrev) //will freeze when engine off
      ++engineRunCount;     
    if (Vacuum > 1)               //can get stuck for a bit
      ++engineRunCount;     
    if (Volts > 12.8)             //reads 0 after 2 second cut off
      ++engineRunCount;            
    if (LambdaHeater > 3)         //not critical but bonus points
      ++engineRunCount;
      
    if (engineRunCount >= 5 && millis() - ecuPrevTime < 2000) //failsafe incase data stops
      engineRunFlag = true;
    else engineRunFlag = false;

    RPMPrev = RPM;              //Reset history checks
    InjPulsePrev = InjPulse;

    if (engineRunFlag == true && ecuStreamUpdate == true)
      engineRunTime += ecuStreamTime; //used for gph avg

    //engine on
    //vacuum > 0 //can get stuck at 2 for a bit
    //Volts > 0 
    //heater volts > 0
    //Stream frame time = 26ms
    //Fuel Sync //not critical
    
    //RPM > 400 //can get stuck at 303
    //injector ms //can get stuck

    //engine off
    //vacuum /= 0
    //Volts = 0 //2 second cut off
    //heater volts = 0
    //Stream frame time = 100ms
    
    //TPS = parital //only on first key on
    //knock = 255 //only on first key on
   

//Trip fuel and distance tracking stuff *********************************************************************************************************
    if (ecuStreamUpdate == true)                          //current trip fuel tracking ******************** 
    {
      ftElapsed = millis() - ftPrev;
      ftPrev = millis();
      
      if (GPH > 0 && engineRunFlag == true)               //prevents add up fuel from stuck KOEF readings
      {
        fuelCurrent = GPH / (1000 / ftElapsed);
        if (isfinite (fuelCurrent))                       //checks for real numbers to prevent glitches
          fuelTemp += fuelCurrent;                        //must divide by 3600 for actual number
        fuelHistory = fuelTemp / 3600;
      }
    }

    if (tcuStreamUpdate == true)                          //current trip distance tracking ****************
    {
      dtElapsed = millis() - dtPrev;
      dtPrev = millis();
      
      if (MPH > 0)
      {
        distanceCurrent = MPH / (1000 / dtElapsed);       //all floats helps with accuracy
        if (isfinite(distanceCurrent))
          distanceTemp += distanceCurrent;                //must divide by 3600 for actual number
        distanceHistory = (distanceTemp / 3600);
      }
    }

  //AVG is only a display number, can be set for Trip or Tank AVG
    if (EEPROM.read(EEAVGmode) == 1)                                        //AVG Tank MPG Reading ***************
      avgMPG = (startDist + distanceHistory) / (startFuel + fuelHistory);   //combines saved values with live values for more interesting AVG
    else                                                                   
    {                                                                       //AVG Trip MPG Reading **************
      if (distanceHistory > 0 && fuelHistory > 0)                           //c-c-c-c-c-cooooombo breaker
        avgMPG = distanceHistory / fuelHistory;                             //Personal Bonus End Goal
    }
    if (speedUnit == false)                                                 //LHK conversion
      avgMPG = 100 / avgMPG;                                                //remember MPG is really KPL when set to KPH  
    if (isfinite(avgMPG) == false)                                          //fixes early goof readings
      avgMPG = 0;
                                                                 

    if (EEPROM.read(EEAVGmode) == 1)                                        //AVG Tank GPH Reading ***************
      avgGPH = (startFuel * 3600 + fuelTemp) / (engineRunTime / 1000);      //combines saved values with live values for more interesting AVG
    else
    {                                                                       //AVG Trip GPH Reading ***************
      if (fuelHistory > 0 && engineRunTime > 0)                             //for manual dudes without rad MPH readings
        avgGPH = (fuelTemp) / (engineRunTime / 1000);
    }
    if (isfinite(avgGPH) == false)
      avgGPH = 0; //fixes early goof readings

//Tank fuel and distance tracking stuff *********************************************************************************************************
  
  //NSS based flag that will save when shifted to park for better tracking accuracy *********
    static bool NSSsave;
    static unsigned long NSStimer;
    if (transType == true && NSS == false && millis() > NSStimer + 300000){ //save value in park only every 5 min
      NSStimer = millis();
      NSSsave = true;
    }
    else NSSsave = false;
    
    if (isfinite(EEPROM.get(EEfuelTrack, floaty)) == false)                  //eeprom inital set *******
      EEPROM.put(EEfuelTrack, 0.00);                                        
      
    if (fuelHistory >= fPrev + 0.05 || NSSsave == true){                     //eeprom tank fuel tracking
      EEPROM.get(EEfuelTrack, fTemp);                                        //grab saved value
      fTemp += (fuelHistory - fPrev);                                        //add saved value to remainder of current                                     
      
      EEPROM.put(EEfuelTrack, fTemp);                                        //save updated total
      fPrev = fuelHistory;                                                   //reset
    }

    
    if (isfinite(EEPROM.get(EEdistanceTrack, floaty)) == false)
      EEPROM.put(EEdistanceTrack, 0.00);
               
    if (distanceHistory >= dPrev + 0.5 || NSSsave == true){                   //eeprom tank distance tracking *******
      EEPROM.get(EEdistanceTrack, dTemp);
      dTemp += (distanceHistory - dPrev);
      
      EEPROM.put(EEdistanceTrack, dTemp);  
      dPrev = distanceHistory;                                                //reset
    }

// SD logging stuff ***************************************************************************************************************************
  /*if (ecuStreamUpdate == true){
    
    // make a string for assembling the data to log:
    String sdDataString = "";

    sdDataString += millis();
    sdDataString += ",";
  
    for (byte Position = 0; Position < ecuLength; Position++){
      sdDataString += String(dataStream[Position]);
      if (Position < ecuLength - 1)
        sdDataString += ","; 
    }
  
    // open the file. note that only one file can be open at a time,
    // so you have to close this one before opening another.
    File dataFile = SD.open("eculog.txt", FILE_WRITE);
  
    // if the file is available, write to it:
    if (dataFile) {
      dataFile.println(sdDataString);
      dataFile.close();
      // print to the serial port too:
      Serial.println(sdDataString);
    }  
    // if the file isn't open, pop up an error:
    else {
      Serial.println("error opening datalog.txt");
    }   
  }

  if (tcuStreamUpdate == true){
    
    // make a string for assembling the data to log:
    String sdDataString = "";

    sdDataString += millis();
    sdDataString += ",";
  
    for (byte Position = 0; Position < 7; Position++){
      sdDataString += String(tcuDataStream[Position]);
      if (Position < 7 - 1)
        sdDataString += ","; 
    }
  
    // open the file. note that only one file can be open at a time,
    // so you have to close this one before opening another.
    File dataFile = SD.open("tculog.txt", FILE_WRITE);
  
    // if the file is available, write to it:
    if (dataFile) {
      dataFile.println(sdDataString);
      dataFile.close();
      // print to the serial port too:
      Serial.println(sdDataString);
    }  
    // if the file isn't open, pop up an error:
    else {
      Serial.println("error opening datalog.txt");
    }   
  }*/

// usb logging output *************************************************************************************************************************
  if (EEPROM.read(EEusbOutput) != false && ecuStreamUpdate == true){// && btnPress(btnHome)){
    switch(EEPROM.read(EEusbOutput))
    {
      case 1: //Normal calculated values
        Serial.print(millis());
        Serial.print(" ");
        Serial.print(MAP,1);
        Serial.print(" ");
        Serial.print(Vacuum,1);
        Serial.print(" ");
        Serial.print(CTS);
        Serial.print(" ");
        Serial.print(IAT);
        Serial.print(" ");
        Serial.print(RPM);
        Serial.print(" ");
        Serial.print(Volts,1);
        
        Serial.print(" ");
        if (engine == 2) 
          Serial.print(Lambda,0);
        else Serial.print(Lambda,2);
        
        if (Exhaust == Lean) 
          Serial.print(" Lean");
        else Serial.print(" Rich");
        
        if (engine == 4){
          Serial.print(" ");
          Serial.print(LambdaHeater,1); 
        }
        
        if (LoopStatus == Clsd)
          Serial.print(" Closed");
        else if (LoopStatus == Dcel)
          Serial.print(" Decel");
        else Serial.print(" Open");
    
        if (EGR == true)
          Serial.print(" On ");
        else Serial.print(" Off ");
        
        Serial.print(TPS);

        if (ThrottleSwitch == Clsd)
          Serial.print(" Closed ");
        else if (ThrottleSwitch == WOT)
          Serial.print(" WOT ");
        else Serial.print(" Part ");
  
        Serial.print(SparkADV);
        Serial.print(" ");
        
        if (engine == 4){ 
          Serial.print(Knock);
          Serial.print(" ");
        }
        
        Serial.print(InjPulse,1);
        Serial.print(" ");
        Serial.print(InjDuty,1);
        Serial.print(" ");

        if (engine == 4){
          if (FuelSync == true)
            Serial.print("- ");
          else Serial.print("+ ");
        }
    
        Serial.print(STFuel);
        Serial.print(" ");
        Serial.print(LTFuel);
        
        if (ACSwitch == true)
          Serial.print(" On");
        else Serial.print(" Off");
        
        if (ACRequest == true)
          Serial.print(" Yes");
        else Serial.print(" No");
        
        if (engine == 2){
          if (ACClutch == true)
            Serial.print(" On");
          else Serial.print(" Off");
        }

        Serial.print(" ");
        Serial.print(GPH);

        if (EEPROM.read(EEwidebandPin) > 0){
          Serial.print(" ");
          Serial.print(AFR, 2);
          //Serial.print(" ");
          //Serial.print(wbSerial, 1);  
        }
        
        Serial.println("");
      break;
      case 2: //Raw formatted
        Serial.print(millis());
        Serial.print(" ");
        for (byte Position = 0; Position < ecuLength; Position++)
        {
          Serial.print(dataStream[Position]);
          //sSpacePad(dataStream[Position]);
          Serial.print(" ");
        }

        if (EEPROM.read(EEwidebandPin) > 0){
          Serial.print(AFR, 2);
          //Serial.print(" ");
          //Serial.print(wbSerial, 1);  
        }
        /*binSPrint(dataStream[10]);
        Serial.print(" ");
        binSPrint(dataStream[11]);
        Serial.print(" ");
        binSPrint(dataStream[30]); //edit
*/        
/*        Serial.print(" ");
        
        if (transType == true){
          for (byte Position = 0; Position < 7; Position++)
          {
            Serial.print(tcuDataStream[Position]);
            //sSpacePad(dataStream[Position]);
            Serial.print(" ");
            if (Position > 2){
              binSPrint(tcuDataStream[Position]);
              Serial.print(" ");
            }
          }
        }
*/      
        Serial.println("");
      break;
      case 3: //Passthough emulated, NOTE: this is now done live in data parsing func
        /*Serial.write(0); //start byte
        for (byte Position = 0; Position < ecuLength; Position++)
        {
          Serial.write(dataStream[Position]);
          if (dataStream[Position] == 255)
            Serial.write(255); //sends a duplicate to differentiate from end byte
        }
        Serial.write(255); //end byte*/
      break;
    }
  }

//Bluetooth Stuff ********************************************************************************************************************************
if ((EEPROM.read(EEbluetooth) == 1 && millis() > btPrev + 100) || 
    (EEPROM.read(EEbluetooth) == 2 && millis() > btPrev + 300))
{
  btPrev = millis();

  if (engine == 2){ //2.5L
    bluetoothStream[0] = dataStream[3]; //MAP
    bluetoothStream[1] = dataStream[4]; //CTS
    bluetoothStream[2] = dataStream[5]; //IAT
    bluetoothStream[3] = Volts * 16.24; //VOLTS, bootleg convert for app
    bluetoothStream[4] = dataStream[7]; //O2, wrong but atleast you get full graph
    bluetoothStream[5] = RPM / 20;//dataStream[8]; //RPM Lo
    bluetoothStream[6] = dataStream[9]; //RPM Hi
    bluetoothStream[7] = dataStream[12]; //TPS
    bluetoothStream[8] = dataStream[13]; //IGN ADVANCE
      
    if (LoopStatus == Clsd)               //LOOP
      bluetoothStream[9] = 2; //clsd
    else if (LoopStatus == Dcel)
      bluetoothStream[9] = 3; // decel
    else bluetoothStream[9] = 1; //open
  
    if (Exhaust == Lean)                  //EXHAUST
      bluetoothStream[10] = 1; 
    else
      bluetoothStream[10] = 2;
    
    bluetoothStream[11] = InjPulse * 7.79; //INJ MS, bootleg convert for app
    bluetoothStream[12] = dataStream[27]; //KNOCK
    bluetoothStream[13] = dataStream[16]; //BARO
    bluetoothStream[14] = dataStream[24]; //STFT
    bluetoothStream[15] = dataStream[26]; //LTFT
  }

  else //4.0
  { 
    bluetoothStream[0] = dataStream[3]; //MAP
    bluetoothStream[1] = dataStream[4]; //CTS
    bluetoothStream[2] = dataStream[5]; //IAT
    bluetoothStream[3] = dataStream[6]; //VOLTS
    bluetoothStream[4] = dataStream[7]; //O2
    bluetoothStream[5] = RPM / 20;//dataStream[8]; //RPM Lo bootleg convert for app
    bluetoothStream[6] = dataStream[9]; //RPM Hi, not used currently
    bluetoothStream[7] = dataStream[12]; //TPS
    bluetoothStream[8] = dataStream[13]; //IGN ADVANCE

    if (LoopStatus == Clsd)               //LOOP
      bluetoothStream[9] = 2; //clsd
    else if (LoopStatus == Dcel)
      bluetoothStream[9] = 3; // decel
    else bluetoothStream[9] = 1; //open
  
    if (Exhaust == Lean)                   //EXHAUST
      bluetoothStream[10] = 1; 
    else
      bluetoothStream[10] = 2;
    
    bluetoothStream[11] = dataStream[19]; //INJ MS
    bluetoothStream[12] = dataStream[27]; //KNOCK
    bluetoothStream[13] = dataStream[16]; //BARO
    bluetoothStream[14] = dataStream[24]; //STFT
    bluetoothStream[15] = dataStream[26]; //LTFT
   }
  
  
  btSerialPort.write(byte(119));           //Control byte
  for (byte i = 0; i < 16; i++)
    btSerialPort.write(byte(bluetoothStream[i]));
}

//Min Max Value Recording ************************************************************************************************************************
    if (engineRunFlag == true && MinMaxCheck == 0)                    //stage 1 of the Min/Max Reset for engine running conditions 
    {
      MinMaxCheckTime = millis();                                     //records time and updates check for stage 2
      MinMaxCheck = 1;                                                //sets flag for next stage
    }
    if (MinMaxCheck == 1 && (millis() > MinMaxCheckTime + 5000)){     //resets min/max after 5 seconds of engine running
      MinMaxReset = true;                                             //trips reset flag
      resetCEL(false);                                                //reset Prev CEL array checker
      MinMaxCheck = 2;                                                //sets flag to prevent multiple resets
    }

    if (millis() > 500){                                              //fitlers out odd startup values
      if ((MAP < MAPMin && MAP != 0) || MinMaxReset == true)          //Min and Max Recording
        MAPMin = MAP;
      if ((MAP > MAPMax && MAPRaw != 255) || MinMaxReset == true)
        MAPMax = MAP;
        
      if ((CTS < CTSMin && CTS != 0) || MinMaxReset == true)
        CTSMin = CTS;
      if ((CTS > CTSMax && CTSRaw != 255) || MinMaxReset == true)
        CTSMax = CTS;
        
      if ((IAT < IATMin && IAT != 0) || MinMaxReset == true)
        IATMin = IAT;
      if ((IAT > IATMax && IATRaw != 255) || MinMaxReset == true)
        IATMax = IAT;
        
      if ((RPM < RPMMin && RPM != 0) || MinMaxReset == true)
        RPMMin = RPM;
      if ((RPM > RPMMax && RPM < 7000) || MinMaxReset == true)
        RPMMax = RPM;
        
      if ((Volts < VoltsMin && Volts != 0) || MinMaxReset == true)
        VoltsMin = Volts;
      if ((Volts > VoltsMax && Volts < 15.8) || MinMaxReset == true)
        VoltsMax = Volts;
        
      if ((TPS < TPSMin && TPS != 0) || MinMaxReset == true)
        TPSMin = TPS;
      if ((TPS > TPSMax && TPS < 99) || MinMaxReset == true)
        TPSMax = TPS;
        
      if ((Lambda < LambdaMin && Lambda != 0) || MinMaxReset == true)
        LambdaMin = Lambda;
      if (Lambda > LambdaMax || MinMaxReset == true)
        LambdaMax = Lambda;
        
      if ((Knock < KnockMin && Knock != 0) || MinMaxReset == true)
        KnockMin = Knock;
      if ((Knock > KnockMax && Knock < 255) || MinMaxReset == true)
        KnockMax = Knock;

      if ((STFuel < STFuelMin && STFuel != 0) || MinMaxReset == true)
        STFuelMin = STFuel;
      if ((STFuel > STFuelMax && STFuel < 255) || MinMaxReset == true)
        STFuelMax = STFuel;
        
      MinMaxReset = false;
    }//current time if end
}//Void end
