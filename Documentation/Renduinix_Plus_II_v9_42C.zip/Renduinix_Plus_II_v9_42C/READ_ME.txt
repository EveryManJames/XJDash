NickInTimeDesign 2023

Renduinix Plus II formatted for Renix Engine Monitor II V4 and II + V5 models only

**************************************************************************************************
For EASY UPLOADING:

1 - Extract or Unzip the Renduinix Folder

2 - Download the Teensy Loader Application used to update the REM: (https://www.pjrc.com/teensy/loader.html)

3 - Plug the REM into a computer using a Micro USB Cable meant for data (Some are charge only so try a different one if you have issues)

4 - Open up the Teensy Loader Application downloaded earlier.

5 - In Teensy Loader at top left, Click the Page Icon “Open Hex File.” 
 - Open the downloaded HEX Folder and select the appropriate "Renduinix_II_..._.ino.hex” File. 
 - MAKE SURE THE ENDING BOARD VERSION MATCHES YOUR REM BOARD MODEL! 
 - The new file number should display at the bottom of Teensy Loader if you did it right.
 - TIP: You can also drag and drop the Hex file directly onto Teensy Loader window to select the update file. 

6 - In Teensy Loader at top right, Click “Auto” icon so that it is Lit Up Green.

7 - The REM needs to be Reset to accept the update.

- Option 1: Open the REM back door and press small white button on teensy for REM II or small black button labeled RST for REM II +. The Reset Button may be hiding under the blue Gyro Board if that option was installed.

—OR—
 
- Option 2: (Renduinix + v0.85 and up) In REM Software, go to More > Settings > Advanced > “USB REM Update” and hit either lower button to initiate a reboot to begin upload.
 
8 - The REM will go dark and Teensy Loader should upload the file, then display “REBOOT OK” on computer.

9 - The REM should now boot with the new software! You can confirm the correct version by going to More > Settings > Options > Software Info.
 
PJRC Teensy Loader: https://www.pjrc.com/teensy/loader.html Renduinix and REM Support: https://www.facebook.com/NickInTimeFilms/ Sweet Product Website: https://nickintimedesign.com/
Youtube Update Walkthrough: https://www.youtube.com/watch?v=sjbltaFosbQ


****************************************************************************************************
For HARD UPLOADING:

For people that like to browse through the code, all the Arduino files are available to look through as well!

Teensyduino add-on will need to be installed for compiling support available at PJRC.com


UPLOAD SETTINGS:

  - Tools > Board: > Teensy 3.2
  - Tools > CPU Speed > 96MHz    (48MHz for compatibility with tcu baud rate if not used on Serial3)
  - Tools > Port > Teensy
  - Tools > Programmer: > AVRISP mkII

  Requires RTClib Library from adafruit and a few others to be installed to compile.
  - Sketch > Include Library > Add .ZIP Library...

Check the download folder for additional Libraries


Compile Tip: the Teensy compiler doesn’t usually give helpful error codes, so switch to “Arduino/Genuino Mega or Mega 2650” to get actual error messages. Or have fun scrolling through the verbose to find where it got stuck.

The Teensy Reboot line will need to be commented out for successful compile for Non-Teensy boards.

(Renduinix + v0.86 and up): made porting much easier between versions with serial port defines and pin handling, so just update the board define number for the right pinout.



 