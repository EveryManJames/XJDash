
//Most things related to the Real Time Clock will go here, V3 Only

char daysOfTheWeek[7][4] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
//not pretty globals, should make getters one day...
byte Ehour;
byte Eminute;
byte Esecond;
bool Eblink;
bool PMflag;
bool spaceSwap;

byte hrHi;
byte hrLo;
byte minHi;
byte minLo;
byte secHi;
byte secLo;

//begin clock functions on boot ************************************************************************************
void rtcTimeBegin() {
  /*rtc.begin();//V3 option
  if (! rtc.begin())
    while (1);//make sure library has been started?  
  if (rtc.lostPower()) 
    // following line sets the RTC to the date & time this sketch was compiled
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
   */

  //set the Time library to use Teensy 3.0's RTC to keep time
  setSyncProvider(getTeensy3Time);

  //check if there is a valid time set 
  if (timeStatus()!= timeSet) {
    time_t t = processSyncMessage();
    if (t != 0)
      t = 1541934671; //11/11/18 11:11:11 GMT
    Teensy3Clock.set(t); // set the RTC
    setTime(t);
  }
}

// get current time from teensy **************************************************************************************
time_t getTeensy3Time() {
  return Teensy3Clock.get();
}

/*  code to process time sync messages from the serial port   */
#define TIME_HEADER  "T"   // Header tag for serial time sync message

// get current time from serial port if possible **********************************************************************
unsigned long processSyncMessage() {
  unsigned long pctime = 0L;
  const unsigned long DEFAULT_TIME = 1357041600; // Jan 1 2013 

  if(Serial.find(TIME_HEADER)) {
     pctime = Serial.parseInt();
     return pctime;
     if( pctime < DEFAULT_TIME) { // check the value is a valid time (greater than Jan 1 2013)
       pctime = 0L; // return 0 to indicate that the time is not valid
     }
  }
  return pctime;
}

//helps format time for easier display, V5+
void easyTime() {
  static byte oldSecond;
  static unsigned long oldMilSec;

//Grab current time and store in a variable for consistant display
  time_t t = driftTimeNow();//now();
  
//Hour Formatting
  if (show12Hours) //12hour display
    Ehour = hourFormat12(t);
  else //24 hour
    Ehour = hour(t);

//Minute Formatting, just so DateTime doesn't have to be called twice
  Eminute = minute(t);

//Second Formatting
  Esecond = second(t);
  
//Second Colon Blinking
  if (oldSecond != second(t)){
    oldMilSec = millis();
    oldSecond = second(t);
    Eblink = true;
  }
  if (millis() > oldMilSec + 500)
    Eblink = false;

//AM/PM flag
  PMflag = isPM(t);

//Seven Seg Clock breakdowns
  hrHi = Ehour / 10;
  hrLo = Ehour - (hrHi * 10);
    
  minHi = Eminute/10;
  minLo = Eminute - (minHi * 10);

  if (menuOrder == Gauges && hrHi > 0 && show12Hours)
    spaceSwap = true; 
  else spaceSwap = false;
}

void displayTime ()
{
  easyTime(); //grab current time and split into variables

  if (spaceSwap) //fills am/pm gap on gauge screen
    lcd.print(" ");

  printTimeDigits(Ehour, " ", false);  
  printTimeDigits(Eminute, "0", true);
  
  if (show12Hours) {  //12 hour display, print AM/PM
    if (!spaceSwap)
      lcd.print(" ");

    if (PMflag)
      lcd.print("PM");
    else
      lcd.print("AM");
  }
  else{                 //24 hour display, print seconds
    printTimeDigits(Esecond, "0", true);
  }
  
}

void displayTimeLong () //no drift adjustment, prints seconds and 12hr AM/PM
{
  time_t timeNow = now();

  displayTimeCustom(timeNow, true, true);
  
  if (show12Hours) {    //12 hour display, print AM/PM
    if (isPM(timeNow))
      lcd.print(" PM");
    else
      lcd.print(" AM");
  }
}

//use now() for base, driftTimeNow() for corrected
void displayTimeCustom(time_t inputTime, bool showSec, bool colBlink) {
  if (show12Hours)                                    //12 hour
    printTimeDigits(hourFormat12(inputTime), "0", false);  
  else                                                //24 hour
    printTimeDigits(hour(inputTime), "0", false); 
  
  if (!colBlink)                                      //Min
    lcd.print(":");
  printTimeDigits(minute(inputTime), "0", colBlink);    
  
  if (showSec){                                       //Sec
    if (!colBlink)
      lcd.print(":");
    printTimeDigits(second(inputTime), "0", colBlink);  
  }
}

/*
Display time options
- RTC vs adjusted
- sec or no sec
- blink or no blink
- hour 0

displayTime:      easytime, 12hr:min/sec|AM         Ehour
displayTimeLong:  timeNow,  12hr:min:sec AM         hour() √
displayTimeCustom:custom T, 12hr:min:?sec? ?blink?  hour()          

*/

void displayDate (time_t inputTime)
{
  time_t t = inputTime;
  
  printTimeDigits(month(t), "0", false);
  lcd.print("/");
  printTimeDigits(day(t), "0", false);
  lcd.print("/");
  byte Eyear = year(t) - ((year(t) / 100) * 100); //trunicate first 2 digits
  printTimeDigits(Eyear, "0", false);
}

time_t driftTimeNow() {
  time_t tNow = now();  //Grab current RTC time
    
    //Serial.println(tNow);
    //printTime(tNow);
  if (getTimeSetpoint() != 0) {               //skip correction if invalid setpoint
    float secWeekDrift = getTimeDriftRate();  //user defined second drift per week, /10 for single decimal
    time_t tSetpoint = getTimeSetpoint();     //Grab Correct Time Setpoint from memory
    time_t tRange = tNow - tSetpoint;         //Find number of seconds from memory setpoint to current time
    time_t driftAmount = tRange / 604800.0 * secWeekDrift; //how many weeks in the tRange * sec/wk correction rate
    tNow += driftAmount;
  } 
/*
    Serial.println(tSetpoint);
    Serial.println(tRange);
    Serial.println(secWeekDrift);
    Serial.println(driftAmount);
    Serial.println(tNow);
    printTime(tNow);
*/
  return tNow;
}

float getTimeDriftRate() {
  int inty = 0; // .get placeholder hack
  return EEPROM.get(EEtimeDriftRate, inty) / 10.0; //user defined second drift per week, /10 for single decimal
}

void setTimeDriftRate(float input) {
  float tempFloat = getTimeDriftRate();
  
  if (input == 0) //reset value
    tempFloat = 0;
  else
    tempFloat += input;

  int tempInt = tempFloat * 10.0; //adjust 1 decimal up to save as int, +- 3,276.8 sec possible
  EEPROM.put(EEtimeDriftRate, tempInt); 
}

time_t getTimeSetpoint() {
  time_t timey = 0; // .get placeholder hack
  return EEPROM.get(EEtimeSetpoint, timey);  
}

void setTimeSetpoint(time_t timeSetpoint){
  EEPROM.put(EEtimeSetpoint, timeSetpoint);
}

//relies on easyTime() which gets called by updateClock() to get blink var. Messy but I'm done touching this for now
void printTimeDigits(int digits, String symbol, bool colon){
  // utility function for digital clock display: prints leading colon and character
  if (colon) {
    if (Eblink)
      lcd.print(":");
    else
      lcd.print(" ");
  }

  if (digits < 10)
    lcd.print(symbol);
  lcd.print(digits);
}

void printTime(time_t t) {
  // digital clock display of the time
  Serial.print(hour(t));
  sPrintDigits(minute(t));
  sPrintDigits(second(t));
  Serial.print(" ");
  Serial.print(month(t));
  Serial.print(" ");
  Serial.print(day(t));
  Serial.print(" ");
  Serial.print(year(t)); 
  Serial.println(); 
}

void sPrintDigits(int digits){
  // utility function for digital clock display: prints preceding colon and leading 0
  Serial.print(":");
  if(digits < 10)
    Serial.print('0');
  Serial.print(digits);
}

void rtcTimeAdjustMenu() {     
  static bool driftSyncFlag = false;
  if (!driftSyncFlag){
    Teensy3Clock.set(driftTimeNow()); //update rtc initally to sync menu
    setTimeSetpoint(now());           //update sync point to stay in sync, but this will be saved again later
    driftSyncFlag = true; //this will only trip once per power cycle, but should be good enough 
  }
  
  if (updateScreen > 0){      
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("+");
    lcd.setCursor(0,1);
    lcd.print("-");
    
    lcd.setCursor(15,0);
    lcd.print(">");
    lcd.setCursor(15,1);
    rightArrow();
  } 
                        
  if (btnCheck(btnTopLeft)){ //Add 1
    time_t t = now();
    char HOUR = 0;
    char MINUTE = 0;
    char SECOND = 0;
    char DAY = 0;
    char MONTH = 0;
    char YEAR = 0;
    switch (timeSetOrder)
    {
      case 1://hour
        if (hour(t) == 23)
          HOUR = -23;
        else HOUR = 1;
      break;
      case 2://minute
        if (minute(t) == 59)
          MINUTE = -59;
        else MINUTE = 1;
        SECOND = -second(); //reset seconds to zero for syncing 
      break;
      case 3://month
        if (month(t) == 12)
          MONTH = -11;
        else MONTH = 1; //possibility for issues if day is higher then allowed for new month
      break;
      case 4://day
        DAY = 1; //relies on library to roll over, but this increases the month. hack below
      break;
      case 5://year
        YEAR = 1;
      break;
    }
    setTime(hour(t) + HOUR, minute(t) + MINUTE, second(t) + SECOND, day(t) + DAY, month(t) + MONTH, year(t) + YEAR);
    if (timeSetOrder == 4 && day() == 1){ //day rollover fix
      setTime(hour(), minute(), second(), day(), month(t), year(t)); //day is good, so use old month and year
    } 
    Teensy3Clock.set(now()); //update rtc
  }
  
  if (btnCheck(btnBottomLeft)){ //Subtract 1
    time_t t = now();
    char HOUR = 0;
    char MINUTE = 0;
    //char SECOND = 0;
    char DAY = 0;
    char MONTH = 0;
    char YEAR = 0;
    switch (timeSetOrder)
    {
      case 1://hour
        if (hour(t) == 0)
          HOUR = 23;
        else HOUR = -1;
      break;
      case 2://minute
        if (minute(t) == 0)
          MINUTE = 59;
        else MINUTE = -1;
      break;
      case 3://month
        if (month(t) == 1)
          MONTH = 11;
        else MONTH = -1;
      break;
      case 4://day
        if (day(t) == 1)
          MONTH = 1; //balances month fuckery
        DAY = -1;
      break;
      case 5://year
        YEAR = -1;
      break;
    }
    setTime(hour(t) + HOUR, minute(t) + MINUTE, second(t), day(t) + DAY, month(t) + MONTH, year(t) + YEAR);
    Teensy3Clock.set(now()); //update rtc
  }

  if (btnCheck(btnBottomRight)){ //move cursor
    ++timeSetOrder;
    if (timeSetOrder > 5)
      timeSetOrder = 1;
  }

  if (updateTimedScreen || updateScreen == buttons){
    lcd.cursor();
    
    lcd.setCursor(4,0);
    displayTimeLong();
  
    lcd.setCursor(4,1);
    displayDate(now());
    //lcd.print("   ");
    
    switch (timeSetOrder)
    {
      case 1:
        lcd.setCursor(5,0);//hr
      break;
      case 2:
        lcd.setCursor(8,0);//min
      break;
      case 3:
        lcd.setCursor(5,1);//month
      break;
      case 4:
        lcd.setCursor(8,1);//day
      break;
      case 5:
        lcd.setCursor(11,1);//yr
      break;
    }
  }

  //________________
  //+   12:42:12   >
  //-   12/13/22  
}
/*
Time drift offset notes:

- offset can be set with Seconds Per Week variable.
- Main clock will not be adjusted, instead an artificial adjustment will be added on after the time is grabbed.
- The adjustment calc will require a saved setpoint when the clock was correct, as well as some kind of drift offset variable to adjust

- User could adjust setpoint which could live adjust time from setpoint, but could be error prone if setpoint is very old
- User could correct system time and calculate drift from 2 setpoints

- Every time user manually adjusts time, overwrite as new setpoint. Only for minute adjustment as to not save setpoint from DST or time zone hour adjustments?

- drift adjuster wizard:
- Set Correct Time and save as setpoint
- Come back later (2 weeks maybe?)
- Correct time again, calculate drift
- ask to apply or edit drift value?
________________
< Drift Adjust >
<     Edit     >
________________
^ No Setpoint:
v Begin Setup ->
 Manual Adjust->
 Reset Values ->
 <No Reset? Yes>
________________
Set Current Time
to the second ->
________________
+ 00:00:00 AM <-
- 00/00/00 Save>
<No  Save?  Yes>
________________
 Readjust again
 after 1+ Week->
________________
^ Last Setpoint:
v 02d03h Adjust->
________________
 Detected Drift:
 20sec/Wk Save->
<No  Save?  Yes> 
________________
<No  Save?  Yes>
^ Drift Adjust
<  20 sec/Wk   >


time_t t = now(); //normal RTC time
time_t t = driftOffsetNow(); //adjusted RTC time

time_t driftOffsetNow () {
  time_t tNow = now();  //Grab current RTC time
  time_t tSetpoint = EEPROM.get(eeTimeSetpoint); //Grab Correct Time Setpoint from memory
  time_t tRange = tSetpoint - tNow; //Find number of seconds from memory setpoint to current time
  float driftAmount = tRange / 604800 * secWeekDrift; //how many weeks in the tRange * sec/wk correction rate
  return tNow + driftAmount;
}

*/

/* //hiding old menu code here
case timeDriftMenu://RTC Time Drift Adjust menu**********************************************************
    static byte driftMenuSelector = 0; //menu selector
    const byte DRIFTHOME = 0;
    const byte AUTOADJUST = 1;
    const byte MANUALADJUST = 2;

    static byte autoMenuSelector = 0;
    
    switch(driftMenuSelector) {   
      case DRIFTHOME: //home menu
        static byte index = 1;          
        upDownArrowScroller(index, 1, 4);

        if (updateScreen > 0){
          lcd.clear();

          rightArrow();
          upDownArrows();

          scrollPrint(1, "Auto Adjust", index);
          scrollPrint(2, "Manual Adjust", index);
          scrollPrint(3, "Reset Values?", index);
          scrollPrint(4, "Back?", index);
        
        }
        
        if (btnCheck(btnTopLeft)) {
          switch(index) {
            case 1:
              driftMenuSelector = AUTOADJUST;
              
              //menu logic
              if (now() > getTimeSetpoint() + SECS_PER_YEAR)
                autoMenuSelector = 1; //setpoint is too old, grab new one
              else if (now() < getTimeSetpoint() + SECS_PER_WEEK)
                autoMenuSelector = 3; //setpoint is too new, go to wait screen
              else
                autoMenuSelector = 4; //go to adjustment page
            break;
            case 2:
              driftMenuSelector = MANUALADJUST;
            break;
            case 3:
            break;
            case 4:
              menuOrder = TimeMenu;
            break;
          }
        }
        
          //^ No Setpoint:
          //v Begin Setup ->
          //Manual Adjust->
          //Reset Values ->
          //<No Reset? Yes>
        
      break;
      case AUTOADJUST:
        switch(autoMenuSelector){
          case 1: //New Setpoint needed
            if (btnCheck(btnBottomRight)) 
              autoMenuSelector = 2; //go to next screen
              
            if (updateScreen > 0){
              lcd.clear();
              lcd.print("Set Current Time");
              lcd.setCursor(0,1);
              lcd.print("to the Second  ");
              rightArrow();                      
            }
            break;
          case 2: //set correct time and save setpoint
            if (btnCheck(btnBottomRight)){ 
              setTimeSetpoint(now()); //save setpoint to current time
              autoMenuSelector = 3; //go to next screen
            }

            rtcTimeAdjustMenu(); 
            break;
          case 3: //wait screen
            if (btnCheck(btnBottomRight)) 
              driftMenuSelector = DRIFTHOME; //go home
              
            if (updateScreen > 0){
              lcd.clear();
              lcd.noCursor();
              lcd.print("Re-adjust after");
              lcd.setCursor(0,1);
              lcd.print("one week.  [OK]");
              rightArrow();                      
            }
            break;
          case 4: //2nd time reset
            static bool menuTriggerFlag = false;
            static time_t rtcTimePrevious = 0;

            if (!menuTriggerFlag){
              rtcTimePrevious = now(); //save current time for drift calc
              menuTriggerFlag = true;
            }

            if (btnCheck(btnBottomRight)){ 
              setTimeSetpoint(now()); //save setpoint to current time
              autoMenuSelector = 5; //go to next screen
            }
            
            rtcTimeAdjustMenu(); 
            break;
          case 5: //show final drift calc?
            break;
        }   
      break;
      case MANUALADJUST:
        if (btnCheck(btnTopLeft)) //go back
          driftMenuSelector = DRIFTHOME;

        if (btnRepeat(btnBottomLeft)) //decrease
          setTimeDriftRate(-0.5);
        if (btnRepeat(btnBottomRight)) //increase
          setTimeDriftRate(0.5); //BUG, when set to 0.1, can't move past 2.1 or -2.1, no idea why so 0.5 it is...

        if (updateTimedScreen > 0 || updateScreen > 0){
          lcd.clear();

          lcd.print("^ New Time ");
          displayMinSec();

          lcd.setCursor(0,1);
          leftArrow();

          lcd.setCursor(2,1);
          floatPrint(getTimeDriftRate(), 5, 1);
          lcd.print(" sec/wk");

          lcd.setCursor(15,1);
          rightArrow();
        }
        
        //________________
        //^ New Time 00:00
        //^ Drift Adjust
        //<  20 sec/Wk   >
      break;  
      //  if (updateScreen == menu){
      //lcd.clear();
      //lcd.setCursor(0,0);
      //lcd.print("Set Current Time");
      //lcd.setCursor(0,1);
      //lcd.print("to the Second  ");
      //rightArrow();
      
    }
    
    //if (updateScreen > 0 || updateTimedScreen == true){  
   // }
  break; 
*/

/* void displayDate () //V4.1
{
  DateTime now = rtc.now();
  //lcd.print(daysOfTheWeek[now.dayOfTheWeek()]);
  //lcd.print(" ");
  if (now.month() < 10 || now.day() < 10)
    lcd.print(" ");
  lcd.print(now.month());
  lcd.print("/");
  lcd.print(now.day());
  lcd.print("/");
  if (now.year()-2000 < 10)
    lcd.print("0");
  lcd.print(now.year()-2000);
}

void easyTime() //helps format time for easier display, V4.1 and older
{
  DateTime now = rtc.now();
  
//Hour Formatting
  if (hourSetting == true){ //12hour display
    if (now.hour() == 0) //12am
      Ehour = 12;
    else if (now.hour() > 12) //pm
      Ehour = now.hour() - 12;
    else //am
    Ehour = now.hour();
  }
  else //24 hour
    Ehour = now.hour();

//Minute Formatting, just so DateTime doesn't have to be called twice
  Eminute = now.minute();

//Second Formatting
  Esecond = now.second();
  
//Second Colon Blinking
  if (oldSecond != now.second()){
    oldMilSec = millis();
    oldSecond = now.second();
    Eblink = true;
  }
  if (millis() > oldMilSec + 500)
    Eblink = false;

//AM/PM flag
  if (now.hour() > 11)
    PMflag = true;
  else
    PMflag = false;

//Seven Seg Clock breakdowns
  hrHi = Ehour / 10;
  hrLo = Ehour - (hrHi * 10);
    
  minHi = Eminute/10;
  minLo = Eminute - (minHi * 10);

  if (menuOrder == Gauges && hrHi > 0 && hourSetting == true)
    spaceSwap = true; 
  else spaceSwap = false;
}*/
