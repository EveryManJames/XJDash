//Stuff for general Gauge Display will go here

//function to autoskip gauges
void gaugeSkip (byte &Order, bool dSign){
  byte *dOrder = &Order; //pointer to modfiy input variable directly
  
  bool dSkip = true; //start true for while loop

  while (dSkip == true)
  {
    dSkip = false; //reset

    if (dSign == false)        // decrease
    {
      if (*dOrder <= 0)        //loop back
      {
        if (transType == false)
          *dOrder = MPHGauge;   //last gauge before auto trans
        else
          *dOrder = dataTotal - 1; //to the end
      }
      else --*dOrder;     
    }
    else                       // increase
    {
      if (*dOrder >= dataTotal - 1 || (*dOrder >= MPHGauge && transType == false)) //out of bounds
        *dOrder = 0;            //back to start
      else
        ++*dOrder;
    }

    if (engine == 2){
      if (*dOrder == heaterGauge || (*dOrder == afrGauge && EEPROM.read(EEwidebandPin) == 0) || *dOrder == knockGauge || *dOrder == fsyncGauge || *dOrder == IACGauge)
        dSkip = true;
    }

    if (*dOrder == MPGGauge && mpgMode == false) //|| transType == false))
      dSkip = true; //autoskip for GPH/MPG combo gauge, ammended for manual guess mph
    
    if (*dOrder == outputsGauge && EEPROM.read(EEfan1Pin) == 0 && EEPROM.read(EEfan2Pin) == 0 && EEPROM.read(EEfan3Pin) == 0)//menu skip
      dSkip = true; //autoskip
  
    if (*dOrder == gyroGauge && EEPROM.read(EEgyroscope) == false)
      dSkip = true;//timeGauge; //autoskip for gyro
  
    //if (*dOrder == afrGauge && EEPROM.read(EEwideband) == 0)
      //dSkip = true;
      
    if (*dOrder == FPRGauge && EEPROM.read(EEfuelPressurePin) == 0)
      dSkip = true; //autoskip for custom fuel pressure sensor gauge
    
  }    
}

void celOn ()
{
  analogWrite(celPin, celDim);  
}

void celOff ()
{
  analogWrite(celPin, 0);
}

//sets flags for cel star print function, reset in CEL tab
void celStar (byte Input)
{
  if (dataOrder1 == Input)
    bitSet(celStarBitmap, 1);
  if (dataOrder2 == Input)
    bitSet(celStarBitmap, 2);
  if (dataOrder3 == Input)
    bitSet(celStarBitmap, 3);
  if (dataOrder4 == Input)
    bitSet(celStarBitmap, 4);
}
//compares input to current displayed gauges and draws star
void celStarPrint ()
{
  if (bitRead(celStarBitmap, 1) == true){
    lcd.setCursor(0,0);
    lcd.print("*");
  }
  if (bitRead(celStarBitmap, 2) == true){
    lcd.setCursor(8,0);
    lcd.print("*");
  }
  if (bitRead(celStarBitmap, 3) == true){
    lcd.setCursor(0,1);
    lcd.print("*");
  }
  if (bitRead(celStarBitmap, 4) == true){
    lcd.setCursor(8,1);
    lcd.print("*");
  }
}

void displayPROM ()
{
  if (engine == 4){
    lcd.print(dataStream[0], HEX);
    lcd.print(dataStream[1], HEX);
    lcd.print(dataStream[2], HEX);
    lcd.print(dataStream[11], HEX);
    lcd.print(dataStream[10], HEX);
    lcd.print(dataStream[30], HEX);
  }
  else{
    lcd.print(dataStream[0], HEX);
    lcd.print(dataStream[1], HEX);
  }
}
void displayMAP ()
{
  floatPrint(MAP, 5, 1);
  lcd.print(F("MAP"));
}
void displayVacuum ()
{ 
  floatPrint(Vacuum, 5, 1);
  lcd.print(F("VAC"));
}
void displayCTS ()
{
  intPrint(CTS, 5);
  tempSymbol();
  lcd.print(F("WT"));
}
void displayIAT ()
{
  intPrint(IAT, 5);
  tempSymbol();
  lcd.print(F("IA"));
}
void displayRPM ()
{  
  intPrint(engineRPM, 5);
  lcd.print(F("RPM"));
}
void displayVolts ()
{
  floatPrint(Volts, 5, 1);
  //BatterySense = expoAVG(getVoltage(battSense), BatterySense, 0.3);
  //floatPrint(BatterySense, 5, 1);
  lcd.print(F("VLT"));
}
void displayLambda ()
{
  lcd.print(" "); //1 spacer
  if (engine == 2){
    intPrint(Lambda, 4);
    lcd.print(F("mVo"));
  }
  else{
    lcd.print(Lambda, 2);
    lcd.print(F("vO2"));
  }
}
void displayExhaust ()
{
  if (Exhaust == Lean)
    lcd.print(" Lean"); //if less than do
  else
    lcd.print(" Rich"); // else do greater than
  lcd.print(F(" EX"));
}
void displayLambdaHeater ()
{ 
  /*float tempVolts = (getVoltage(pin6) - 0.5) * 25; // convert to pin voltage
  floatPrint(tempVolts, 5, 1);
  lcd.print(F("PSI"));
  */
  floatPrint(LambdaHeater, 5, 1);
  lcd.print(F("vHT"));
}
void displayLoopStatus ()
{
  if (LoopStatus == Clsd)
    lcd.print(" Clsd");
  else if (LoopStatus == Dcel)
    lcd.print(" Dcel");
  else lcd.print(" Open"); 
  
  lcd.print(" LP");   
}
void displayEGR ()
{
  if (EGR == true)
    lcd.print("  On"); //if odd
  else lcd.print(" Off"); //else even
  lcd.print(F(" EGR"));
}
void displayTPS ()
{
  lcd.print(" ");
  if (tpsMode == false){ //Advance TPS Mode
    if (ThrottleSwitch == Clsd)
      lcd.print("C");
    else if (ThrottleSwitch == WOT)
      lcd.print("W");
    else lcd.print("P");
  }
  else lcd.print(" ");
  
  intPrint(TPS, 3);
  lcd.print("TPS");
}
void displayThrottleSwitch ()
{  
  if (ThrottleSwitch == Clsd)
    lcd.print(" Clsd");
  else if (ThrottleSwitch == WOT)
    lcd.print("  WOT");
  else lcd.print(" Part");    
    
  lcd.print(F(" TH"));
}
void displaySparkADV ()
{
  intPrint(SparkADV, 5);
  lcd.print(F("IGN"));
}
void displayKnock ()
{
  intPrint(Knock, 5);
  lcd.print(F("KNO"));
}
void displayInjPulse ()
{
  floatPrint(InjPulse, 5, 1); // 1 decimal
  lcd.print(F(" mS"));
}
void displayInjDuty ()
{
  floatPrint(InjDuty, 5, 1);
  lcd.print("%DC");
}
void displayBaro ()
{
  floatPrint(Baro, 4, 1); //1 decimal
  lcd.print("AT");
}
void displayFuelSync ()
{
  lcd.print(" ");
  lcd.write(2); // spiny bit
  lcd.print(" ");
  
  if (FuelSync == true)
    lcd.print("-");
  else 
    lcd.print("+");
  
  lcd.print(F(" SYN"));
//ok so this seems backwards but createChar erases lcd cursor memory so it must go last, 
//displayed characters automatically update to latest lcd CGRAM input
  createDizzyChar(); 
}
void displaySTFuel ()
{ 
  if (fuelTrimUnit == true) //Zero center, print + and -
  {
    if (STFT >= 0)
      lcd.print(" +");
    else
      lcd.print(" -");

    intPrint(abs(STFT), 3);
  }
  else
    intPrint(STFT, 5);  //Stock 128 center
    
  lcd.print(F(" ST"));
}
void displayLTFuel ()
{ 
  if (fuelTrimUnit == true) //Zero center, print + and -
  {
    if (LTFT >= 0)
      lcd.print(" +");
    else
      lcd.print(" -");

    intPrint(abs(LTFT), 3);
  }
  else
    intPrint(LTFT, 5);  //Stock 128 center
    
  lcd.print(F(" LT"));
}
void displayACSwitch ()
{
  if (ACSwitch == true)
    lcd.print("  On"); //if odd
  else lcd.print(" Off"); //else even
  lcd.print(F(" A/C"));
}
void displayACRequest ()
{
  if (ACRequest == true)
    lcd.print(" Yes"); //if odd
  else lcd.print("  No"); //else even
  lcd.print(F(" REQ"));
}
void displayACClutch ()
{
  if (ACClutch == true) //2.5L only
    lcd.print("  On"); //if odd
  else lcd.print(" Off"); //else even
  lcd.print(F("ACCL"));
}
void displayACStatus ()
{
  if (ACClutch == true && ACRequest == true)
    lcd.print("  On");
  else if (ACRequest == true)
    lcd.print(" Req");
  else if (ACSwitch == true)
    lcd.print(" Sel");
  else
    lcd.print(" Off");
  
  lcd.print(F(" A/C"));
}
void displayNSS() //double duty for 2.5L PS Sw as well
{
  if (engine == 2)
  {
    if (PSSwitch == true)
      lcd.print("High");
    else lcd.print(" Low");
    lcd.print(F(" PSw"));
  }
  else
  {
    if (NSS == true)      //4.0L A/T only
      lcd.print(" R-D");
    else lcd.print(" P-N");
    lcd.print(F(" NSS"));
  }
}
void displayMPG ()
{
  if (InjDuty == 0) //fixes inf error
    lcd.print(" 9999");
  else floatPrint(MPG, 5, 1);
        
  if (speedUnit == false)
    lcd.print("LHK");
  else
    lcd.print("MPG");
}
void displayGPH ()
{
  if (MPH > 0 && mpgMode == false)//MPG Mode
    displayMPG();
  else{ //GPH Mode
    if (GPH > 9.95)
      floatPrint(GPH, 5, 1);
    else
      floatPrint(GPH, 5, 2);
    if (speedUnit == false)
      lcd.print("LPH");
    else
      lcd.print("GPH");
  }
}
void displayAVG ()
{
  if (transType == false)   
    floatPrint(avgGPH, 5, 2);
  else  
    floatPrint(avgMPG, 5, 1);
  lcd.print("AVG");
}
void displayMPH ()
{
  if (transType == false){
    lcd.print(" ^"); //highest gear symbol I guess
    intPrint(MPH, 3);
  }
  else
    intPrint(MPH, 5);
    
  if (speedUnit == false)
    lcd.print("KPH ");
  else
    lcd.print("MPH ");
}
void displayGear ()
{  
  lcd.print(" ");
  if (tcuGear == 0)
    lcd.print("?");
  else
    lcd.print(tcuGear);
  
  if (solenoid3 == true)
    lcd.print("L ");
  else{
    switch(tcuGear)
    {
      case 1: //1st
        lcd.print("st");
      break;
      case 2: //2nd
        lcd.print("nd");
      break;
      case 3: //3rd
        lcd.print("rd");
      break;
      case 4: //4th
        lcd.print("th");
      break;
      default: //????
        lcd.print("??");
      break;
    }
  }
  lcd.print("GEAR");
}
void displayTransInfo ()
{
  if (tcuBrake == true)
    lcd.print(" B");
  else
    lcd.print("  ");

  if (solenoid1 == true)
    lcd.print("1");
  else
    lcd.print(" ");

  if (solenoid2 == true)
    lcd.print("2");
  else
    lcd.print(" ");

  if (solenoid3 == true)
    lcd.print("L");
  else
    lcd.print(" ");
    
  if (tcuMode == true)
    lcd.print("P");
  else
    lcd.print("C");
    
  lcd.print(tcuTPS);
  lcd.print("T");  
}
void displayIAC()
{
   lcd.print(" ");
  
  if (IACtimer + 500 > millis()){ //display for minimum time 
    if (IACdir == true)
      lcd.print(">"); //open
    else
      lcd.print("<"); //closed
  }
  else
    lcd.print(" ");
  intPrint(IAC ,3);
  lcd.print("IAC");
}
void displayOutputs()
{
  if (fan3State == LOW)
    lcd.print(" ");

  if (fan2State == LOW)
    lcd.print("  ");
  
  if (fan1State == HIGH)
    lcd.print("1 ");
  else lcd.print("  ");

  if (fan2State == HIGH)
    lcd.print("2 ");

  if (fan3State == HIGH)
    lcd.print("3");
  
  lcd.print("FAN");
}
void displayAFR()
{
  if (EEPROM.read(EEwidebandPin) == 0){ //Fake AFR from Inverse of L/(1+e^(-k*(x-x0))) 
    floatPrint(estAFR, 5, 1);
  }
  else{
    if (AFRV < 0.5 && smartWideband())
      lcd.print(" HEAT");
    else if (AFRV > 4.5 && smartWideband())
      lcd.print(" ERRO");
    else
      floatPrint(AFR, 5, 1);
  }
  
  lcd.print("A/F");
}

void displayFPR()
{
  if (EEPROM.read(EEfuelPressurePin) != 0)
  {
    float temp = 0;
    temp = getPSISensor(EEPROM.read(EEfuelPressurePin)); //Get PSI reading
    floatPrint(temp, 5, 1); //Tylers custom setup
  }
  else
    lcd.print(F("---.-"));
    
  lcd.print(F("FPR"));
}
