//8x1 horizontal scroll history line graph

void printLongScroll (int input, int loput, int hiput, byte xCurs, byte yCurs, byte Length){  
  static int Output;
  int OutputPrev = Output; //save old value first, change to "static int" for a filled in bottom
  
  Output = constrain((((input - loput) * 9) / (hiput - loput)), 0, 9); //convert number into 0 - 9 unit range, 0 and 9 are cutoff

  charFlag = true; //used for other functions that use custom characters

//fancy stuff to fill in gaps
  byte graphInput = Output;
  byte leftover = abs(OutputPrev - Output);
  bool signFlag = false;

  if ((OutputPrev - Output) > -1)
    signFlag = true;

  static byte row1a;
  static byte row2a;
  static byte row3a;
  static byte row4a;
  static byte row5a;
  static byte row6a;
  static byte row7a;
  static byte row8a;
  
  static byte row1b;
  static byte row2b;
  static byte row3b;
  static byte row4b;
  static byte row5b;
  static byte row6b;
  static byte row7b;
  static byte row8b;
  
  static byte row1c;
  static byte row2c;
  static byte row3c;
  static byte row4c;
  static byte row5c;
  static byte row6c;
  static byte row7c;
  static byte row8c;
  
  static byte row1d;
  static byte row2d;
  static byte row3d;
  static byte row4d;
  static byte row5d;
  static byte row6d;
  static byte row7d;
  static byte row8d;
  
  static byte row1e;
  static byte row2e;
  static byte row3e;
  static byte row4e;
  static byte row5e;
  static byte row6e;
  static byte row7e;
  static byte row8e;
  
  static byte row1f;
  static byte row2f;
  static byte row3f;
  static byte row4f;
  static byte row5f;
  static byte row6f;
  static byte row7f;
  static byte row8f;
  
  static byte row1g;
  static byte row2g;
  static byte row3g;
  static byte row4g;
  static byte row5g;
  static byte row6g;
  static byte row7g;
  static byte row8g;
  
  static byte row1h;
  static byte row2h;
  static byte row3h;
  static byte row4h;
  static byte row5h;
  static byte row6h;
  static byte row7h;
  static byte row8h;
      
//shifting previous sequence
  row1a = row1a << 1;
  row2a = row2a << 1;
  row3a = row3a << 1;
  row4a = row4a << 1;
  row5a = row5a << 1;
  row6a = row6a << 1;
  row7a = row7a << 1;
  row8a = row8a << 1;

  row1b = row1b << 1;
  row2b = row2b << 1;
  row3b = row3b << 1;
  row4b = row4b << 1;
  row5b = row5b << 1;
  row6b = row6b << 1;
  row7b = row7b << 1;
  row8b = row8b << 1;

  row1c = row1c << 1;
  row2c = row2c << 1;
  row3c = row3c << 1;
  row4c = row4c << 1;
  row5c = row5c << 1;
  row6c = row6c << 1;
  row7c = row7c << 1;
  row8c = row8c << 1;

  row1d = row1d << 1;
  row2d = row2d << 1;
  row3d = row3d << 1;
  row4d = row4d << 1;
  row5d = row5d << 1;
  row6d = row6d << 1;
  row7d = row7d << 1;
  row8d = row8d << 1;
  
  row1e = row1e << 1;
  row2e = row2e << 1;
  row3e = row3e << 1;
  row4e = row4e << 1;
  row5e = row5e << 1;
  row6e = row6e << 1;
  row7e = row7e << 1;
  row8e = row8e << 1;
  
  row1f = row1f << 1;
  row2f = row2f << 1;
  row3f = row3f << 1;
  row4f = row4f << 1;
  row5f = row5f << 1;
  row6f = row6f << 1;
  row7f = row7f << 1;
  row8f = row8f << 1;
  
  row1g = row1g << 1;
  row2g = row2g << 1;
  row3g = row3g << 1;
  row4g = row4g << 1;
  row5g = row5g << 1;
  row6g = row6g << 1;
  row7g = row7g << 1;
  row8g = row8g << 1;
  
  row1h = row1h << 1;
  row2h = row2h << 1;
  row3h = row3h << 1;
  row4h = row4h << 1;
  row5h = row5h << 1;
  row6h = row6h << 1;
  row7h = row7h << 1;
  row8h = row8h << 1;

//update newest column
  do {
    switch (graphInput)
    {
      case 1:
        bitSet(row8h,0);
      break;
      case 2:
        bitSet(row7h,0);
      break;
      case 3:
        bitSet(row6h,0);
      break;
      case 4:
        bitSet(row5h,0);
      break;
      case 5:
        bitSet(row4h,0);
      break;
      case 6:
        bitSet(row3h,0);
      break;
      case 7:
        bitSet(row2h,0);
      break;
      case 8:
        bitSet(row1h,0);
      break;
    }
  //loop continues untill gap is filled
    if (leftover > 0){
      --leftover;
      if (signFlag == true)
        ++graphInput;
      else
        --graphInput;
    }
    
  } while (leftover > 0);

//transfer offscreen bits to next segment
if (bitRead(row1h, 5))
  bitSet(row1g,0);
  
if (bitRead(row2h, 5))
  bitSet(row2g,0);

if (bitRead(row3h, 5))
  bitSet(row3g,0);
  
if (bitRead(row4h, 5))
  bitSet(row4g,0);
  
if (bitRead(row5h, 5))
  bitSet(row5g,0);
  
if (bitRead(row6h, 5))
  bitSet(row6g,0);

if (bitRead(row7h, 5))
  bitSet(row7g,0);

if (bitRead(row8h, 5))
  bitSet(row8g,0);


  

if (bitRead(row1g, 5))
  bitSet(row1f,0);
  
if (bitRead(row2g, 5))
  bitSet(row2f,0);

if (bitRead(row3g, 5))
  bitSet(row3f,0);
  
if (bitRead(row4g, 5))
  bitSet(row4f,0);
  
if (bitRead(row5g, 5))
  bitSet(row5f,0);
  
if (bitRead(row6g, 5))
  bitSet(row6f,0);

if (bitRead(row7g, 5))
  bitSet(row7f,0);

if (bitRead(row8g, 5))
  bitSet(row8f,0);



  
if (bitRead(row1f, 5))
  bitSet(row1e,0);
  
if (bitRead(row2f, 5))
  bitSet(row2e,0);

if (bitRead(row3f, 5))
  bitSet(row3e,0);
  
if (bitRead(row4f, 5))
  bitSet(row4e,0);
  
if (bitRead(row5f, 5))
  bitSet(row5e,0);
  
if (bitRead(row6f, 5))
  bitSet(row6e,0);

if (bitRead(row7f, 5))
  bitSet(row7e,0);

if (bitRead(row8f, 5))
  bitSet(row8e,0);




if (bitRead(row1e, 5))
  bitSet(row1d,0);
  
if (bitRead(row2e, 5))
  bitSet(row2d,0);

if (bitRead(row3e, 5))
  bitSet(row3d,0);
  
if (bitRead(row4e, 5))
  bitSet(row4d,0);
  
if (bitRead(row5e, 5))
  bitSet(row5d,0);
  
if (bitRead(row6e, 5))
  bitSet(row6d,0);

if (bitRead(row7e, 5))
  bitSet(row7d,0);

if (bitRead(row8e, 5))
  bitSet(row8d,0);

  


if (bitRead(row1d, 5))
  bitSet(row1c,0);
  
if (bitRead(row2d, 5))
  bitSet(row2c,0);

if (bitRead(row3d, 5))
  bitSet(row3c,0);
  
if (bitRead(row4d, 5))
  bitSet(row4c,0);
  
if (bitRead(row5d, 5))
  bitSet(row5c,0);
  
if (bitRead(row6d, 5))
  bitSet(row6c,0);

if (bitRead(row7d, 5))
  bitSet(row7c,0);

if (bitRead(row8d, 5))
  bitSet(row8c,0);



if (bitRead(row1c, 5))
  bitSet(row1b,0);
  
if (bitRead(row2c, 5))
  bitSet(row2b,0);

if (bitRead(row3c, 5))
  bitSet(row3b,0);
  
if (bitRead(row4c, 5))
  bitSet(row4b,0);
  
if (bitRead(row5c, 5))
  bitSet(row5b,0);
  
if (bitRead(row6c, 5))
  bitSet(row6b,0);

if (bitRead(row7c, 5))
  bitSet(row7b,0);

if (bitRead(row8c, 5))
  bitSet(row8b,0);




if (bitRead(row1b, 5))
  bitSet(row1a,0);
  
if (bitRead(row2b, 5))
  bitSet(row2a,0);

if (bitRead(row3b, 5))
  bitSet(row3a,0);
  
if (bitRead(row4b, 5))
  bitSet(row4a,0);
  
if (bitRead(row5b, 5))
  bitSet(row5a,0);
  
if (bitRead(row6b, 5))
  bitSet(row6a,0);

if (bitRead(row7b, 5))
  bitSet(row7a,0);

if (bitRead(row8b, 5))
  bitSet(row8a,0);


//create new display character
byte spot1[8] =
{
  row1a,
  row2a,
  row3a,
  row4a,
  row5a,
  row6a,
  row7a,
  row8a
};

byte spot2[8] =
{
  row1b,
  row2b,
  row3b,
  row4b,
  row5b,
  row6b,
  row7b,
  row8b
};

byte spot3[8] =
{
  row1c,
  row2c,
  row3c,
  row4c,
  row5c,
  row6c,
  row7c,
  row8c
};

byte spot4[8] =
{
  row1d,
  row2d,
  row3d,
  row4d,
  row5d,
  row6d,
  row7d,
  row8d
};

byte spot5[8] =
{
  row1e,
  row2e,
  row3e,
  row4e,
  row5e,
  row6e,
  row7e,
  row8e
};

byte spot6[8] =
{
  row1f,
  row2f,
  row3f,
  row4f,
  row5f,
  row6f,
  row7f,
  row8f
};

byte spot7[8] =
{
  row1g,
  row2g,
  row3g,
  row4g,
  row5g,
  row6g,
  row7g,
  row8g
};

byte spot8[8] =
{
  row1h,
  row2h,
  row3h,
  row4h,
  row5h,
  row6h,
  row7h,
  row8h
};

//print the magic
  if (Length > 0)
    lcd.createChar(1, spot1);
  if (Length > 1)
    lcd.createChar(2, spot2);
  if (Length > 2)
    lcd.createChar(3, spot3);
  if (Length > 3)
    lcd.createChar(4, spot4);
  if (Length > 4)
    lcd.createChar(5, spot5);
  if (Length > 5)
    lcd.createChar(6, spot6);
  if (Length > 6)
    lcd.createChar(7, spot7);
  if (Length > 7)
    lcd.createChar(8, spot8);
  
  lcd.setCursor(xCurs, yCurs);

  if (Length > 0)
    lcd.write(1);
  if (Length > 1)
    lcd.write(2);
  if (Length > 2)
    lcd.write(3);
  if (Length > 3)
    lcd.write(4);
  if (Length > 4)
    lcd.write(5);
  if (Length > 5)
    lcd.write(6);
  if (Length > 6)
    lcd.write(7);
  if (Length > 7)
    lcd.write(8);
}
