
//Code to do with activating the Check Engine Light goes here.

boolean celRequest = false;
boolean celFlag = false;
unsigned long celTimer = 0;

void updateCEL (){
  celRequest = false;//resets cel flag
    switch(cel)
    {
      case 3://CEL Warning Mode
        if (RPM > 400 && RPM < 5500) //CEL's for Engine Running
        {
          if (CTSRaw < 2 || CTSRaw > 240){
            celRequest = true;
            celGauge = CTSGauge;
            celStar();
          }
          if (IATRaw < 2 || IATRaw > 200){
            celRequest = true;
            celGauge = IATGauge;
            celStar();
          }
          if (Volts < 12.6 || Volts > 15.5){
            celRequest = true;
            celGauge = voltGauge;
            celStar();
          }
          currentTime = millis();
          if (Lambda == LambdaPrev){
            if (LambdaCounter == false){
              LambdaPrevTime = millis();
              LambdaCounter = true;
            }
            if (currentTime > (LambdaPrevTime + 20000)){
              celRequest = true;
              celGauge = lambdaGauge;
              celStar();
            }
          }
          else{
            LambdaPrev = Lambda; //check for new number
            LambdaCounter = false; //Reset Counter
          }
          if (RPM < 500 || (RPM > 5000 && RPM < 7000)){
            celRequest = true;
            celGauge = RPMGauge;
            celStar();
          }
          if (Knock > 80){
            celRequest = true;
            celGauge = knockGauge;
            celStar();
          }
        }//end Warning Engine running CEL 
        else//CEL's for Engine Off
        {
          if (MAPRaw < 85 || MAPRaw > 253){
            celRequest = true;
            celGauge = MAPGauge;
            celStar();
          }
        }//end Warning Engine Off CEL
        if (TPS < 10 || TPS > 96){
            celRequest = true;
            celGauge = TPSGauge;
            celStar();
          }  
      //break;//Notice this is commented out, tricky use of switch case so that faliure code doesn't have to be duplicated for above
      case 2://CEL Faliure Mode
        if (MAPRaw < 2 || MAPRaw > 253 || (MAPRaw >= BaroRaw && RPM > 500 && RPM < 5200)){
          celRequest = true;//sets cel flag
          celGauge = MAPGauge;//sets to the gauge array number for the void to use
          celStar();//void checks for any active gauges and indicates cel with "*"
        }
        if (CTSRaw < 2 || CTSRaw > 253){
          celRequest = true;
          celGauge = CTSGauge;
          celStar();
        }
        if (IATRaw < 2 || IATRaw > 253){
          celRequest = true;
          celGauge = IATGauge;
          celStar();
        }
        currentTime = millis();
        if (Lambda == LambdaPrev){
          if (LambdaCounter == false){
            LambdaPrevTime = millis();
            LambdaCounter = true;
          }
          if (currentTime > (LambdaPrevTime + 60000)){
            celRequest = true;
            celGauge = lambdaGauge;
            celStar();
          }
        }
        else{
          LambdaPrev = Lambda; //check for new number
          LambdaCounter = false; //Reset Counter
        }
        if (TPS < 3 || TPS > 96){
          celRequest = true;
          celGauge = TPSGauge;
          celStar();
        }  
      break;
    }//end CEL Switch case
    
  if (celRequest == true){//used to trigger the cel
    if (celFlag == false){//time record
      celTimer = millis();
      celFlag = true;
    }
    currentTime = millis();
    if (celFlag == true && currentTime > celTimer + 2000)//time check
      celOn();//turns CEL on
    }
  else{//reset variables
    celOff();//turns CEL off
    celFlag = false;
  }
    
}//void end

