 /*
  Renduinix Plus v0.851 OLED Port, for REM II (V4.1) models ONLY!

  This was orginally complied on Arduino IDE 1.8.3 and used 71,851 bytes PS, 7,084 bytes DM
  
  UPLOAD SETTINGS:

  - Tools > Board: > Teensy 3.2
  - Tools > CPU Speed > 96MHz    (48MHz for compatibility with tcu baud rate is not using Serial3)
  - Tools > Port > Teensy
  - Tools > Programmer: > AVRISP mkII

  Requires RTClib Library from adafruit to be installed to compile.
  - Sketch > Include Library > Add .ZIP Library...

  Links:
   - REM+ V3 Update Video: https://www.youtube.com/watch?v=4vQw_9jwLiE
   - SiLabs Drivers: http://www.silabs.com/products/mcu/pages/usbtouartbridgevcpdrivers.aspx
   - RTClib.h Download: https://github.com/adafruit/RTClib
   - Windows USBTiny Drivers: https://learn.adafruit.com/usbtinyisp/drivers
   - Mac FTDI Drivers: https://learn.sparkfun.com/tutorials/how-to-install-ftdi-drivers/mac
   
**********************************************************************************************************************

  
  This code is formated for the open source Renix Engine Monitor but can be built on a breadboard.
  This sketch will read a 1987 to 1990 Jeep Renix ECU's TX output, convert the string into useable measurements,
  and display them on a 16x2 LCD display allowing you to cylce through with buttons.

  Renduinx Plus allows the Renix Engine Monitor to read the AW-4 TCU Serial Stream as well with a jumper wire and
  1k pull-up resistor to 5v. The TCU does all of the other work for creating the logic level.
  
  The circuit:
   A PJRC Teensy 3.2 is connected to a 16x2 RGB LCD Screen and 5 buttons to provide the base scanner. 

    Components needed for ECU communication:
     just about any NPN Transisitor (I'm using a 2N3904)
     a 1k and 3.3k Resistor (1k isn't even nessisary with onboard pullup)
     some wire and maybe a breadboard

   The Renix Diagnostic Connector has 2 ports, D2 is the larger one. D2 Pins are numbered
   Bottom to Top, Left to Right if D1 is to the Left of D2

     D1      D2
    |4 1|   <3 6 9 12 15|
    |5 2)   <2 5 8 11 14|
    |6 3|   <1 4 7 10 13|

    Pin D2-1 is the ECU TX output, it is open collector to ground
    Pin D2-4 is Ignition Postive (+)
    Pin D2-7 is Ignition Ground  (-)
    Pin D2-15 is TCU TX output

   We will use an NPN transistor to physically NOT (invert) the data and use some resistors to get the switching done

    Arduino VIN pin ->  Pin D2-4 Ign Pos(+) (Arduino Uno is good to 20v, Adafruit to 16v, Teensy only 6V so EXTERNAL needed)
    Arduino 5V pin  ->  3.3k resistor -> NPN Base      <- Pin D2-1 ECU TX     (This is the ECU Input)
    Arduino 5V pin  ->  1k resistor   -> NPN Collector <- Arduino RX Pin 0    (This is the Output to Arduino)
    Arduino Gnd pin ->                   NPN Emitter   <- Pin D2-7 Ign Gnd(-) (Negitive Rail)
    Arduino 5v pin  ->  1k resistor   -> Arduino RX2   <- Pin D2-15 TCU TX    (TCU Input)

  Core Code
  RenixComm V 0.3
  First incarnation January 7th, 2012
  This revision Jan 17th, 2012 (Subrevision 24)
  Phil Andrews 2011, 2012
  Thanks to Kes for help with the code

  Additional Code
  Renduinix v0.850
  Created July 13th, 2016 (v0.1)
  by Nick Risley
  Modified Novemeber 23rd, 2017

  Update Log:
  v0.1 Modified core code to display predetermined outputs on a 16x2 display
  v0.2 Interfaced buttons to cycle through a sensor array
  v0.3 Updated calculations to show proper, added more data points, and debounced button presses
  v0.4 Cleaned up formating, custom character, updated text data points, added permanent memory function
  v0.5 Update pins for Trinket Pro, fixed RPM calc, added custom backlight options, fixed freeze if no data was present
  v0.6 Migrated code to Switch Case, Revamped Menu System, improved stream acquisition, added settings and debug, unified gauge spacing, added custom Baud and PROG# Option
  v0.7 Added EEPROM presets and reset, revamped vehicle selection, released Alpha Models
     -0.71 Fixed Color and Software Info Menus
     -0.72 Fixed Vehicle Selection Menu, added basic CEL function
     -0.73 Added RPM Error Check
     -0.74 Rewrote gauge delay to improve buttons, maxed Green and Cyan intensity, updated button delays, added Throttle Switch & Data Check gauge
     -0.75 Added TPS and Knock Error Check, updated Vehicle Screen, added more CEL Options, made data check more useful, added unit conversions, fixed switch analog pin reference, added cel notification, reactivated Custom Program option
     -0.76 Updated Data Gauge, Added correct RPM check, CEL tweaking, Added adv TPS and loop option, Added Vac Gauge, Filled out Diagnostic Menu, condensed bulky variables, unified data acquisition code
        -0.761 Quick fix, Commented out Custom Program Menu for a bit more free ram to allieviate crashes
     -0.77 Updated Settings Text and Diagnose Menu Units, added diagnostic CEL, tweaked CEL, added Beta hardware support, updated button debouncing, added serial average modifier for speed, freed most text from RAM
     -0.78 tweaked CEL, fixed TPS skip issue, robust 255 data handling, tweaked auto birghtness, added min/max feature, added auto brightness menu
        -0.781 removed Bar Pressure and replaced it with Voltage, slightly updated gauge math
        -0.782 added screen auto re-sync and home button screen reset
     -0.79 added flag to display.clear commands, removed stream averaging, updated diagnostic menu, added injector ducty cycle
       
       -0.79+ adds basic TCU Support, used const byte, trimmed total bytes, commented out the fat, added speed unit
       -0.791+ added seperate time var for auto sync, adjuted tcu screen updating, updated Duty Cycle formatting, updated splash screen
       -0.792+ increased null button range, added seperate tcu time variable, fixed gauges updating for auto resync and buttons, increased tcu array to fix final byte issues, tuned CELs
  v0.8 Seprated data and cel to tab, Simultaneous data reading, added gph and mpg, EEprom float values, added 0-60 timer, added cel delay, fixed Baro calc, added vehicle menu and trans variable, selective (F) macros saved 600b ram, adjusted button range, rewrote button debouncing code
       -0.801+ Updated TCU Array timing to prevent accidental early reading, updated GPH reading, added 0-60 restart, rolled back ECU search code to old method, removed LockUp byte
      
       -0.802+V3 Added other pin variables, Added RTC Stuff, added time to home screen & guages, moved Trans options to Vehicle, condensed duplicate variables, Removed Wait Screen, InjDC to float, 0-60 reset fix, Clock Menu, fixed MAPRaw TireSize and SpeedCorr float dependencies, removed resync screen
     -0.81+V3 Fixed Vehicle # display issue, 0to60 buttons & formatting, changed transType tempUnit speedUnit tpsUnit loopMode splashScreen lambdacounter tcuReadFlag & updateScreen to Boolean, added TCU Errors, readdisplaybuttons & rgb values to byte, TCU screen throttling for read speed, moved clock gauge for speed
       -0.811+V3 Fixed M/T GPH issue, updated TCU Error Scrolling, added gauge # variables and porting notes, Updated KPH calc, added LPH and LHK conversion, fixed double 12am issue, setCursor cleaning, autoDim menu tweak
       -0.812+V3 updated reset values, 0-60 tweak, added ECU detection
     
     -0.82+V4 Updated pins to V4 Spec, Added 2.5L support, fixed dim menu spacing, re-calibrated VHT, fixed date spacing, gyro gauges, cleaned up get_gata, adjusted color values, wrote gauge skip function, EGR gauge, added Gauges tab, updated rpm math, updated ECU detection, gyro and BT options, button filtering, CEL dimming
     -0.83+V4 Updated TCU Screen formatting, added Out Support, fixed TCU read bugs, loop time efficiency improvements, rewrote display refresh throttling routine, fixed 0-60 timer, removed wait menu, added advanced menu     

     -0.851+V4.1 OLEDPORT updated fan control and menu, removed CEL PWM, rearragned i2c start-up and added i2c restart, added extra gyro stuff, updated ecu reading, revamped time code, update gyro gauge, added usb reboot option
*/
const float softwareVersion = 0.851;

#include <EEPROM.h> //included for EEPROM memory functions
//#include <LiquidCrystal.h> //included to interface with the LCD

//RTC clock stuff
#include <Wire.h>
#include "RTClib.h"
RTC_DS3231 rtc;//sets RTC chip type
boolean hourSetting;
boolean homeScreen = false;//for clock option
byte timeSetOrder = 1;
byte timeMenuOrder = 1;

//Gyro/Mag Stuff
#include <Adafruit_Sensor.h>
#include <Adafruit_FXAS21002C.h>
#include <Adafruit_FXOS8700.h>
#include <Mahony.h>
#include <Madgwick.h>
// Mahony is lighter weight as a filter and should be used
// on slower systems
Mahony filter;
//Madgwick filter;
/* Assign a unique ID to this sensor at the same time */
Adafruit_FXAS21002C gyro = Adafruit_FXAS21002C(0x0021002C);
Adafruit_FXOS8700 accelmag = Adafruit_FXOS8700(0x8700A, 0x8700B);

//OLED stuff
// OLED to Teensy 3.2 PINOUT:
// 1 to GND
// 2 to 3.3v
// 4 to 5
// 7 to 13
// 8 to 11
// 15 to 8
// 16 to 6

#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1325.h>

// If using software SPI, define CLK and MOSI
#define OLED_CLK 13
#define OLED_MOSI 11

// These are neede for both hardware & softare SPI
#define OLED_CS 8 
#define OLED_RESET 6 //was 9
#define OLED_DC 5 //was 8

// this is software SPI, slower but any pins
//Adafruit_SSD1325 display(OLED_MOSI, OLED_CLK, OLED_DC, OLED_RESET, OLED_CS);

// this is for hardware SPI, fast! but fixed oubs
Adafruit_SSD1325 display(OLED_DC, OLED_RESET, OLED_CS);

byte celDim = 25; //0 = off, 255 = max, controls CEL Brightness

//V4.1 Pins 
                //RS, E, 4, 5, 6, 7
//LiquidCrystal display(1, 2, 3, 4, 5, 6);//olddisplay
//const byte ECUpin = 0; //RX1
const byte TCUpin = 7; //RX3
const byte celpin = A9; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
//const byte redPin = A8;//olddisplay
//const byte greenPin = A7;//olddisplay
//const byte bluePin = A6;//olddisplay
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A10;
const int o2HeaterPin = A11;
const int AFRPin = A8;
//In/Out Pins
const byte pin1 = A1;
const byte pin2 = A2;
const byte pin3 = A3;

/*
//V4 Pins 
                //RS, E, 4, 5, 6, 7
//LiquidCrystal display(1, 2, 3, 4, 5, 6);//olddisplay
//const byte ECUpin = 0; //RX1
const byte TCUpin = 9; //RX2
const byte celpin = A9; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
//const byte redPin = A8;//olddisplay
//const byte greenPin = A7;//olddisplay
//const byte bluePin = A6;//olddisplay
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A1;
const int o2HeaterPin = A2;
const int AFRPin = A8;
//In/Out Pins
const byte pin1 = A11;//A11 orginally, both are analog only, whoops
const byte pin2 = A10;//A10 orginally, use 10-12 if not using sd card for more functions
const byte pin3 = A3;//
*/
/*
//V3 Pins
                //RS, E, 4, 5, 6, 7
LiquidCrystal display(4, 5, 6, 7, 8, 12);
const byte TCUpin = 2;
const byte celpin = 3; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = 11;
const byte greenPin = 10;
const byte bluePin = 9;
//Analog Pins
const int lightSensorPin = A0;
const int buttonsPin = A1;
const int o2HeaterPin = A2;*/
/*
// V1 & V2 Pins
                //RS,  E, 4, 5, 6, 7
LiquidCrystal display(12, A0, 8, 6, 5, 4);
const int TCUpin = A3;
const byte celpin = 3; //Check Engine Light
//LCD RGB Backlight Pins, uses PWM
const byte redPin = 9;
const byte greenPin = 10;
const byte bluePin = 11;
//Analog Pins
const int lightSensorPin = A4;
const int buttonsPin = A1;
const int o2HeaterPin = A2;
*/
/*
//Custom character setup for LCD
byte leftArrow[8] =//display1
{
  B00010,
  B00100,
  B01000,
  B11111,
  B01000,
  B00100,
  B00010
};
byte rightArrow[8] =//display2
{
  B01000,
  B00100,
  B00010,
  B11111,
  B00010,
  B00100,
  B01000
};
byte fahrenheitSymbol[8] =//display3
{
  B11000,
  B11000,
  B01111,
  B01000,
  B01110,
  B01000,
  B01000
};
byte celsiusSymbol[8] =//display4
{
  B11000,
  B11000,
  B00110,
  B01001,
  B01000,
  B01001,
  B00110
};
*/
//values for buttons
byte lcdKey  = 0;
byte btnPrev = 0;
int adcKeyIn = 0; //Analog read, keep int
unsigned long btnPrevTime;
int btnRead1; //keep int for analog read
int btnRead2;
int btnRead3;
int btnRead4;
const byte btnNONE = 0;
const byte btnHOME = 1;
const byte btnBOTTOMRIGHT = 2;
const byte btnBOTTOMLEFT = 3;
const byte btnTOPRIGHT = 4;
const byte btnTOPLEFT = 5;

//Delays next button press in ms, poor mans debounce fucntion
const byte buttonDelayFast = (10);  //used for fast selection

// read the buttons
byte readLcdButtons()
{
  if (millis() > btnPrevTime + 10){//time throttled sampling for more spaced out readings
    btnPrevTime = millis();
  //shifts last 4 button reads
  btnRead4 = btnRead3;
  btnRead3 = btnRead2;
  btnRead2 = btnRead1;
  btnRead1 = analogRead(buttonsPin);      // read the value from the button resistors

  // absolutle comparator makes sure all reads are within 4 units of each other to filter noise and button rise time
  if(abs(btnRead4 - btnRead1) < 5 && abs(btnRead3 - btnRead1) < 5 && abs(btnRead2 - btnRead1) < 5 && abs(btnRead4 - btnRead2) < 5)
    adcKeyIn = btnRead1;    // pass value through if it is consistant
  }
  
  // my buttons when read are centered at these values: 0, 512, 601, 698, 845, 1022
  // we add approx 10 to those values to allow variation
  if (adcKeyIn < 500) return btnNONE; // We make this the 1st option for speed reasons since it will be the most likely result

  // custom thresholds used
  if (adcKeyIn < 522)  return btnHOME;        //512
  if (adcKeyIn < 611)  return btnBOTTOMRIGHT; //601
  if (adcKeyIn < 708)  return btnBOTTOMLEFT;  //698
  if (adcKeyIn < 855)  return btnTOPRIGHT;    //845
  if (adcKeyIn < 1025) return btnTOPLEFT;     //1022
  return btnNONE;  // when all others fail, return this...
}

//Program Runtime variables, used to slow down gauge screen without delays and other timing
unsigned long currentTime = 0;
unsigned long prevTime = 0;
unsigned long resyncPrevTime = 0;
unsigned long btPrev = 0;

// Serial registers etc
byte prev = 0;
byte current = 255;
byte next = 255;
byte Position = 0;
byte dataStream[31];  // 32 bytes. we only have 1024 to play with. 31 for data, 1 for sign apart from it doesn't use the sign. bah.
//byte averageStream[31];
bool dataStreamCounter = false;// used to check for double 255's
byte bluetoothStream[16];
byte counter;

// Serial data variables
//byte ProgramVersion = 0;
//byte PROMversion = 0;
//byte CalibrationCode = 0;
//unsigned long PROM = 0;
byte MAPRaw = 0;
float MAP = 0; 
float MAPMin = 0;
float MAPMax = 0;
float Vacuum = 0;
byte VacuumRaw = 0;
byte CTSRaw = 0;
int CTS = 0;
int CTSMin = 0;
int CTSMax = 0;
int IAT = 0;
int IATMin = 0;
int IATMax = 0;
byte IATRaw = 0;
float Volts = 0;
float VoltsMin = 0;
float VoltsMax = 0;
float Lambda = 0;
float LambdaMin = 0;
float LambdaMax = 0;
float LambdaPrev = 0;
boolean LambdaCounter = false; // true = millis set
unsigned long LambdaPrevTime = 0;
float LambdaHeater = 0;
unsigned int RPM = 0;
unsigned int RPMMin = 0;
unsigned int RPMMax = 0;
//byte PROM9_10 = 0;
//byte PROM7_8 = 0;
byte TPS = 0;
byte TPSMin = 0;
byte TPSMax = 0;
byte SparkADV = 0;
//byte Unknown14 = 0;
//byte Unknown15 = 0;
byte BaroRaw = 0;
float Baro = 0;
//byte Unknown17 = 0;
//byte LoopStatus = 0;
byte Exhaust = 0;
float InjPulse = 0;
//byte Unknown20 = 0;
//byte ThrottleSwitch;
byte FuelSync = 0;
//byte Unknown22 = 0;
//byte Unknown23 = 0;
byte STFuel = 0;
//byte Unknown25 = 0;
byte LTFuel = 0;
byte Knock = 0;
byte KnockMin = 0;
byte KnockMax = 0;
//byte Unknown28 = 0;
//byte ACSwitch = 0;
byte ACRequest = 0;
//byte PROM11_12 = 0;
float InjDuty = 0;
float GPH = 0;
float AFR;

//Settings Variables
byte engine = 4;
byte settingsOrder = 1;//1 indexed to allow use of byte
//byte settingsTotal = 5; //Speed, CEL, Splash, Reset, info
//boolean splashScreen = true; //true on, false off
byte updateSpeedMenu = 3; //1 slow, 2 med, 3 fast, 4 ludi
byte updateSpeed = 25;
const byte slow = 100; //Gauge Update Speeds in milliseconds/10 (must be less than 256)
const byte med = 50;
const byte fast = 25;
const byte ludi = 12;
//byte debugStreamOrder = 1;//sets debug stream "page" #
byte cel = 1; //1 CEL Disabled, 2 CEL Faliure, 3 CEL Warning
byte celGauge = 0; //placeholder for gauge # requesting CEL
byte unitOrder = 1;
//byte unitTotal = 4; //Pressure, Temp, TPS, Loop
byte pressureUnit = 2; //1 bar, 2 "Hg, 3 kPa, 4 psi 
boolean tempUnit = true; //false celsius, true farenheit
boolean speedUnit = true; //false kmh, true mph
boolean tpsMode = true; //false advanced, true normal
boolean loopMode = true; //false combo, true normal
byte diagnoseMenu = 1;//1 indexed to allow byte
//byte diagnoseTotal = 10;
byte diagnoseMode = 0; //Switches Screen Info
byte diagnoseMinMax = 0; //0 = off, 1 = on
boolean MinMaxReset = false; //false = off, true = on, initially set to on to record an actual number
byte MinMaxCheck = 0; //0 = not triggered, 1 = counting, 2 = triggered
unsigned long MinMaxCheckTime = 0;
byte advSettingsOrder = 1;

byte dataOrder1 = 6; //Top Left counter, 0 indexed, used byte so that EEPROM can use it
byte dataOrder2 = 5; //Top Right counter, 0 indexed
byte dataOrder3 = 11;//Bottom Left counter, 0 indexed
byte dataOrder4 = 4; //Bottom Right counter, 0 indexed

//byte vehicleYear = 87;
//int customProgramNumber = 177;
//byte programNumberOrder = 2;//starts in 1's place

//Menu Counter used to cycle through menues
byte menuOrder = 1; //Sets to Waiting screen initially
byte vehicleOrder = 1;
byte menuPrev = 255; //prevents multiple display clears
//const byte menuDelay = 40; //delay used on menus to reduce screen flicker, and help buttons register
byte updateScreen = 1;

//Assign variables to menus for easy reference
const byte Home = 0;
const byte Waiting = 1; 
const byte Vehicle = 2;
const byte Gauges = 3;
const byte Diagnose = 4;
const byte Options = 5;
const byte Units = 6;
const byte PickColor = 7;
const byte Backlight = 8;
const byte CustomColor = 9;
const byte RGBCustomSave = 10;
//const byte Debug = 11;
const byte Settings = 12;
//const byte VehicleCustom = 13;
//const byte ProgramNumberMenu = 15;
const byte AutoBrightness = 16;
const byte AutoResyncScreen = 17;
const byte TCUGauges = 18; //screen page variable
const byte TimeMenu = 19;
const byte TCUErrors = 20;
const byte InOutMenu = 21;
const byte advancedMenu = 22;

//TCU stuff
//#include <SoftwareSerial.h>
//SoftwareSerial tcuSerial(TCUpin, A7); //RX, TX

byte serialBeginFlag = 1; //0 = off, 1 = on
unsigned int byteGap = 0;
boolean tcuReadFlag = false; //false = Search, true = Read
unsigned long tcuPrevTime = 0; // tcu time variable for measuring byte length
int tcuCursor = 0; //cursor variable
byte tcuCursorMove = 0; //modifier for scrolling
unsigned long tcuFaultTime;//fault display timer
byte tcuFaultCounter;
bool tcuStreamUpdate;

byte tcuDataStream[7]; //7 bytes,0 indexed, extra spot for stability

int tcuRPM;
float MPH;
byte tcuTPS;
//byte LockUp;
//byte Brake;
byte Solenoids;
byte Mode;
//byte CurrentGear;
//byte PRNDL;
//byte ModuleID;
byte SolenoidFaults;
byte TPSFaults;
float MPG = 0;

boolean transType = 0; //0 = M/T, 1 = A/T, 
byte tcuMenu = 0;
byte TireSize = 29;
float GearRatio = 3.55;
byte GearRatioCounter = 2;
byte SpeedCorr = 100;

float launchTime = 0;
float startTime = 0;
float endTime = 0;
float Best060Time = 99.99;
byte armedFlag = 0;

//callback pointer stuff for displaying each sensor string
typedef void (*GaugeFunction) ();

//V4 Data Array connected to callback pointer
GaugeFunction dataArray[] = {displayOutputs, displayGyro, displayAccel, displayMag, displayTimeBig, displayMAP, displayVacuum, displayCTS, displayIAT, displayRPM, displayVolts, displayLambda, displayExhaust, displayAFR, displayLambdaHeater, displayLoopStatus, displayEGR, displayTPS, displayThrottleSwitch, displaySparkADV, displayKnock, displayInjPulse, displayInjDuty, displayFuelSync, displaySTFuel, displayLTFuel, displayACSwitch, displayACRequest, displayGPH, displayMPH, displayGear, displayTransInfo};//

const byte dataTotal = 32; //number of data points in above array
const byte outputsGauge =   0;
const byte gyroGauge =      1;
const byte accelGauge =     2;
const byte magGauge =       3;
const byte timeGauge =      4;
const byte MAPGauge =       5;
const byte VACGauge =       6;
const byte CTSGauge =       7;
const byte IATGauge =       8;
const byte RPMGauge =       9;
const byte voltGauge =      10;
const byte lambdaGauge =    11;
const byte afrGauge =       12;
const byte exhaustGauge =   13;
const byte heaterGauge =    14;//4.0 only
const byte loopGauge =      15;
const byte egrGauge =       16;
const byte TPSGauge =       17;
const byte throttleGauge =  18;
const byte ADVGauge =       19;
const byte knockGauge =     20;//4.0 only
const byte injGauge =       21;
const byte IDCGauge =       22;
const byte fsyncGauge =     23;//4.0 only
const byte STFGauge =       24;
const byte LTFGauge =       25;
const byte ACSGauge =       26;
const byte ACRGauge =       27;
const byte GPHGauge =       28;
const byte MPHGauge =       29;
const byte gearGauge =      30;
const byte transGauge =     31;
/*
//V3 Data Array connected to callback pointer
GeneralFunction dataArray[] = {displayTime, displayMAP, displayVacuum, displayCTS, displayIAT, displayRPM, displayVolts, displayLambda, displayExhaust, displayLambdaHeater, displayLoopStatus, displayTPS, displayThrottleSwitch, displaySparkADV, displayKnock, displayInjPulse, displayInjDuty, displayFuelSync, displaySTFuel, displayLTFuel, displayACSwitch, displayACRequest, displayGPH, displayMPH, displayGear, displayTransInfo};//, displayCheck};
const byte dataTotal = 26; //number of data points in above array
const byte timeGauge = 0;
const byte MAPGauge = 1;
const byte VACGauge = 2;
const byte CTSGauge = 3;
const byte IATGauge = 4;
const byte RPMGauge = 5;
const byte voltGauge = 6;
const byte lambdaGauge = 7;
const byte exhaustGauge = 8;
const byte heaterGauge = 9;
const byte loopGauge = 10;
const byte TPSGauge = 11;
const byte throttleGauge = 12;
const byte ADVGauge = 13;
const byte knockGauge = 14;
const byte injGauge = 15;
const byte IDCGauge = 16;
const byte fSyncGauge = 17;
const byte STFGauge = 18;
const byte LTFGauge = 19;
const byte ACSGauge = 20;
const byte ACRGauge = 21;
const byte GPHGauge = 22;
const byte MPHGauge = 23;
const byte gearGauge = 24;
const byte transGauge = 25;
*/
//V1/V2 Data Array connected to callback pointer
/*
GeneralFunction dataArray[] = { displayMAP, displayVacuum, displayCTS, displayIAT, displayRPM, displayVolts, displayLambda, displayExhaust, displayLambdaHeater, displayLoopStatus, displayTPS, displayThrottleSwitch, displaySparkADV, displayKnock, displayInjPulse, displayInjDuty, displayFuelSync, displaySTFuel, displayLTFuel, displayACSwitch, displayACRequest, displayGPH, displayMPH, displayGear, displayTransInfo};
const byte dataTotal = 25; //number of data points in above array
const byte MAPGauge = 0;
const byte VACGauge = 1;
const byte CTSGauge = 2;
const byte IATGauge = 3;
const byte RPMGauge = 4;
const byte voltGauge = 5;
const byte lambdaGauge = 6;
const byte exhaustGauge = 7;
const byte heaterGauge = 8;
const byte loopGauge = 9;
const byte TPSGauge = 10;
const byte throttleGauge = 11;
const byte ADVGauge = 12;
const byte knockGauge = 13;
const byte injGauge = 14;
const byte IDCGauge = 15;
const byte fSyncGauge = 16;
const byte STFGauge = 17;
const byte LTFGauge = 18;
const byte ACSGauge = 19;
const byte ACRGauge = 20;
const byte GPHGauge = 21;
const byte MPHGauge = 22;
const byte gearGauge = 23;
const byte transGauge = 24;
*/

//EEPROM Memory Variables for storing information between power cylces (Notice 0 was skipped for continuity)
const byte EEdataOrder1 = 1; //EEPROM Address to store first counter
const byte EEdataOrder2 = 2; //EEPROM Address to store second counter
const byte EEdataOrder3 = 3; //EEPROM Address to store third counter
const byte EEdataOrder4 = 4; //EEPROM Address to store forth counter

//current LED values to be multiplied by dim value
byte redValue = 0; //int to prevent looping
byte greenValue = 128;
byte blueValue = 0;

//diming variable to affect final output of RGB Variables
byte RGBDim = 100; //100 = Max and 0 = Off
byte RGBDimOrder = 4; //1 = Off, 2 = Low, 3 = Med, 4 = High, 5 = Auto
//byte RGBDimTotal = 5; //total number of options
int lightSensor = 0;
byte autoDim = 15; // 0 - 100
byte lowDim = 2; // divided by 4 to conform to byte, orginally 8
byte highDim = 16; // will be multiplied by 4 in code, orginally 64
byte AutoDimOrder = 1; //1 = auto, 2 = low, 3 = high
//byte AutoResync = 2; //1 = On, 2 = Off

//final value that is outputed to the LEDs
byte redDisplay = 0; 
byte greenDisplay = 0;
byte blueDisplay = 0;

//counter variables for RGB Preset Color Selection Screen
byte RGBOrder = 4; //1 = Red, Orange, Yellow, Green, Cyan, Blue, Purple, Pink, White, 10 = Custom
//byte RGBTotal = 10;

//counter variables for RGB Custom Color Selection Screen
byte RGBCustomOrder = 0; //0 = red, 1 = green, 2= blue
//byte RGBCustomTotal = 3;

//stores custom RGB color values
byte redCustom = 0;
byte greenCustom = 0;
byte blueCustom = 0;

//EEPROM Addresses to save options between power cycles
const byte EEreset = 0;        //used to determin EEPROM State for first boot
const byte EERGBOrder = 5;     //preset color setting
const byte EERGBDimOrder = 6;  //dim setting
const byte EEredValue = 7;     //selected color values
const byte EEgreenValue = 8;
const byte EEblueValue = 9;
const byte EEredCustom = 10;   //custom color values
const byte EEgreenCustom = 11;
const byte EEblueCustom = 12;
const byte EERGBDim = 13;      //selected dim value
const byte EEsplashScreen = 14;
const byte EEupdateSpeedMenu = 15; //saves menu screen for continuity
const byte EEupdateSpeed = 16; //saves actual delay value
const byte EEengine = 17; //was previously Program Number
const byte EEtransType = 18; //was previously customProgramNumber = 18;
//const byte EEvehicleYear = 19;
const byte EEModelNumber = 20;
const byte EEcel = 21;
const byte EEpressureUnit = 22;
const byte EEtempUnit = 23;
const byte EEtpsMode = 24;
const byte EEloopMode = 25;
const byte EEautoDim = 26;
const byte EElowDim = 27;
const byte EEhighDim = 28;
const byte EEAutoResync = 29;
const byte EETireSize = 30;
const byte EEGearRatioCounter = 31;
const byte EESpeedCorr = 32;
const byte EEspeedUnit = 33;
const byte EEGearRatio = 34; //This is a float, takes up 4 addresses, don't write to 34-37
const byte EEBest060Time = 38; //float for 0-60, don't write 38-41
const byte EEhourSetting = 42;
const byte EEhomeScreen = 43;
const byte EEbluetooth = 44;
const byte EEgyroscope = 45;
const byte EEfan1Pin = 46;
const byte EEfan2Pin = 47;
const byte EEfan3Pin = 48;
const byte EEfan1Mode = 49;
const byte EEfan2Mode = 50;
const byte EEfan3Mode = 51;
const byte EEtemp1on = 52;
const byte EEtemp1off = 53;
const byte EEtemp2on = 54;
const byte EEtemp2off = 55;
const byte EEtemp3on = 56;
const byte EEtemp3off = 57;
const byte EEac1Trigger = 58;
const byte EEac2Trigger = 59;
const byte EEac3Trigger = 60;
const byte EEclockMode = 61;
const byte EEusbOutput = 62;
const byte EEclockLowDim = 63;
const byte EEclockHighDim = 64;
const byte EEmpgMode = 65;
const byte EErollOffset = 66;
const byte EEpitchOffset = 67;


//Stuff for In/Out Adapter

bool fan1State;
bool fan2State;
bool fan3State;

const byte out = 1;
const byte in = 2;
const byte inPull = 3;

const byte off = 1;
const byte on = 2;
const byte Auto = 3;

byte InOutOrder;
byte ioCursor;

unsigned long loopTime;

unsigned long screenTimer; //used to auto refresh screen
bool updateTimedScreen;

const byte menu = 2; //shortcuts for menu refreshing
const byte buttons = 1;
bool screenBtnFlag;

//oled formatting stuff
const byte W = 64;
//const byte h = 128; 
const byte T1 = 8;
const byte T2 = 16;
byte gaugeCursor;
const byte gaugeSpace = 12; //Text 1 is 8px, + 4 for equal spacing

byte i2cFlag = false;
byte i2cStop;

bool gyroFlag;
unsigned long gyroPrevTime;
bool gyroCaliOrder;


//********************************************************************************************************************************************************************************************************
void setup()
{  
  //Check to see if EEPROM is blank and write useable values 
  if (EEPROM.read(EEreset) == 255){
    EEPROM.update(EEreset, 0);
    EEPROM.update(EEdataOrder1, CTSGauge);
    EEPROM.update(EEdataOrder2, RPMGauge);
    EEPROM.update(EEdataOrder3, TPSGauge);
    EEPROM.update(EEdataOrder4, voltGauge);
    EEPROM.update(EERGBOrder, 4);     //preset color setting
    EEPROM.update(EERGBDimOrder, 4);  //dim setting
    EEPROM.update(EEredValue, 0);     //selected color values
    EEPROM.update(EEgreenValue, 255);
    EEPROM.update(EEblueValue, 0);
    EEPROM.update(EEredCustom, 128);   //custom color values
    EEPROM.update(EEgreenCustom, 128);
    EEPROM.update(EEblueCustom, 128);
    EEPROM.update(EERGBDim, 100);      //selected dim value
    EEPROM.update(EEsplashScreen, true); //on
    EEPROM.update(EEupdateSpeedMenu, 3);
    EEPROM.update(EEupdateSpeed, fast);
    EEPROM.update(EEtransType, false); //Manual
    EEPROM.update(EEengine, 4);
    EEPROM.update(EEcel, 2);
    EEPROM.update(EEpressureUnit, 2);
    EEPROM.update(EEtempUnit, true); //F
    EEPROM.update(EEtpsMode, true); //normal
    EEPROM.update(EEloopMode, true); //normal
    EEPROM.update(EEautoDim, 15);
    EEPROM.update(EElowDim, 2);
    EEPROM.update(EEhighDim, 16);
    //EEPROM.update(EEAutoResync, 2);//V1-V2 option
    EEPROM.update(EETireSize, 29);
    EEPROM.update(EEGearRatioCounter, 2);
    EEPROM.update(EESpeedCorr, 100);
    EEPROM.update(EEspeedUnit, true); //mph
    EEPROM.put(EEGearRatio, GearRatio);//notice .put, second argument is just the data type, variable is set equal to the value we want
    EEPROM.put(EEBest060Time, Best060Time);
    EEPROM.update(EEhourSetting, true);//V3 option
    EEPROM.update(EEhomeScreen, false);//V3 option
    EEPROM.update(EEbluetooth, false);
    EEPROM.update(EEgyroscope, false);
    EEPROM.update(EEfan1Pin, 0);
    EEPROM.update(EEfan2Pin, 0);
    EEPROM.update(EEfan3Pin, 0);
    EEPROM.update(EEfan1Mode, off);
    EEPROM.update(EEfan2Mode, off);
    EEPROM.update(EEfan3Mode, off);
    EEPROM.update(EEtemp1on, 210);
    EEPROM.update(EEtemp1off, 205);
    EEPROM.update(EEtemp2on, 210);
    EEPROM.update(EEtemp2off, 205);
    EEPROM.update(EEtemp3on, 210);
    EEPROM.update(EEtemp3off, 205);
    EEPROM.update(EEac1Trigger, 0);
    EEPROM.update(EEac2Trigger, 0);
    EEPROM.update(EEac3Trigger, 0);
    //EEPROM.update(EEclockMode, 3);
    EEPROM.update(EEusbOutput, 0);
    EEPROM.update(EEclockLowDim, 0);
    EEPROM.update(EEclockHighDim, 15);
    EEPROM.update(EEmpgMode, 1);
    EEPROM.update(EErollOffset, 128);
    EEPROM.update(EEpitchOffset, 128);
  }
  
// Sets the Active Varables equal to the Saved Variables
//olddisplay 
/*
  redValue = EEPROM.read(EEredValue);
  greenValue = EEPROM.read(EEgreenValue);
  blueValue = EEPROM.read(EEblueValue);
  
  RGBDim = EEPROM.read(EERGBDim);
  autoDim = EEPROM.read(EEautoDim);
  lowDim = EEPROM.read(EElowDim);
  highDim = EEPROM.read(EEhighDim);
  
  redCustom = EEPROM.read(EEredCustom);
  greenCustom = EEPROM.read(EEgreenCustom);
  blueCustom = EEPROM.read(EEblueCustom);
  
  RGBOrder = EEPROM.read(EERGBOrder);
  RGBDimOrder = EEPROM.read(EERGBDimOrder);
    
  redDisplay = (redValue * RGBDim / 100);       //adjusts RGB values to selected dim setting
  greenDisplay = (greenValue * RGBDim / 100);
  blueDisplay = (blueValue * RGBDim / 100);
  //AutoResync = EEPROM.read(EEAutoResync);
*/
  
  updateSpeed = EEPROM.read(EEupdateSpeed);

  //customProgramNumber = EEPROM.read(EEcustomProgramNumber);
  //vehicleYear = EEPROM.read(EEvehicleYear);
  cel = EEPROM.read(EEcel);
  pressureUnit = EEPROM.read(EEpressureUnit);
  tempUnit = EEPROM.read(EEtempUnit);
  tpsMode = EEPROM.read(EEtpsMode);
  loopMode = EEPROM.read(EEloopMode);

  engine = EEPROM.read(EEengine);
  transType = EEPROM.read(EEtransType);
  TireSize = EEPROM.read(EETireSize);
  GearRatioCounter = EEPROM.read(EEGearRatioCounter);
  SpeedCorr = EEPROM.read(EESpeedCorr);
  speedUnit = EEPROM.read(EEspeedUnit);
  GearRatio = EEPROM.get(EEGearRatio, GearRatio);//reads in the float

  hourSetting = EEPROM.read(EEhourSetting);//V3 option
  homeScreen = EEPROM.read(EEhomeScreen);//V3 option
/* //olddisplay
  analogWrite(redPin, redDisplay);        //turns on RGB backlight to set amount
  analogWrite(greenPin, greenDisplay);    //PWM is used to control the brightness
  analogWrite(bluePin, blueDisplay);
*/
  pinMode(0, INPUT_PULLUP);  // Pin zero, RX on the UART
  Serial1.begin(62500);      // Begin ECU serial comms at 62500.
  pinMode(TCUpin, INPUT_PULLUP); // Pin A3, software RX pin for TCU, needs external pullup to work long distance
  Serial3.begin(500);      // Begin TCU serial comms at 500.
  celOn();                   // Turns on Check Engine Light

  //prev = 0;                  // Set the PREV to 0
  //Serial.flush();//Flush doesn't work anymore // Dump the incoming buffer because it will probably be full of junk
  //digitalWrite(0, HIGH); // Renix II is open collector serial-out. Saves on external component count. Requires 1 NPN in open emitter to physically NOT the data

  /*display.begin(16,2);                //set up the LCD's number of columns and rows
  display.createChar(1, leftArrow);  //sends custom character to display memory
  display.createChar(2, rightArrow);
  display.createChar(3, fahrenheitSymbol);
  display.createChar(4, celsiusSymbol);*/ //olddisplay

  display.begin();//oled

  /*for (uint8_t c=0; c<127; c++) {
    display.command(SSD1325_SETCONTRAST); // set contrast current
    display.command(c);  // max!
    Serial.println(c, DEC);
    delay(100);
  }*/
  display.command(SSD1325_SETCONTRAST); // set contrast current
  display.command(255);//max brightness?
  display.setRotation(1);//rotate 90 degrees CW

  display.clearDisplay();//clears the OLED splash screen
  display.setTextColor(WHITE);
  
  if (EEPROM.read(EEsplashScreen) == true)
    {
    display.setTextSize(1);
    t1Cursor(10,2);//fancy cursor function to center font. # of symbols, text row
    display.print(F("Renduinix+"));          //display Splash Screen Text
    t1Cursor(6,3);
    display.print("v");
    display.print(softwareVersion,3);
    t1Cursor(10,7);
    display.print(F("NickInTime"));
    t1Cursor(6,8);
    display.print(F("Design"));
    t1Cursor(4,10);
    display.print(F("2017"));
    display.display();
    delay(3000);                          //wait
    }
  celOff();
  display.setTextSize(2);
  //display.clearDisplay();//olddisplay

//start i2c comms
rtc.begin();//V3 option
  if (! rtc.begin())
    while (1);//make sure library has been started?  
  if (rtc.lostPower()) 
    // following line sets the RTC to the date & time this sketch was compiled
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    
  if (EEPROM.read(EEgyroscope) == true){//Initialise gyro sensors
    gyro.begin();
    accelmag.begin(ACCEL_RANGE_4G);
  // Filter expects 70 samples per second
  // Based on a Bluefruit M0 Feather ... rate should be adjuted for other MCUs
    filter.begin(1);
  }

  //auto i2c Reset if RTC gets stuck with data line low
  if (digitalRead(A4) == LOW && digitalRead(A5) == HIGH){
    i2cFlag = true;

    pinMode(A5, OUTPUT); //take manual control of line
    for (byte i2cCounter; i2cCounter < 9; i2cCounter++){ //pulse 9 times
    //while (digitalRead(A4) == LOW){//stop when line is free, which could be NEVER
      digitalWrite(A5, LOW); //manually pulse line high and low for normal length
      delayMicroseconds(5);
      digitalWrite(A5, HIGH);
      delayMicroseconds(5);
    }

    Wire.begin(); //restart i2c to give control back
  }

  if (EEPROM.read(EEbluetooth) == true)
    Serial2.begin(115200);
    
  Serial.begin(115200); //moved to the bottom because it increases boot time

//sets menu to gauge screen if data is available
  if (Serial1.available() > 0)
    menuOrder = Gauges;
  else menuOrder = Home;

  //pinMode(3, OUTPUT);//useful debug for checking loop time with an osciliscope
}
void loop()
{
  //Serial.println(analogRead(buttonsPin));
  /*currentTime = micros();
  loopTime = currentTime - loopTime;
  Serial.println(loopTime);
  loopTime = currentTime;*/
  //digitalWrite(3, !digitalRead(3));//useful debug for checking loop time with an osciliscope

  //auto i2c Reset if RTC gets stuck with data line low
  if (digitalRead(A4) == LOW && digitalRead(A5) == HIGH && i2cStop < 10){
    ++i2cStop;
    i2cFlag = true;

    pinMode(A5, OUTPUT); //take manual control of line
    for (byte i2cCounter; i2cCounter < 9; i2cCounter++){ //pulse 9 times
    //while (digitalRead(A4) == LOW){//stop when line is free
      digitalWrite(A5, LOW); //manually pulse line high and low for normal length
      delayMicroseconds(5);
      digitalWrite(A5, HIGH);
      delayMicroseconds(5);
    }

    Wire.begin(); //restart i2c to give control back
  }

  updateIO(); //updates free In/Out pins
    
  lightSensor = analogRead(lightSensorPin);
  if (RGBDimOrder == 5){
    if (RGBDim <= autoDim && lightSensor > highDim * 4){//increase if 
      RGBDim = 100;
      celDim = 50;
    }
    if ((RGBDim >= autoDim && lightSensor < lowDim * 4) || RGBDim == 0){//decrease if and dim menu fix
      RGBDim = autoDim;
      celDim = 20;
    }
  }
  //redDisplay = (redValue * RGBDim / 100);     //adjusts RGB values to selected dim setting
  //greenDisplay = (greenValue * RGBDim / 100);
  //blueDisplay = (blueValue * RGBDim / 100);
  
  //analogWrite(redPin, redDisplay);        //adjusts RGB backlight to set amount
  //analogWrite(greenPin, greenDisplay);    //PWM is used to control the brightness
  //analogWrite(bluePin, blueDisplay); //oldlcd
  
  lcdKey = readLcdButtons();      //reads variable input
  if (lcdKey == btnHOME && btnPrev != lcdKey)        //checks if Select button press is true & debounce button presses
  {
    if (menuOrder == CustomColor)   //saves color and resets screen color
      menuOrder = RGBCustomSave;
    else{
      menuOrder = Home;             //sets order back to home screen  
      celOff();                     //turns off cel
      //display.noCursor();//removes underline cursor
    }
    btnPrev = lcdKey;
  }

//Update Speed option time based screen refresh
  currentTime = millis();
  if (currentTime > screenTimer + updateSpeed*10){
    screenTimer = currentTime;
    updateTimedScreen = true;
  }
  else updateTimedScreen = false;

//menu and button change based screen refresh    
  if (menuPrev != menuOrder){ //used to refresh screen only during menu change
    menuPrev = menuOrder;
    updateScreen = menu;
  }
  
  else if (lcdKey != btnNONE && screenBtnFlag == false){//button based screen refresh, this will cause screen to flicker if held continously, menudelay prevents that
    updateScreen = buttons;
    screenBtnFlag = true;//used to prevent flip-flop update loop 
  }
    
  else updateScreen = 0;

  if (lcdKey == btnNONE && screenBtnFlag == true)
    screenBtnFlag = false;

  if (lcdKey == btnNONE)//resets button variable if nothing is pressed
    btnPrev = lcdKey; //used to debounce button press
  
  getData();// this get's all our data, check tab

//update gyro
/*
  if (gyroFlag == true && millis() >= gyroPrevTime + 10){
    gyroPrevTime = millis(); 
    updateGyroMagFilter();
    
  float roll = filter.getRoll();
  float pitch = filter.getPitch();
  float heading = filter.getYaw();
  Serial.print(heading, 1);
  Serial.print(" ");
  Serial.print(pitch, 1);
  Serial.print(" ");
  Serial.print(roll, 1);

  sensors_event_t aevent;
  accelmag.getEvent(&aevent);

  Serial.print(" ");
  Serial.print((aevent.acceleration.y * 9)*-1);
  Serial.print(" ");
  Serial.print((aevent.acceleration.x * 9)*-1);
  Serial.print(" ");
  Serial.println((aevent.acceleration.z * 9)*-1);
   }

  gyroFlag = false; //Reset update flag
*/
//V1/V2 AutoResync routine
  /*currentTime = millis();//update variable to current runtime
  if (currentTime > resyncPrevTime + 1000 && AutoResync == 1){ //checks for proper delay and setting  
    resyncPrevTime = currentTime;
    display.begin(16,2);  //used to resync the screen if it bugs out
    display.createChar(1, leftArrow);  //sends custom character to display memory
    display.createChar(2, rightArrow);
    display.createChar(3, fahrenheitSymbol);
    display.createChar(4, celsiusSymbol);
    updateScreen = 1;
    }*/
    //________
    //1O 2f 3f
//Main Switch Case to control displayed Menu
switch (menuOrder)
 {
    case InOutMenu://Extra In Out Pins for REM***************************************************************************        
      switch (InOutOrder){
        case 0://main menu*****************************************
          if (updateTimedScreen == true || updateScreen > 0){ 
            display.clearDisplay();
            manuCursor(1,0);
            display.print("Fan 1");
            t1Cursor(6,2);
            if (fan1State == HIGH)
              display.print(" On");
            else display.print("OFF");
            
            manuCursor(1,5);
            display.print("Fan 2");
            t1Cursor(6,7);
            if (fan2State == HIGH)
              display.print(" On");
            else display.print("OFF");
            
            manuCursor(1,10);
            display.print("Fan 3");
            t1Cursor(6,12);
            if (fan3State == HIGH)
              display.print(" On");
            else display.print("OFF");
            
            display.display();
          }
          
            //lcdKey = readLcdButtons();
            switch(lcdKey)
            {
              case btnTOPLEFT:        
                if (btnPrev != lcdKey){
                  InOutOrder = 1;
                  btnPrev = lcdKey;
                }
              break;
              case btnBOTTOMLEFT:                 //Same as above for Botttom Left
                if (btnPrev != lcdKey){
                  InOutOrder = 2;
                  btnPrev = lcdKey;
                }
              break;
              case btnBOTTOMRIGHT:                //Same as above for Bottom Right
                if (btnPrev != lcdKey){
                  InOutOrder = 3;
                  btnPrev = lcdKey;
                }
              break;
              case btnTOPRIGHT:                   //Same as above for Top Right
                if (btnPrev != lcdKey){
                  
                  btnPrev = lcdKey;
                }
              break;
            }//displaykey end
        break;
        case 1://Pin 1 main menu*****************************************
          if (updateTimedScreen == true || updateScreen > 0){ //menu or button update              
              display.clearDisplay();
              
              manuCursor(1,0);
              display.print("Fan 1");
              
              t1Cursor(6,2);
              if (fan1State == HIGH)
                display.print("ON");
              else display.print("OFF");

              manuCursor(1,5);
              if (EEPROM.read(EEfan1Mode) == on)
                display.print(">ON");
              else if (EEPROM.read(EEfan1Mode) == off)
                display.print(">OFF");
              else display.print("OnOff");
            
              manuCursor(1,9);
              if (EEPROM.read(EEfan1Mode) == Auto)
                display.print(">AUTO");
              else
                display.print("Auto");

              manuCursor(1,13);
              display.print("Edit");
              
              
                
              display.display();
            }

          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                InOutOrder = 0;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan1Mode) == on)
                  EEPROM.update(EEfan1Mode, off);
                else EEPROM.update(EEfan1Mode, on);
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                EEPROM.update(EEfan1Mode, Auto);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                InOutOrder = 11;
                btnPrev = lcdKey;
              }
            break;
          }//displaykey end
        break;
        case 11://Pin 1 Auto Edit Menu*****************************************
          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  InOutOrder = 1;
                else --ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (ioCursor < 2)
                  ++ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp1on, EEPROM.read(EEtemp1on) - 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp1off, EEPROM.read(EEtemp1off) - 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac1Trigger, false);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp1on, EEPROM.read(EEtemp1on) + 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp1off, EEPROM.read(EEtemp1off) + 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac1Trigger, true);
                btnPrev = lcdKey;
              }
            break;
          }//lcdkey end

          
          if (updateTimedScreen == true || updateScreen > 0){
            
            display.clearDisplay();
            
            manuCursor(1,0);
            display.print("E1");
            if (fan1State == HIGH)
              display.print(" ON");
            else
              display.print("OFF");

            gaugeCursor = 16;
            manuCursor(1,3);
            displayCTS();
            
            manuCursor(2,6);
            display.print(EEPROM.read(EEtemp1on));
            display.print("F");
            
            manuCursor(2,9);
            display.print(EEPROM.read(EEtemp1off));
            display.print("F");
            
            manuCursor(2,12);
            display.print("AC:");
            if (EEPROM.read(EEac1Trigger) == true)
              display.print("Y");
            else
              display.print("N");

            switch(ioCursor)
            {
              case 0:
                manuCursor(1,6);
              break;
              case 1:
                manuCursor(1,9);
              break;
              case 2:
                manuCursor(1,12);
              break;
            }
            display.print(">");

            manuCursor(1,14);
            display.print("^v -+");

            display.display();
          }  
        break;
        case 2://Pin 2 main menu*****************************************
          if (updateTimedScreen == true || updateScreen > 0){ //menu or button update              
              display.clearDisplay();
              
              manuCursor(1,0);
              display.print("Fan 2");
              
              t1Cursor(6,2);
              if (fan2State == HIGH)
                display.print("ON");
              else display.print("OFF");

              manuCursor(1,5);
              if (EEPROM.read(EEfan2Mode) == on)
                display.print(">ON");
              else if (EEPROM.read(EEfan2Mode) == off)
                display.print(">OFF");
              else display.print("OnOff");
            
              manuCursor(1,9);
              if (EEPROM.read(EEfan2Mode) == Auto)
                display.print(">AUTO");
              else
                display.print("Auto");

              manuCursor(1,13);
              display.print("Edit");
              
              
                
              display.display();
            }

          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                InOutOrder = 0;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan2Mode) == on)
                  EEPROM.update(EEfan2Mode, off);
                else EEPROM.update(EEfan2Mode, on);
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                EEPROM.update(EEfan2Mode, Auto);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                InOutOrder = 22;
                btnPrev = lcdKey;
              }
            break;
          }//displaykey end
        break;
        case 22://Pin 2 Auto Edit Menu*****************************************
          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  InOutOrder = 2;
                else --ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (ioCursor < 2)
                  ++ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp2on, EEPROM.read(EEtemp2on) - 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp2off, EEPROM.read(EEtemp2off) - 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac2Trigger, false);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp2on, EEPROM.read(EEtemp2on) + 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp2off, EEPROM.read(EEtemp2off) + 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac2Trigger, true);
                btnPrev = lcdKey;
              }
            break;
          }//lcdkey end

          
          if (updateTimedScreen == true || updateScreen > 0){
            
            display.clearDisplay();
            
            manuCursor(1,0);
            display.print("E2");
            if (fan2State == HIGH)
              display.print(" ON");
            else
              display.print("OFF");

            gaugeCursor = 16;
            manuCursor(1,3);
            displayCTS();
            
            manuCursor(2,6);
            display.print(EEPROM.read(EEtemp2on));
            display.print("F");
            
            manuCursor(2,9);
            display.print(EEPROM.read(EEtemp2off));
            display.print("F");
            
            manuCursor(2,12);
            display.print("AC:");
            if (EEPROM.read(EEac2Trigger) == true)
              display.print("Y");
            else
              display.print("N");

            switch(ioCursor)
            {
              case 0:
                manuCursor(1,6);
              break;
              case 1:
                manuCursor(1,9);
              break;
              case 2:
                manuCursor(1,12);
              break;
            }
            display.print(">");

            manuCursor(1,14);
            display.print("^v -+");

            display.display();
          }  
        break;
        case 3://Pin 3 main menu*****************************************
          if (updateTimedScreen == true || updateScreen > 0){ //menu or button update              
              display.clearDisplay();
              
              manuCursor(1,0);
              display.print("Fan 3");
              
              t1Cursor(6,2);
              if (fan3State == HIGH)
                display.print("ON");
              else display.print("OFF");

              manuCursor(1,5);
              if (EEPROM.read(EEfan3Mode) == on)
                display.print(">ON");
              else if (EEPROM.read(EEfan3Mode) == off)
                display.print(">OFF");
              else display.print("OnOff");
            
              manuCursor(1,9);
              if (EEPROM.read(EEfan3Mode) == Auto)
                display.print(">AUTO");
              else
                display.print("Auto");

              manuCursor(1,13);
              display.print("Edit");
              
              
                
              display.display();
            }

          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                InOutOrder = 0;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan3Mode) == on)
                  EEPROM.update(EEfan3Mode, off);
                else EEPROM.update(EEfan3Mode, on);
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                EEPROM.update(EEfan3Mode, Auto);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                InOutOrder = 33;
                btnPrev = lcdKey;
              }
            break;
          }//displaykey end
        break;
        case 33://Pin 3 Auto Edit Menu*****************************************
          switch(lcdKey)
          {
            case btnTOPLEFT:        
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  InOutOrder = 3;
                else --ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMLEFT:                 //Same as above for Botttom Left
              if (btnPrev != lcdKey){
                if (ioCursor < 2)
                  ++ioCursor;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:                //Same as above for Bottom Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp3on, EEPROM.read(EEtemp3on) - 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp3off, EEPROM.read(EEtemp3off) - 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac3Trigger, false);
                btnPrev = lcdKey;
              }
            break;
            case btnTOPRIGHT:                   //Same as above for Top Right
              if (btnPrev != lcdKey){
                if (ioCursor == 0)
                  EEPROM.update(EEtemp3on, EEPROM.read(EEtemp3on) + 1);
                else if (ioCursor == 1)
                  EEPROM.update(EEtemp3off, EEPROM.read(EEtemp3off) + 1);
                else if (ioCursor == 2)
                  EEPROM.update(EEac3Trigger, true);
                btnPrev = lcdKey;
              }
            break;
          }//lcdkey end

          
          if (updateTimedScreen == true || updateScreen > 0){
            
            display.clearDisplay();
            
            manuCursor(1,0);
            display.print("E3");
            if (fan3State == HIGH)
              display.print(" ON");
            else
              display.print("OFF");

            gaugeCursor = 16;
            manuCursor(1,3);
            displayCTS();
            
            manuCursor(2,6);
            display.print(EEPROM.read(EEtemp3on));
            display.print("F");
            
            manuCursor(2,9);
            display.print(EEPROM.read(EEtemp3off));
            display.print("F");
            
            manuCursor(2,12);
            display.print("AC:");
            if (EEPROM.read(EEac3Trigger) == true)
              display.print("Y");
            else
              display.print("N");

            switch(ioCursor)
            {
              case 0:
                manuCursor(1,6);
              break;
              case 1:
                manuCursor(1,9);
              break;
              case 2:
                manuCursor(1,12);
              break;
            }
            display.print(">");

            manuCursor(1,14);
            display.print("^v -+");

            display.display();
          }  
        break;
      }//InOutOrder end
    break;
    case TCUGauges://TCU Gauge Screen**************************************************************************************
      if (transType == false)
        menuOrder = Vehicle;//just used for gauge length at this point
        
      if (tcuMenu == 0 && (tcuStreamUpdate == true || updateScreen > 0 || updateTimedScreen == true)){ //checks screen update flag
      tcuStreamUpdate = false;//reset flag
    /*_____
      RPM
      11952
      MPH
        123
      7 TPS
      1 1-2
      B12LC
      0/0*/
      gaugeCursor = 0;
      display.clearDisplay();                    
      display.setCursor(0,0);
      display.setTextSize(1);
      display.print(F("TCU RPM"));
      gaugeCursor += 8;
      
      display.setCursor(12, gaugeCursor);
      display.setTextSize(2);
      if(tcuRPM < 10)
        display.print(" ");
      if(tcuRPM < 100)
        display.print(" ");
      if(tcuRPM < 1000)
        display.print(" ");
      display.print(tcuRPM);
      gaugeCursor += 16;
      
      display.setCursor(0, gaugeCursor);
      display.setTextSize(1);
      if (speedUnit == false)
        display.print("KPH");
      else
        display.print("MPH");
      gaugeCursor += 8;
      
      display.setCursor(24, gaugeCursor);
      display.setTextSize(2);
      if(MPH < 10)
        display.print(" ");
      if(MPH < 99.5)
        display.print(" ");
      display.print(MPH,0);
      gaugeCursor += 20;
      
      display.setCursor(0, gaugeCursor);
      display.print(tcuTPS);
      display.setCursor(24, gaugeCursor);
      display.print("TPS");
      gaugeCursor += 20;
      
      display.setCursor(0, gaugeCursor);
      //previously PRNDL
      if ((Mode / 16) % 4 == 1)//Remainder of 1
        display.print("1-2");
      else if ((Mode / 16) % 4 == 2)
        display.print("3rd");
      else if ((Mode / 16) % 4 == 3)
        display.print("RND");
      else 
        display.print("???");
        
      if ((Solenoids / 32) == 6)//Current Gear 
        display.print(" 1");
      else if ((Solenoids / 32) % 4 == 0)
        display.print(" 2");
      else if ((Solenoids / 32) % 4 == 1)
        display.print(" 3");
      else if ((Solenoids / 32) % 4 == 3)
        display.print(" 4");
      else
        display.print(" ?");
      gaugeCursor += 20;
      
      display.setCursor(0, gaugeCursor);      
      if (Mode % 2) //odd, Brake
        display.print(" ");
      else //even
        display.print("B");
    
      if ((Solenoids / 32) % 2) //odd
        display.print(" ");
      else //even
        display.print("1");
    
      if ((Solenoids / 64) % 2) //odd
        display.print(" ");
      else //even
        display.print("2");
    
      if (Solenoids < 128)
        display.print("L");
      else 
        display.print(" ");
        
      if ((Mode / 64) % 2 && Mode < 128) //odd
        display.print("P");
      else //even
        display.print("C");
      gaugeCursor += 20;
      
      display.setCursor(0, gaugeCursor);
      display.print(SolenoidFaults);
      display.print("/");
      display.print(TPSFaults);
      /*if (SolenoidFaults == 0 && TPSFaults == 0){
        display.print("0/0");
        tcuFaultCounter = 0;
      }
      else{
        currentTime = millis();
        if (currentTime > tcuFaultTime + 2000){
          ++tcuFaultCounter;
          tcuFaultTime = currentTime ;
        }
        if (tcuFaultCounter > 3)
          tcuFaultCounter = 1;
          
        switch (tcuFaultCounter){
          case 1:
            if(SolenoidFaults < 10)
              display.print(" ");
            if(SolenoidFaults < 100)
              display.print(" ");
            display.print(SolenoidFaults);
          break;
          case 2:
            display.print(F(" / "));
          break;
          case 3:
            if(TPSFaults < 10)
              display.print(" ");
            if(TPSFaults < 100)
              display.print(" ");
            display.print(TPSFaults);
          break;  
        }
      }//solenoid fault else end*/
      display.display();
    }//main display end
    
    //lcdKey = readLcdButtons();  // read the buttons
    if (lcdKey == btnTOPLEFT){
      tcuMenu = 0;
      btnPrev = lcdKey;
    }
    else if (lcdKey == btnTOPRIGHT || lcdKey == btnBOTTOMLEFT){
      if (btnPrev != lcdKey  && tcuMenu == 0){
        tcuMenu = 1;
        btnPrev = lcdKey; //prevents accidental trigger on lower switch case
        }
    }
    else if (lcdKey == btnBOTTOMRIGHT){
      if (btnPrev != lcdKey  && tcuMenu == 0){
        menuOrder = TCUErrors;
        btnPrev = lcdKey;
      }
    }
    
    if (tcuMenu != 0){ //0-60 timer              
        if (armedFlag == 0)
          Best060Time = EEPROM.get(EEBest060Time, Best060Time);
        
        if (tcuRPM < 681 && (MPH > 0 || tcuTPS > 1) && armedFlag == 2){//Armed initial trigger
          startTime = millis();
          armedFlag = 3;
        }
        if (armedFlag == 3){//Armed timer
          endTime = millis();
          launchTime = (endTime - startTime) / 1000;//Fun Fact, Software Serial Data reading interupts millis updating, so a correction factor was previously needed.
          if ((MPH >= 60 && speedUnit == true) || (MPH >= 100 && speedUnit == false)){//timer finish
            armedFlag = 1;
            if (launchTime < Best060Time){//Best Time Recording
              Best060Time = launchTime;
              EEPROM.put(EEBest060Time, launchTime);
              armedFlag = 4;
            }//end best time if
          }//end 60 if
          if (MPH == 0){
            armedFlag = 2;//set back to waiting mode if vehicle stops again
            startTime = endTime;//resets counter
          }//end 0 mph if
        }//end timer if 

      if (tcuStreamUpdate == true || updateScreen > 0 || updateTimedScreen == true){ //if statement may help grab tcu data more reliably
        tcuStreamUpdate = false;//reset flag

        //0-60
        //Timer
        
        //ARMED
        //00.00
        
        display.clearDisplay();

        if (armedFlag == 4){
          t2Cursor(3,0);
          display.print(F("NEW")); 
          t2Cursor(4,1);
          display.print(F("BEST")); 
          t2Cursor(5,2);
          display.print(F("TIME!"));
        }
        else{
          if (speedUnit == false){
            t2Cursor(5,0);
            display.print(F("0-100"));
            t2Cursor(5,1);
            display.print(F("Timer"));
          }
          else{
            t2Cursor(4,0);  
            display.print(F("0-60"));
            t2Cursor(5,1); 
            display.print(F("Timer"));
          }

          t1Cursor(10,12);
        if (armedFlag > 1)
            display.print(F("ARMED"));
          else if (armedFlag == 0)
            display.print(F("Best "));
          else display.print(F("idle "));
        }
        

        t1Cursor(10,6);  
        display.setTextSize(1);
         if (speedUnit == false)
          display.print("KPH ");
        else
          display.print("MPH ");
        
        t1Cursor(10,7);
        display.setTextSize(2);
        if(MPH < 99.5)
          display.print(" ");
        if(MPH < 10)
          display.print(" ");
        display.print(MPH,1);


        t1Cursor(10,9);
        display.setTextSize(1);
        display.print("MM:SS");
        
        t1Cursor(10,10);
        display.setTextSize(2);
        if (armedFlag == 0){
          if (Best060Time < 10)
            display.print(" ");
          display.print(Best060Time, 2);
        }
        if (armedFlag != 0){
          if (launchTime < 10)
            display.print(" ");
          display.print(launchTime, 2);
        }

        display.setCursor(0,112);
        display.print("<");
        
        if (armedFlag == 0){
          display.setCursor(16,112);
          display.print("r");
        }
        display.setCursor(51,112);
        display.print("^");
        display.display();
        }//end screen update

        
      
       
      //lcdKey = readLcdButtons();  // read the buttons
      if (lcdKey == btnTOPRIGHT || lcdKey == btnBOTTOMRIGHT){
        if (btnPrev != lcdKey){
          ++armedFlag;
          btnPrev = lcdKey;
        }
        if (armedFlag > 2)
          armedFlag = 0;
      }
      else if(lcdKey == btnBOTTOMLEFT){
        if (btnPrev != lcdKey && armedFlag == 0){//reset only if on best screen
          EEPROM.put(EEBest060Time, 99.99);
          btnPrev = lcdKey;
        }
      }
    }//if 0-60 menu
  break;
  case TCUErrors://TCU Error Code Screen *********************************************************************************      
    if (tcuStreamUpdate == true || updateScreen > 0 || updateTimedScreen == true){//if statment helps tcu read in reliably
      tcuStreamUpdate = false;

      display.clearDisplay();
      
      t1Cursor(6,0);
      display.print("TCU");
      
      t1Cursor(10,2);
      display.print("Codes");
      
      t1Cursor(10,5);
      display.print("S1");

      if ((SolenoidFaults / 32) % 2){ //odd, S1 C
        manuCursor(4,5);
        display.print("C");
      }
      if ((SolenoidFaults / 2) % 2){ //odd, S1 S
        manuCursor(5,5);
        display.print("S");
      }
      
      t1Cursor(10,8);
      display.print("S2");

      if ((SolenoidFaults / 64) % 2){ //odd, S2 C
        manuCursor(4,8);
        display.print("C");
      }

      if ((SolenoidFaults / 4) % 2){ //odd, S2 S
        manuCursor(5,8);
        display.print("S");
      }
      
      t1Cursor(10,11);
      display.print("S3");

      if (SolenoidFaults > 127){ //odd, S3 C
        manuCursor(4,11);
        display.print("C");
      }

      if ((SolenoidFaults / 8) % 2){ //odd, S3 S
        manuCursor(5,11);
        display.print("S");
      }
      
      t1Cursor(10,14);
      display.print("TPS");

      if (TPSFaults > 0){
        manuCursor(5,14);
        display.print("C");
      }
          
      display.display();
    }
  
    
    //lcdKey = readLcdButtons();  // read the buttons
    if (lcdKey == btnTOPLEFT){
      menuOrder = TCUGauges;
      btnPrev = lcdKey;
    }/*
    if (lcdKey == btnTOPRIGHT){
      if (btnPrev != lcdKey){
        --tcuCursorMove;
        btnPrev = lcdKey;
      }
    }
    if (lcdKey == btnBOTTOMRIGHT &&  tcuCursor > 1){
      if (btnPrev != lcdKey){
        ++tcuCursorMove;
        btnPrev = lcdKey;
      }
    }*/
  break;
  case Gauges://Gauge Screen *********************************************************************************************  
    
    dataOrder1 = EEPROM.read(EEdataOrder1);  //sets the counter variable equal to the saved EEPROM value
    dataOrder2 = EEPROM.read(EEdataOrder2);
    dataOrder3 = EEPROM.read(EEdataOrder3);
    dataOrder4 = EEPROM.read(EEdataOrder4);

    //lcdKey = readLcdButtons();//*******reads variable input********
    switch(lcdKey)
    {
      case btnTOPLEFT:        
        if (btnPrev != lcdKey){
          ++dataOrder1; //increases order by 1 if above is true
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT:                   //Same as above for Top Right
        if (btnPrev != lcdKey){
          ++dataOrder2;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMRIGHT:                 //Same as above for Botttom Left
        if (btnPrev != lcdKey){
          ++dataOrder3;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT:                //Same as above for Bottom Right
        if (btnPrev != lcdKey){
          ++dataOrder4;
          btnPrev = lcdKey;
        }
      break;
    }
// Fancy Function to auto skip gauges and save some copy pasting! *Edit in Gauges Tab*
    if (gaugeSkip(dataOrder1) != 255){
      if (gaugeSkip(dataOrder1) == 128)
        ++dataOrder1;
      else dataOrder1 = gaugeSkip(dataOrder1);
    }
    if (gaugeSkip(dataOrder2) != 255){
      if (gaugeSkip(dataOrder2) == 128)
        ++dataOrder2;
      else dataOrder2 = gaugeSkip(dataOrder2);
    }
    if (gaugeSkip(dataOrder3) != 255){
      if (gaugeSkip(dataOrder3) == 128)
        ++dataOrder3;
      else dataOrder3 = gaugeSkip(dataOrder3);
    }
    if (gaugeSkip(dataOrder4) != 255){
      if (gaugeSkip(dataOrder4) == 128)
        ++dataOrder4;
      else dataOrder4 = gaugeSkip(dataOrder4);
    }

  //if (updateScreen > 0)
    
  if (updateTimedScreen == true || updateScreen > 0){ //adds delay while still allowing buttons to registure  
    display.clearDisplay();
    display.setCursor(0, 0);              //set top left
    dataArray [dataOrder1] ();        //prints selected data from the Array
    gaugeCursor += 22;
    display.setCursor(0, gaugeCursor);
    dataArray [dataOrder2] ();        //Note display print commands are already in the void code
    gaugeCursor += 22;
    display.setCursor(0, gaugeCursor);
    dataArray [dataOrder3] ();
    gaugeCursor += 22;
    display.setCursor(0, gaugeCursor);
    dataArray [dataOrder4] ();
    display.display();
    updateCEL();//Check Engine Light stuff, check tab
    gaugeCursor = 0;
  }
      
    EEPROM.update(EEdataOrder1, dataOrder1); //Updates EEPROM value to counter value if it has changed
    EEPROM.update(EEdataOrder2, dataOrder2); //EEPROM has limited lifecycle so (update) is more efficent then (write)
    EEPROM.update(EEdataOrder3, dataOrder3);
    EEPROM.update(EEdataOrder4, dataOrder4);
    
  break;
  case Diagnose://Diagnoses Screen***************************************************************************************    
    //lcdKey = readLcdButtons();
    switch(lcdKey)
    {
      case btnTOPLEFT://info button
        if (btnPrev != lcdKey){
          if (diagnoseMinMax == 1)
            diagnoseMinMax = 2;
          else
            ++diagnoseMode;
          btnPrev = lcdKey; 
        }
        if (diagnoseMode > 3)
          diagnoseMode = 0;
      break;
      case btnBOTTOMLEFT://scroll up
        if (btnPrev != lcdKey){
          --diagnoseMenu;
          btnPrev = lcdKey;
        }
        if (diagnoseMenu < 1)
          diagnoseMenu = 11;
        if (diagnoseMenu == 8 && engine ==2)
          diagnoseMenu = 7;
      break;
      case btnTOPRIGHT://min/max button
        if (btnPrev != lcdKey){
          ++diagnoseMinMax;
          btnPrev = lcdKey;
        }
        if (diagnoseMinMax > 1)
          diagnoseMinMax = 0;
      break;
      case btnBOTTOMRIGHT://scroll down
        if (btnPrev != lcdKey){
          ++diagnoseMenu;
          btnPrev = lcdKey;
        }
        if (diagnoseMenu > 11)
          diagnoseMenu = 1;
        if (diagnoseMenu == 8 && engine ==2)
          diagnoseMenu = 9;
      break;
    }

    if (updateTimedScreen == true || updateScreen > 0){
        gaugeCursor = 16;       
        display.clearDisplay();

        display.setCursor(0,0);
        if (diagnoseMinMax == 1)
          display.print("r");
        else
          display.print("i");
        if (diagnoseMode == 0){//Normal Overlay
          display.setCursor(48,0);
          display.print("m");
          display.setCursor(0,112);
          display.print("^");
          display.setCursor(48,112);
          display.print("v");
        }
        display.setCursor(0,16);
        
      celOff();
    switch (diagnoseMenu){
      case 1://MAP**************************************************
        if (RPM > 500 && RPM < 5200 && MAPRaw >= BaroRaw)
            celOn();
        switch (diagnoseMode){//selects which main screen text to display
          case 0://Readout

          gaugeCursor = 12;
          displayMAP();
          
          display.setCursor(0,44);
          display.print(((MAPRaw / 5.1)/10), 2);//MAPRaw/51 but byte variable can't do that correctly
          display.print("v");
                    
          if (diagnoseMinMax == 0){
          display.setCursor(0,62);
          gaugeCursor += 36;
          displayVacuum();
          
          display.setCursor(0,88);
          gaugeCursor += 14;
          displayBaro();
          }
          
            /*display.setCursor(5,0);
            displayMAP();
            display.setCursor(2,0);
            display.print(F("MAP"));
            display.setCursor(10,0);
            switch(pressureUnit)
            {
              case 1://Bars Calc
                display.print(F("Volts"));
                display.setCursor(2,1);
                display.print(F("Idle:1.0-4.0"));
              break;
              case 2://inHg
                display.print(F("\"Hg"));// the forwardslash allows the " to be printed without interpeting it as code
                display.setCursor(2,1);
                display.print(F("Idle: 10-25"));
              break;
              case 3://KPA
                display.print(F("kPa"));
                display.setCursor(2,1);
                display.print(F("Idle: 34-85"));
              break;
              case 4://PSI
                display.print(F("psi"));
                display.setCursor(2,1);
                display.print(F("Idle: 5-12"));
              break;
              }*/
          if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
            if (diagnoseMinMax == 2){//resets min an max values
              MAPMin = MAP;
              MAPMax = MAP;
              diagnoseMinMax = 1;
            }
            t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(10,9);
            display.setTextSize(2);
            if (MAPMin < 10)
              display.print(" ");
            if (MAPMin < 100)
              display.print(" ");
            display.print(MAPMin,1);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(10,12);
            display.setTextSize(2);
            if (MAPMax < 10)
              display.print(" ");
            if (MAPMax < 100)
              display.print(" ");           
            display.print(MAPMax,1);
          }
          break;
          case 1://Description
            display.setCursor(2,16);
            display.print(F("Manif old"));
            display.setCursor(2,56); 
            display.print(F("Absol ute"));
            display.setCursor(2,96); 
            display.print(F("Press ure"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Centr")); 
            t1Cursor(4,6);
            display.print(F("of"));
            t1Cursor(8,9);
            display.print(F("Fire"));
            t1Cursor(8,12);
            display.print(F("wall"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("A:GND");
            t1Cursor(10,6);
            display.print("B:Out");
            t1Cursor(10,9);
            display.print("C:5V");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 2://CTS**************************************************
        if (CTS < -38 || CTS > 240)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            gaugeCursor = 0;
            //display.setCursor(0,16);
            displayCTS();
            t2Cursor(3,2);
            display.print(F("CTS"));
            
            if (diagnoseMinMax == 0){
              t2Cursor(5,4);
              display.print(F("Norm:"));
              t2Cursor(4,5);
              if (tempUnit == false){
                display.print("80-");
                t2Cursor(4,6); 
                display.print("105C");
              }
              else{ 
                display.print("180-");
                t2Cursor(4,6); 
                display.print("220F");
              }
            }
            
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                CTSMin = CTS;
                CTSMax = CTS;
                diagnoseMinMax = 1;
              }
              t1Cursor(10,8);
              display.setTextSize(1);
              display.print("Min");
              
              t1Cursor(2,9);
              display.setTextSize(2);
              if (CTSMin >= -9 && CTSMin <= 99)
                display.print(" ");
              if (CTSMin >= 0 && CTSMin <= 9)
                display.print(" ");
              display.print(CTSMin);
              
              t1Cursor(10,11);
              display.setTextSize(1);
              display.print("Max");
  
              t1Cursor(2,12);
              display.setTextSize(2);
              if (CTSMax >= -9 && CTSMax <= 99)
                display.print(" ");
              if (CTSMax >= 0 && CTSMax <= 9)
                display.print(" ");           
              display.print(CTSMax);
            }
          break;
          case 1://Description
            t1Cursor(8,3);
            display.print(F("Cool"));
            t1Cursor(6,6);  
            display.print(F("ant"));
            t1Cursor(8,9); 
            display.print(F("Temp"));
            t1Cursor(10,12);
            display.print(F("Sendr"));
          break;
          case 2://Location
            t1Cursor(8,3);
            display.print(F("Left"));
            t1Cursor(4,6);
            display.print(F("of"));
            
            t1Cursor(10,9);
            display.print(F("Engin"));
            t1Cursor(10,12);
            display.print(F("Block"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("A:GND");
            t1Cursor(10,6);
            display.print("B:Out");
            t1Cursor(10,9);
            display.print("100k-0 Ohm");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 3://IAT**************************************************
        if (IATRaw < 2 || IATRaw > 200)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            //display.setCursor(0,16);
            displayIAT();
            t2Cursor(3,3);
            display.print("IAT");

            if (diagnoseMinMax == 0){
              t2Cursor(5,5);
              display.print(F("> Out"));
              t2Cursor(3,6);
              display.print("Air");
            }
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                IATMin = IAT;
                IATMax = IAT;
                diagnoseMinMax = 1;
              }
              t1Cursor(10,8);
              display.setTextSize(1);
              display.print("Min");
              
              t1Cursor(2,9);
              display.setTextSize(2);
              if (IATMin >= -9 && IATMin <= 99)
                display.print(" ");
              if (IATMin >= 0 && IATMin <= 9)
                display.print(" ");
              display.print(IATMin);
              
              t1Cursor(10,11);
              display.setTextSize(1);
              display.print("Max");
  
              t1Cursor(2,12);
              display.setTextSize(2);
              if (IATMax >= -9 && IATMax <= 99)
                display.print(" ");
              if (IATMax >= 0 && IATMax <= 9)
                display.print(" ");           
              display.print(IATMax);
            }
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Intak")); 
            t1Cursor(6,6);
            display.print(F("Air"));
            t1Cursor(8,9);
            display.print(F("Temp"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Intak")); 
            t1Cursor(10,6);
            display.print(F("Mnfld"));
            t1Cursor(10,9);
            display.print(F("Bhind")); 
            t1Cursor(10,12);
            display.print(F("TBody"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("A:GND");
            t1Cursor(10,6);
            display.print("B:Out");
            t1Cursor(10,9);
            display.print("100k-0 Ohm");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 4://RPM**************************************************
        if (RPM > 400 && TPS < 19 && (RPM < 570 || RPM > 930))
          celOn();
        switch (diagnoseMode){
          case 0://Readout
            
            //display.setCursor(0,16);
            displayRPM();

            if (diagnoseMinMax == 0){
              t2Cursor(5,4);
              display.print(F("Idle:"));
              t2Cursor(4,5);
              display.print("600-");
              t2Cursor(3,6);
              display.print("900");
            }
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                RPMMin = RPM;
                RPMMax = RPM;
                diagnoseMinMax = 1;
              }
              t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(10,9);
            display.setTextSize(2);
            if (RPMMin < 10)
              display.print(" ");
            if (RPMMin < 100)
              display.print(" ");
            if (RPMMin < 1000)
              display.print(" ");
            if (RPMMin < 10000)
              display.print(" ");
            display.print(RPMMin,1);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(10,12);
            display.setTextSize(2);
            if (RPMMax < 10)
              display.print(" ");
            if (RPMMax < 100)
              display.print(" ");
            if (RPMMax < 1000)
              display.print(" ");
            if (RPMMax < 10000)
              display.print(" ");           
            display.print(RPMMax,1);
            }
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Revol"));
            t1Cursor(10,6);
            display.print(F("ution"));
            t1Cursor(6,9);
            display.print(F("Per"));
            t1Cursor(10,12); 
            display.print(F("Minut"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Drivr"));
            t1Cursor(10,6);
            display.print(F("Trans")); 
            t1Cursor(8,9);
            display.print(F("Bell"));
            t1Cursor(10,12);
            display.print(F("hosng"));
          break;
          case 3://Pinout
            t1Cursor(6,3);
            display.print(F("CPS"));
            t1Cursor(6,6);
            display.print(F("A&B:"));
            t1Cursor(6,8);
            display.print(F("A/C"));
            t1Cursor(10,11);
            display.print(F("125 -"));
            t1Cursor(10,13);
            display.print(F("275Om"));
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 5://Volts**************************************************
        if (RPM > 400 && (Volts < 12.9 || Volts > 15))
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            displayVolts();
            if (diagnoseMinMax == 0){
              t2Cursor(5,4);
              display.print(F("Idle:"));
              t2Cursor(5,5); 
              display.print("13-15");
            }
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                VoltsMin = Volts;
                VoltsMax = Volts;
                diagnoseMinMax = 1;
              }
            t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(6,9);
            display.setTextSize(2);
            if (VoltsMin < 10)
              display.print(" ");
            display.print(VoltsMin,1);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(6,12);
            display.setTextSize(2);
            if (VoltsMax < 10)
              display.print(" ");           
            display.print(VoltsMax,1);
            }
          break;
          case 1://Description
            t1Cursor(8,3);
            display.print(F("Batt"));
            t1Cursor(8,6);
            display.print(F("/Alt"));
            t1Cursor(10,9);
            display.print(F("Volts"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Reads"));
            t1Cursor(10,6);
            display.print(F("0v w/"));
            t1Cursor(10,9);
            display.print(F("Key O"));
            t1Cursor(10,12);
            display.print(F("Eng F"));
          break;
          case 3://Pinout
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 6://TPS**************************************************
        if (TPS < 14 || TPS > 95)
            celOn();
        switch (diagnoseMode){
          case 0://Readout
            gaugeCursor = 0;
            //display.setCursor(0,16);
            displayTPS();
            
            t2Cursor(5,2);
            display.print(TPS/20.08);
            display.print("v ");

            if (diagnoseMinMax == 0){
              t2Cursor(5,3);
              gaugeCursor = 46;
              displayThrottleSwitch();
              
              t2Cursor(5,5);
              display.print("Closd :17%");
            }
            
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                TPSMin = TPS;
                TPSMax = TPS;
                diagnoseMinMax = 1;
              }
            t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(0,9);
            display.setTextSize(2);
            if (TPSMin < 10)
              display.print(" ");
            display.print(TPSMin,1);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(0,12);
            display.setTextSize(2);
            if (TPSMax < 10)
              display.print(" ");           
            display.print(TPSMax,1);
            }
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Throttle"));
            t1Cursor(10,8);
            display.print(F("Postion"));
            t1Cursor(10,13);
            display.print(F("Sensr"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Front"));
            t1Cursor(4,6);
            display.print(F("of"));
            t1Cursor(10,9);
            display.print(F("Thrtl"));
            t1Cursor(8,12);
            display.print(F("Body"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print(F("A:5v"));
            t1Cursor(10,6);
            display.print(F("B:GND"));
            t1Cursor(10,9);
            display.print(F("C:Out"));
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 7://Lambda**************************************************
        currentTime = millis();
        if (Lambda == LambdaPrev){
            if (LambdaCounter == false){
              LambdaPrevTime = currentTime;
              LambdaCounter = true;
            }
            if (currentTime > (LambdaPrevTime + 10000))
              celOn();
          }
          else{
            LambdaPrev = Lambda; //check for new number
            LambdaCounter = false; //Reset Counter
          }
        switch (diagnoseMode){
          case 0://Readout
            //display.setCursor(0,16);
            gaugeCursor = 14;
            displayLambda();
            display.setCursor(0,44);
            gaugeCursor += 16; 
            displayExhaust();

            if (diagnoseMinMax == 0){
            t2Cursor(4,5);    
            display.print(F("0-5vSwing"));
            }
            
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                LambdaMin = Lambda;
                LambdaMax = Lambda;
                diagnoseMinMax = 1;
              }
            t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(7,9);
            display.setTextSize(2);
            display.print(LambdaMin,2);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(7,12);
            display.setTextSize(2);           
            display.print(LambdaMax,2);
            }
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Oxygn"));
            t1Cursor(10,6);
            display.print(F("Sensr"));
            t1Cursor(10,9);
            display.print(F("Volts"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Exhau st"));
            t1Cursor(10,8);
            display.print(F("Manif old"));
            t1Cursor(8,13);
            display.print(F("Pipe"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("A:12v"); 
            t1Cursor(10,6);
            display.print("B:GND");
            t1Cursor(10,9);
            display.print("C:Out");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 8://Knock**************************************************
        switch (diagnoseMode){
          case 0://Readout
            //display.setCursor(0,16);
            gaugeCursor = 0;
            displayKnock();
            t2Cursor(5,2);
            gaugeCursor += 16;
            displayRPM();

            if (diagnoseMinMax == 0){
              t2Cursor(5,4);
              display.print(F("2.5kR:10-  100"));
            }
            if (diagnoseMinMax == 1 || diagnoseMinMax == 2){
              if (diagnoseMinMax == 2){
                KnockMin = Knock;
                KnockMax = Knock;
                diagnoseMinMax = 1;
              }
            t1Cursor(10,8);
            display.setTextSize(1);
            display.print("Min");
            
            t1Cursor(3,9);
            display.setTextSize(2);
            if (KnockMin < 10)
              display.print(" ");
            if (KnockMin < 100)
              display.print(" ");
            display.print(KnockMin);
            
            t1Cursor(10,11);
            display.setTextSize(1);
            display.print("Max");

            t1Cursor(3,12);
            display.setTextSize(2);
            if (KnockMax < 10)
              display.print(" ");
            if (KnockMax < 100)
              display.print(" ");           
            display.print(KnockMax);
            }
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Knock"));
            t1Cursor(10,6);
            display.print(F("Sensr"));
          break;
          case 2://Location
            t1Cursor(10,3);
            display.print(F("Drivr")); 
            t1Cursor(8,6);
            display.print(F("side"));
            t1Cursor(10,9);
            display.print(F("Engin")); 
            t1Cursor(10,12);
            display.print(F("Block"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("A:GND"); 
            t1Cursor(10,6);
            display.print("B:Out");
            t1Cursor(10,9);
            display.print(F("Piezo"));
            t1Cursor(10,12);
            display.print(F("Enrgy"));
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 9://Fuel Trims**************************************************
        switch (diagnoseMode){
          case 0://Readout

            gaugeCursor = 11;
            displayInjPulse();
            
            display.setCursor(0,40);
            gaugeCursor += 13;
            displaySTFuel();
            
            display.setCursor(0,66);
            gaugeCursor += 15;
            displayLTFuel();
            
            display.setCursor(0,90);
            gaugeCursor += 11;
            displayLoopStatus();
            
            
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Short"));
            t1Cursor(10,6);
            display.print(F("/Long"));
            t1Cursor(8,9);
            display.print(F("Fuel"));
            t1Cursor(10,12);
            display.print(F("Trims"));
          break;
          case 2://Location
            t1Cursor(10,2);
            display.print(F("Correction"));
            t1Cursor(10,7);
            display.print(F("Factr"));
            t1Cursor(8,10);
            display.print(F("used"));
            t1Cursor(10,13);
            display.print(F("byECU"));
          break;
          case 3://Pinout
            t1Cursor(10,3);
            display.print("< 128"); 
            t1Cursor(8,6);
            display.print("Lean");
            t1Cursor(10,10);
            display.print("> 128");
            t1Cursor(8,13);
            display.print("Rich");
          break;
        }//diagnoseMode Switch Case end    
      break;
      case 10://ECU type
        switch (diagnoseMode){
          case 0://Readout
            t2Cursor(3,1);
            display.print(F("ECU"));
            
            t2Cursor(5,2);
            display.print("Dtect");
            
            t2Cursor(5,4);            
            if (dataStream[0] == 177) 
              display.print("89-90");
            else if (dataStream[0] == 176) 
              display.print("87-88");
            else if (dataStream[0] == 32)
              display.print(" 2.5L");
            else display.print(" ???");

            
            t2Cursor(3,5);  
            if (dataStream[1] == 16 || dataStream[1] == 20)
              display.print(F("A/T"));
            else if (dataStream[1] == 144 || dataStream[1] == 148)
              display.print("M/T");
            else if (dataStream[1] == 97 || dataStream[1] == 98)
              display.print("New");
            else if (dataStream[1] == 225)
              display.print("Old");
            else display.print("???");
              
          break;
          case 1:
              t1Cursor(10,3);
              display.print(F("PROM#"));
              t1Cursor(8,6);
              display.print(dataStream[0], HEX);
              display.print(dataStream[1], HEX);
              t1Cursor(8,8);
              display.print(dataStream[2], HEX);
              display.print(dataStream[11], HEX);
              t1Cursor(8,10);
              display.print(dataStream[10], HEX);
              display.print(dataStream[30], HEX);
          break;
          case 2:
            diagnoseMode = 0;
          break;
          case 3:
            diagnoseMode = 0;
          break;
        }   
      break;
      case 11://Mysteries**************************************************
        switch (diagnoseMode){
          case 0://Readout
            t2Cursor(3,0);//14 15 17 20 22 23 25 28
            if (dataStream[14] < 100)
              display.print(" ");
            if (dataStream[14] < 10)
              display.print(" ");
            display.print(dataStream[14]);
            
            t2Cursor(3,1);
            if (dataStream[15] < 100)
              display.print(" ");
            if (dataStream[15] < 10)
              display.print(" ");
            display.print(dataStream[15]);
            
            t2Cursor(3,2);
            if (dataStream[17] < 100)
              display.print(" ");
            if (dataStream[17] < 10)
              display.print(" ");
            display.print(dataStream[17]);
            
            t2Cursor(3,3);
            if (dataStream[20] < 100)
              display.print(" ");
            if (dataStream[20] < 10)
              display.print(" ");
            display.print(dataStream[20]);
            
            
            t2Cursor(3,4);
            if (dataStream[22] < 100)
              display.print(" ");
            if (dataStream[22] < 10)
              display.print(" ");
            display.print(dataStream[22]);
            
            t2Cursor(3,5);
            if (dataStream[23] < 100)
              display.print(" ");
            if (dataStream[23] < 10)
              display.print(" ");
            display.print(dataStream[23]);
            
            t2Cursor(3,6);
            if (dataStream[25] < 100)
              display.print(" ");
            if (dataStream[25] < 10)
              display.print(" ");
            display.print(dataStream[25]);
            
            t2Cursor(3,7);
            if (dataStream[28] < 100)
              display.print(" ");
            if (dataStream[28] < 10)
              display.print(" ");
            display.print(dataStream[28]);
            
          break;
          case 1://Description
            t1Cursor(10,3);
            display.print(F("Myste ry")); 
            t1Cursor(8,8);
            display.print(F("Byte"));
            t1Cursor(10,11);
            display.print(F("Value"));
          break;
          case 2://Location
            t2Cursor(2,0);
            display.print(F("14"));
            t2Cursor(2,1);
            display.print(F("15"));
            t2Cursor(2,2);
            display.print(F("17"));
            t2Cursor(2,3);
            display.print(F("20"));
            t2Cursor(2,4);
            display.print(F("22"));
            t2Cursor(2,5);
            display.print(F("23"));
            t2Cursor(2,6);
            display.print(F("25"));
            t2Cursor(2,7);
            display.print(F("28")); 
          break;
          case 3:
            diagnoseMode = 0;
          break;
        }//diagnoseMode Switch Case end    
      break;
     }//diagnoseMenu Switch Case end
    display.display(); 
    }//Timed Update End
    //delay(menuDelay);
  break;
  case Home://Home Selection Screen ************************************************************************************ 
//120mhz = 321us
//96mhz = 331us
//72mhz = 332us
//48mhz = 372us
//24mhz = 456us
    
// + 2-4us
    InOutOrder = 0;//reset diagnose in/out menu
//--

// 7667us
    if (updateScreen > 0){
      display.clearDisplay();
      display.setTextSize(2);
      if (homeScreen == false){//regular screen
        t2Cursor(5,0);
        display.print(F("Gauge"));
        t2Cursor(5,2);
        display.print("TCU");//(F("AW-4 TCU"));
        t2Cursor(5,4);
        display.print(F("Digns"));
        t2Cursor(5,6);
        display.print(F("Optns"));
        
      }
      display.display();
    }//end update screen
// ---

// 5904us
    if (homeScreen == true && (updateTimedScreen == true || updateScreen > 0)){
      display.clearDisplay();
      display.setTextSize(1);
      t1Cursor(8,0);
      displayTimeTiny();
      t1Cursor(8,1);
      displayDateTiny();

      display.setTextSize(2);
      t2Cursor(5,1);
      display.print(F("Gauge"));
      t2Cursor(5,3);
      display.print("TCU");//(F("AW-4 TCU"));
      t2Cursor(5,5);
      display.print(F("Digns"));
      t2Cursor(5,7);
      display.print(F("Optns"));
       
      display.display();
    }
// ---

// no effect
    //lcdKey = readLcdButtons();//*******reads variable input********
    switch(lcdKey)
    {
      case btnTOPLEFT://Vehicle
        if (btnPrev != lcdKey){
          //menuOrder = Vehicle;
          menuOrder = Gauges;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT://Gauges
        if (btnPrev != lcdKey){
          menuOrder = TCUGauges;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMRIGHT://Diagnose
        if (btnPrev != lcdKey){
          menuOrder = Diagnose;
          //menuOrder = InOutMenu;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT://Options
        if (btnPrev != lcdKey){
          menuOrder = Options;
          btnPrev = lcdKey;
        }
      break;
    }
// ---
  break;
  case Options://Main Options Screen*************************************************************************************
    if (updateScreen > 0){
      display.clearDisplay();
      t2Cursor(5,0);
      display.print(F("Units"));
      t2Cursor(5,2);
      display.print(F("Fans"));
      t2Cursor(5,4);
      display.print(F("Vehcl"));
      t2Cursor(5,6);
      display.print(F("Setng"));
      display.display();
    }
    
    //lcdKey = readLcdButtons();         
    switch(lcdKey)                      
    {
      case btnTOPLEFT://Units
        if (btnPrev != lcdKey){
          menuOrder = Units;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT://Display
        if (btnPrev != lcdKey){
          menuOrder = InOutMenu;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMRIGHT://Debug
        if (btnPrev != lcdKey){
          menuOrder = Vehicle;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT://Settings
        if (btnPrev != lcdKey){
          menuOrder = Settings;
          btnPrev = lcdKey;
        }
      break;    
    } 
  break;
  case Vehicle://Vehicle Selection Screen************************************************************************************
   //lcdKey = readLcdButtons();
    switch(lcdKey)
    {
      case btnTOPLEFT://Increase
        if (btnPrev != lcdKey){
          --vehicleOrder;
          btnPrev = lcdKey;
        }
        if(vehicleOrder < 1)
          vehicleOrder = 4;
      break;
      case btnTOPRIGHT:
        if (btnPrev != lcdKey){
          ++vehicleOrder;
          btnPrev = lcdKey;
        }
        if(vehicleOrder > 4)
          vehicleOrder = 1;
      break;
    }

  if (updateScreen > 0)
    display.clearDisplay();
   if (updateScreen > 0 || (tcuStreamUpdate == true && vehicleOrder == 5)){
      tcuStreamUpdate = false;
      
      menuArrows();
   
    switch(vehicleOrder){
      case 1://Trans Type
        if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
          if (btnPrev != lcdKey){
            transType = !transType;
            btnPrev = lcdKey;
          }
        }
        
        menuCursor(5,0);
        display.print(F("Trans"));
        
        menuCursor(3,3);
        if (transType == true)
          display.print("A/T");
        else
          display.print("M/T");
      break;    
      case 2://Tire Size********************************
          switch(lcdKey){ 
            case btnBOTTOMLEFT:
              if (btnPrev != lcdKey){
                --TireSize;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:
              if (btnPrev != lcdKey){
                ++TireSize;
                btnPrev = lcdKey;
              }
            break;
            }
          TireSize = constrain(TireSize, 16, 52);
          
          menuCursor(4,0);
          display.print(F("Tire"));
          menuCursor(4,1);
          display.print(F("Size"));
          
          menuCursor(4,3);
          display.print(TireSize);
          display.print(F("In"));
        break;
        case 3://Gear Ratio******************************
          switch(lcdKey){ 
            case btnBOTTOMLEFT:
              if (btnPrev != lcdKey){
                --GearRatioCounter;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:
              if (btnPrev != lcdKey){
                ++GearRatioCounter;
                btnPrev = lcdKey;
                }
            break;
          }
          GearRatioCounter = constrain(GearRatioCounter, 1, 9);
          
          switch (GearRatioCounter){
            case 1:
              GearRatio = 3.07;
            break;
            case 2:
              GearRatio = 3.55;
            break;
            case 3:
              GearRatio = 3.73;
            break;
            case 4:
              GearRatio = 3.91;
            break;
            case 5:
              GearRatio = 4.11;
            break;
            case 6:
              GearRatio = 4.27;
            break;
            case 7:
              GearRatio = 4.56;
            break;
            case 8:
              GearRatio = 4.88;
            break;
            case 9:
              GearRatio = 5.13;
            break;
            }
            
          menuCursor(4,0);
          display.print(F("Gear"));
          menuCursor(5,1);
          display.print(F("Ratio"));
          
          menuCursor(4,3);
          display.print(GearRatio,2);       
        break;
        case 4://Speed Correction************************
          //lcdKey = readLcdButtons();  // read the buttons
          switch(lcdKey){ 
            case btnBOTTOMLEFT:
              if (btnPrev != lcdKey){
                --SpeedCorr;
                btnPrev = lcdKey;
              }
            break;
            case btnBOTTOMRIGHT:
              if (btnPrev != lcdKey){
                ++SpeedCorr;
                btnPrev = lcdKey;
              }
            break;
          }
          
          menuCursor(5,0);
          display.print(F("Speed"));
          menuCursor(5,1);
          display.print(F("Adjst"));
          
          menuCursor(5,2);
          if (MPH < 10)
            display.print(" ");
          display.print(MPH,1);
          if (speedUnit == false)
            display.print("K");
          else
            display.print("M");
          menuCursor(4,3);
          if (SpeedCorr < 100)
            display.print(" ");
          display.print(SpeedCorr);
          display.print("%");
        break;
      }//end menu switch case
      display.display();
   }//update screen end
    EEPROM.update(EEengine, engine);
    EEPROM.update(EEtransType, transType);
    EEPROM.update(EETireSize, TireSize);
    EEPROM.update(EEGearRatioCounter, GearRatioCounter);
    EEPROM.put(EEGearRatio, GearRatio);//like update but will store the whole float, 4 adresses
    EEPROM.update(EESpeedCorr, SpeedCorr); 
  break;
  case Units: //Unit Selection Screen ****************************************************************************************************              
    switch(lcdKey)                          
    {
      case btnTOPLEFT://goes back 1 menu
        if (btnPrev != lcdKey){
          --unitOrder;
          btnPrev = lcdKey;
        }
        if (unitOrder < 1)
          unitOrder = 5;
      break;
      case btnTOPRIGHT://goes forward 1 menu
        if (btnPrev != lcdKey){
          ++unitOrder;
          btnPrev = lcdKey;
        }
        if (unitOrder > 5)
          unitOrder = 1;
      break;
    }

    if(updateScreen > 0){
      display.clearDisplay();
      
    menuArrows();
      
      switch(unitOrder)
      {
        case 1://Pressure Unit Screen*******************
          pressureUnit = EEPROM.read(EEpressureUnit);

          switch(lcdKey)                          
            {
            case btnBOTTOMLEFT://Decrease case**********
              if (btnPrev != lcdKey){
                --pressureUnit;
                btnPrev = lcdKey;
              }
              if (pressureUnit < 2)                 
                pressureUnit = 4; 
            break;
            case btnBOTTOMRIGHT://Increase case*********       
              if (btnPrev != lcdKey){
                ++pressureUnit;
                btnPrev = lcdKey;
              }
              if (pressureUnit > 4)  
                pressureUnit = 2;
            break; 
            } 
            EEPROM.update(EEpressureUnit, pressureUnit);
            
          menuCursor(5,0);
          display.print(F("Press"));
          menuCursor(3,1);
          display.print(F("ure"));
          switch(pressureUnit)
          {
            /*case 1:
              display.print(F("   Voltage"));//fun fact, spaces take up less bytes then multiple setCursor command
            break;*/
            case 2:
              menuCursor(4,3);
              display.print(F("InHg"));
            break;
            case 3:
              menuCursor(3,3);
              display.print(F("kPa"));
            break;
            case 4:
              menuCursor(3,3);
              display.print(F("PSI"));
            break;
          }
        break;
        case 2://Temperature Unit Screen*******************************
          tempUnit = EEPROM.read(EEtempUnit);
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              tempUnit = !tempUnit;
              btnPrev = lcdKey;
            }
          }     
          EEPROM.update(EEtempUnit, tempUnit);
          
          menuCursor(4,0);
          display.print(F("Temp"));
          menuCursor(4,3);
          if (tempUnit == false)
            display.print(F("Cels"));
          else display.print(F("Fahr"));
        break;
        case 3://Speed Unit Screen*******************************
          speedUnit = EEPROM.read(EEspeedUnit);
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              speedUnit = !speedUnit;
              btnPrev = lcdKey;
            } 
          }     
          EEPROM.update(EEspeedUnit, speedUnit);
          
          menuCursor(5,0);
          display.print(F("Speed"));
          menuCursor(3,3);
          if (speedUnit == false)
            display.print(F("KPH"));
          else display.print(F("MPH"));
        break;
        case 4://TPS Unit Screen*******************************
          tpsMode = EEPROM.read(EEtpsMode);
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              tpsMode = !tpsMode;
              btnPrev = lcdKey;
            } 
          }   
          EEPROM.update(EEtpsMode, tpsMode);
          
          menuCursor(3,0);
          display.print(F("TPS"));
          menuCursor(4,1);
          display.print(F("Mode"));
          
          menuCursor(5,3);
          if (tpsMode == false)
            display.print(F("Advnc"));
          else display.print(F("Norml")); 
        break;
        case 5://Loop Unit Screen*******************************
          loopMode = EEPROM.read(EEloopMode);
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              loopMode = !loopMode;
              btnPrev = lcdKey;
            }
          }  
          EEPROM.update(EEloopMode, loopMode);
          
          menuCursor(4,0);
          display.print(F("Loop"));
          menuCursor(4,1);
          display.print(F("Mode"));
          
          menuCursor(5,3);
          if (loopMode == false)
            display.print(F("Combo"));
          else display.print(F("Seprt")); 
        break;
      }//unitOrder switch end
      display.display();
    }//update screen end
  break;
  /*case PickColor: //Preset Color Screen *****************************************************************************************************
    //lcdKey = readLcdButtons();          //reads variable input
    switch(lcdKey)                      //sets variable to switch
    {
      case btnTOPLEFT :                  //back option
        if (btnPrev != lcdKey){
          menuOrder = CustomColor;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT:
        if (btnPrev != lcdKey){
          menuOrder = Backlight;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT:                  //Decrease case*****
        if (btnPrev != lcdKey){
          --RGBOrder;
          btnPrev = lcdKey;
        }
        if (RGBOrder < 1)               //checks if order is out of bounds
           RGBOrder = 10;    //sets it back to max if above is true
      break;
      case btnBOTTOMRIGHT:                 //Increase case*****       
        if (btnPrev != lcdKey){
          ++RGBOrder;
          btnPrev = lcdKey;
        }
        if (RGBOrder > 10)  
          RGBOrder = 1;                 //sets it back to 0 if above is true
      break;
    } 
    
    if (updateScreen > 0){
      display.clearDisplay();
      //display.noCursor();
      display.setCursor(0,0);
      display.print("<");
      display.setCursor(1,0);
      display.print("Color:");
      display.setCursor(15,0);
      display.print(">");
    
      //case statment to display selected color ******************
      display.setCursor(8,0);
      switch(RGBOrder) 
      {
        case 1://Red
          redValue   = 255;
          greenValue = 0; 
          blueValue  = 0;
          display.print("Red");
        break;
        case 2://Orange
          redValue   = 255;
          greenValue = 24; 
          blueValue  = 0;
          display.print("Orange");   
        break;
        case 3://Yellow
          redValue   = 255;
          greenValue = 75;//old was 50 
          blueValue  = 0;
          display.print("Yellow");   
        break;     
        case 4://Green
          redValue   = 0;
          greenValue = 255; 
          blueValue  = 0;
          display.print("Green");   
        break;
        case 5://Cyan
          redValue   = 0;
          greenValue = 255; 
          blueValue  = 255;
          display.print("Cyan");   
        break;  
        case 6://Blue
          redValue   = 0;
          greenValue = 0; 
          blueValue  = 255;
          display.print("Blue");   
        break;
        case 7://Purple
          redValue   = 255;
          greenValue = 0; 
          blueValue  = 180;
          display.print("Purple");   
        break;  
        case 8://Pink
          redValue   = 255;
          greenValue = 0; 
          blueValue  = 50;
          display.print("Pink");   
        break;  
        case 9://White
          redValue   = 255;
          greenValue = 120;//60 was old 
          blueValue  = 100;//70 was old
          display.print("White");   
        break;  
        case 10://Custom
          redValue   = redCustom;
          greenValue = greenCustom; 
          blueValue  = blueCustom;
          display.print("Custom");   
        break;       
       }

      display.setCursor(0,1);
      display.write(1);//left arrow
      display.print("R");
      display.print(redValue);
      display.setCursor(6,1);
      display.print("G");
      display.print(greenValue);
      display.setCursor(11,1);
      display.print("B");
      display.print(blueValue);
      display.setCursor(15,1);
      display.write(2);//right arrow
      
      EEPROM.update(EEredValue, redValue); //Saves selection to memory
      EEPROM.update(EEgreenValue, greenValue);
      EEPROM.update(EEblueValue, blueValue);
      EEPROM.update(EERGBOrder, RGBOrder);
     //delay(menuDelay);
    }//update screen end
  break; */
  /*case CustomColor: //Custom RGB Backlight Menu ***********************************************************************************************
     //Set custom variables to current variables to show previously saved color 
      redValue = redCustom;
      greenValue = greenCustom;
      blueValue = blueCustom;

      currentTime = millis();//for button re-press
      //lcdKey = readLcdButtons();                   
      switch(lcdKey)                                
      {
        case btnTOPLEFT://increase selected value     
          if (currentTime > prevTime + 50){//millis based delay so the button can be held down
            prevTime = currentTime;
            updateScreen = buttons;
            switch (RGBCustomOrder)
            {
              case 0:                 //Increase Red
                if (redValue < 255)
                  ++redValue;
                break;
              case 1:                 //Increase Green
                if (greenValue < 255)
                  ++greenValue;
                break;
              case 2:                 //Increase Blue
                if (blueValue < 255)
                  ++blueValue;
                break;    
            }
          }
        break;
        case btnTOPRIGHT://switch to next menu
          if (btnPrev != lcdKey){
            menuOrder = RGBCustomSave;
            btnPrev = lcdKey;
          }
        break;  
        case btnBOTTOMLEFT://decrease selected order
          if (currentTime > prevTime + 50){
            prevTime = currentTime;
            updateScreen = buttons;      
            switch (RGBCustomOrder)
            {
              case 0:                 //Decrease Red
                if (redValue > 0)
                  --redValue;
                break;
              case 1:                 //Decrease Green
                if (greenValue > 0)
                  --greenValue;
                break;
              case 2:                 //Decrease Blue
                if (blueValue > 0)
                  --blueValue;  
                break;    
            }
          }
        break;
        case btnBOTTOMRIGHT://Move to next selection      
          if (btnPrev != lcdKey){
            ++RGBCustomOrder;
            btnPrev = lcdKey;
          }
          if (RGBCustomOrder > 2)  
            RGBCustomOrder = 0;                     //sets it back to 0 if above is true
        break;
      }
      
    if (updateScreen > 0){      
      //display.cursor(); //turns on underline cursor
      display.setCursor(0,0);
      display.print(F("^ Custom Color S"));
      display.setCursor(0,1);
      display.print("vR");
      display.setCursor(6,1);
      display.print("G");
      display.setCursor(11,1);
      display.print("B");
      display.setCursor(15,1);
      display.write(2);//right arrow

      display.setCursor(2,1);
      display.print(redValue);
      if (redValue < 100)
        display.print(" ");
      if (redValue < 10)
        display.print(" ");
      
      display.setCursor(7,1);
      display.print(greenValue);
      if (greenValue < 100)
        display.print(" ");
      if (greenValue < 10)
        display.print(" ");
      
      display.setCursor(12,1);
      display.print(blueValue);
      if (blueValue < 100)
        display.print(" ");
      if (blueValue < 10)
        display.print(" ");
     
     //Set Final Underline Cursor Position**********************************
      switch (RGBCustomOrder)
      {
        case 0:                 //Red
          display.setCursor(1,1);
          break;  
        case 1:                 //Green
          display.setCursor(6,1);  
          break;
        case 2:                 //Blue
          display.setCursor(11,1);
          break;  
      }
    }
      //Save selected value to custom variable  
      redCustom = redValue;
      greenCustom = greenValue;
      blueCustom = blueValue;
  break;    
  case RGBCustomSave://quick menu that sets RGB color back to RGBOrder **********************************************************
    EEPROM.update(EEredCustom, redCustom);
    EEPROM.update(EEgreenCustom, greenCustom);
    EEPROM.update(EEblueCustom,blueCustom);

    if(RGBOrder == 10){
      redValue = redCustom;
      greenValue = greenCustom;
      blueValue = blueCustom;
      EEPROM.update(EEredValue, redValue);
      EEPROM.update(EEgreenValue, greenValue);
      EEPROM.update(EEblueValue,blueValue);
    } 
    else{
      redValue = EEPROM.read(EEredValue);
      greenValue = EEPROM.read(EEgreenValue);
      blueValue = EEPROM.read(EEblueValue);
    }
    menuOrder = PickColor;
  break; */
  case Backlight://RGB Dimmer Screen ****************************************************************************************************************
    //lcdKey = readLcdButtons();               
    switch(lcdKey)                          
    {
      case btnTOPLEFT://goes back to options menu
        if (btnPrev != lcdKey){
          menuOrder = PickColor;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT://goes back to Color Picker Screen
        if (btnPrev != lcdKey){
          //menuOrder = AutoResyncScreen;//V1/V2 Option
          menuOrder = CustomColor;//V3 Option
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT://Decrease case**********
        if (btnPrev != lcdKey){
          --RGBDimOrder;
          btnPrev = lcdKey;
        }
        if (RGBDimOrder < 1)                 
           RGBDimOrder = 5;  
      break;
      case btnBOTTOMRIGHT://Increase case*********       
        if (btnPrev != lcdKey){
          if (RGBDimOrder == 5)
            menuOrder = AutoBrightness;
          else
            ++RGBDimOrder;
        btnPrev = lcdKey;
        }
        if (RGBDimOrder > 5)  
          RGBDimOrder = 1;                    
      break;
    }
    
    if (updateScreen == menu){
      display.clearDisplay();
      display.setCursor(0,0);
      display.print(F("<"));
      display.setCursor(3,0);
      display.print(F("Backlight"));
      display.setCursor(15,0);
      display.print(F(">"));
      display.setCursor(0,1);
      display.write(1);//left arrow
    }

    if (updateScreen > 0){ 
      display.setCursor(6,1);
      switch(RGBDimOrder)//dim selection case****
      {
        case 1:
          RGBDim = 0;
          display.print("Off ");
        break;
        case 2:
          RGBDim = 3;
          display.print("Low ");
        break;
        case 3:
          RGBDim = 20;
          display.print("Med ");
        break;
        case 4:
          RGBDim = 100;
          display.print("High");
        break;  
        case 5:
          display.print("Auto");
        break;
        }

      display.setCursor(15,1);
      if (RGBDimOrder == 5)
        display.print("E");
      else display.write(2);//right arrow
    }
    EEPROM.update(EERGBDimOrder, RGBDimOrder); //saves selection to memory 
    EEPROM.update(EERGBDim, RGBDim);
  break;
  case AutoBrightness://********************************************************************************************************************
    currentTime = millis();//for button re-press
    //lcdKey = readLcdButtons();               
    switch(lcdKey)                          
    {
      case btnTOPLEFT://Increase****
      if (currentTime > prevTime + 200){
         prevTime = currentTime;  
        switch(AutoDimOrder)
        {
          case 1: //Dim
            if (autoDim < 100)
              ++autoDim;
          break;
          case 2: //Low
            //if (lowDim > 0)
              ++lowDim;
          break;
          case 3: // High
            //if (highDim < 0)
              ++highDim;
          break;
        }
      }
      break;
      case btnTOPRIGHT://Move case****
        if (btnPrev != lcdKey){
          menuOrder = Backlight;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT://Decrease case**********
        if (currentTime > prevTime + 200){
          prevTime = currentTime;
          switch(AutoDimOrder)
          {
            case 1: //Dim
              if (autoDim > 0)
                --autoDim;
            break;
            case 2: //Low
              if (lowDim > 0)
                --lowDim;
            break;
            case 3: // High
              if (highDim > 0)
                --highDim;
            break;
        }
        }
      break;
      case btnBOTTOMRIGHT://Move case*********       
        if (btnPrev != lcdKey){
            ++AutoDimOrder;
            btnPrev = lcdKey;
        }
        if (AutoDimOrder > 3)  
          AutoDimOrder = 1;                    
      break;
    }
    
    if (updateScreen == menu){
      display.clearDisplay();
      //display.cursor();
      display.setCursor(0,0);
      display.print(F("+ Dim"));
      display.setCursor(8,0);
      display.print(F("Lght"));
      display.setCursor(0,1);
      display.print("- Low");
      display.setCursor(8,1);
      display.print("High");
      display.setCursor(15,0);
      display.print("^");
      display.setCursor(15,1);
      display.write(2);
    }
  if (updateScreen > 0 || updateTimedScreen == true){
    display.setCursor(5,0);
    display.print(autoDim);
    if (autoDim < 10)
      display.print(" ");
      
    display.setCursor(12,0);
    if (lightSensor < 100)
      display.print(" ");
    if (lightSensor < 10)
      display.print(" ");
    display.print(lightSensor);

    display.setCursor(5,1);
    display.print(lowDim * 4);
    if (lowDim * 4 < 100)
      display.print(" ");
    if (lowDim * 4 < 10)
      display.print(" ");

    display.setCursor(12,1);
    display.print(highDim * 4);
    if (highDim * 4 < 100)
      display.print(" ");
    if (highDim * 4 < 10)
      display.print(" ");
     
    switch(AutoDimOrder)
    {
      case 1: //Dim
        display.setCursor(5,0);
        RGBDim = autoDim;
      break;
      case 2: //Low
        display.setCursor(5,1);
      break;
      case 3: // High
        display.setCursor(12,1);
      break;
    }
  }
    EEPROM.update(EEautoDim, autoDim); //see AutoBrightness Menu
    EEPROM.update(EElowDim, lowDim);
    EEPROM.update(EEhighDim, highDim);
  break;
  /*case AutoResyncScreen:// ********************************************************************************************************************
    AutoResync = EEPROM.read(EEAutoResync);//V1/V2 Option
    //display.clearDisplay();
    if (updateScreen == 1 || updateScreen == 2){
        display.clearDisplay();
        updateScreen = 0;
    }
    display.setCursor(0,0);
    display.print(F("< Auto Re-Sync >"));
    display.setCursor(0,1);
    display.write(1);//left arrow
    display.setCursor(15,1);
    display.write(2);//right arrow
    display.setCursor(4,1);
    if (AutoResync == 1)
      display.print(F("Enabled"));
    else display.print(F("Disabled"));
    
    //lcdKey = readLcdButtons();               
    switch(lcdKey)                          
    {
      case btnTOPLEFT://goes back to options menu
        if (btnPrev != lcdKey){
          menuOrder = Backlight;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT://goes back to Color Picker Screen
        if (btnPrev != lcdKey){
          menuOrder = CustomColor;
          btnPrev = lcdKey;
        }
      break;
      case btnBOTTOMLEFT://Decrease case**********
        if (btnPrev != lcdKey){
          --AutoResync;
          btnPrev = lcdKey;
        }
        if (AutoResync < 1)                 
           AutoResync = 2;  
      break;
      case btnBOTTOMRIGHT://Increase case*********       
        if (btnPrev != lcdKey){
          ++AutoResync;
          btnPrev = lcdKey;
        }
        if (AutoResync > 2)                 
           AutoResync = 1;                  
      break;
    }  
    EEPROM.update(EEAutoResync, AutoResync);
    delay(menuDelay);
  break;*/
  /*case Debug:// ***************************************************************************************************************************** 
    display.clearDisplay();
    display.setCursor(0,0);
        switch(debugStreamOrder)
        {
        case 1:
          display.print(dataStream[0]);
          display.setCursor(3,0);
          display.print(dataStream[1]);
          display.setCursor(6,0);
          display.print(dataStream[2]);
          display.setCursor(9,0);
          display.print(dataStream[3]);
          display.setCursor(12,0); 
          display.print(dataStream[4]);
          
          display.setCursor(0,1);
          display.print(dataStream[5]);
          display.setCursor(3,1);
          display.print(dataStream[6]);
          display.setCursor(6,1);
          display.print(dataStream[7]);  
          display.setCursor(9,1);
          display.print(dataStream[8]);
          display.setCursor(12,1); 
          display.print(dataStream[9]);
          display.setCursor(15,1);
          display.print("1");
        break;
        case 2:
          display.print(dataStream[10]);
          display.setCursor(3,0);
          display.print(dataStream[11]);
          display.setCursor(6,0);
          display.print(dataStream[12]);
          display.setCursor(9,0);
          display.print(dataStream[13]);
          display.setCursor(12,0); 
          display.print(dataStream[14]);
          
          display.setCursor(0,1);
          display.print(dataStream[15]);
          display.setCursor(3,1);
          display.print(dataStream[16]);
          display.setCursor(6,1);
          display.print(dataStream[17]);  
          display.setCursor(9,1);
          display.print(dataStream[18]);
          display.setCursor(12,1); 
          display.print(dataStream[19]);
          display.setCursor(15,1);
          display.print("2");
        break;
        case 3:  
          display.print(dataStream[20]);
          display.setCursor(3,0);
          display.print(dataStream[21]);
          display.setCursor(6,0);
          display.print(dataStream[22]);
          display.setCursor(9,0);
          display.print(dataStream[23]);
          display.setCursor(12,0); 
          display.print(dataStream[24]);
          
          display.setCursor(0,1);
          display.print(dataStream[25]);
          display.setCursor(3,1);
          display.print(dataStream[26]);
          display.setCursor(6,1);
          display.print(dataStream[27]);  
          display.setCursor(9,1);
          display.print(dataStream[28]);
          display.setCursor(12,1); 
          display.print(dataStream[29]);
          display.setCursor(15,1);
          display.print("3");
        break;
        case 4:  
          display.print(dataStream[30]);
          display.setCursor(3,0);
          display.print(dataStream[31]);
          
          display.setCursor(15,1);
          display.print("4");               
        break;
        }//debugStreamOrder Switch
        display.setCursor(15,1);
        display.blink();
     
    //lcdKey = readLcdButtons();//read bottom buttons to change value               
        switch(lcdKey)                          
        {
        case btnTOPLEFT://Decrease case**********
          if (btnPrev != lcdKey)
            --debugStreamOrder;
          if (debugStreamOrder < 1)                 
             debugStreamOrder = 4;  
        break;
        case btnTOPRIGHT://Increase case*********       
          if (btnPrev != lcdKey)
            ++debugStreamOrder;
          if (debugStreamOrder > 4)  
            debugStreamOrder = 1;                
        break;  
        }
      //btnPrev = lcdKey;
    delay(menuDelay);
  break;*/
  case Settings://Settings Selection Screen (Scrolling)***********************************************************************************
    //lcdKey = readLcdButtons();//read buttons for changing screens               
    switch(lcdKey)                          
    {
      case btnTOPLEFT://goes back 1 menu
        if (btnPrev != lcdKey){
          --settingsOrder;
          btnPrev = lcdKey;
        }
        if (settingsOrder < 1)
          settingsOrder = 7;
      break;
      case btnTOPRIGHT://goes forward 1 menu
        if (btnPrev != lcdKey){
          ++settingsOrder;
          btnPrev = lcdKey;
        }
        if (settingsOrder > 7)
          settingsOrder = 1;
      break;
    }
      
    if (updateScreen > 0){
      display.clearDisplay();
      menuArrows();
    
      switch(settingsOrder)
      {
        case 1://Gauge Update Speed*******************
          updateSpeedMenu = EEPROM.read(EEupdateSpeedMenu);
          updateSpeed = EEPROM.read(EEupdateSpeed);   
                
          switch(lcdKey)                          
          {
          case btnBOTTOMLEFT://Decrease case**********
            if (btnPrev != lcdKey){
              --updateSpeedMenu;
              btnPrev = lcdKey;
            }
            if (updateSpeedMenu < 1)  
              updateSpeedMenu = 4; 
          break;
          case btnBOTTOMRIGHT://Increase case*********       
            if (btnPrev != lcdKey){
              ++updateSpeedMenu;
              btnPrev = lcdKey;
            }
            if (updateSpeedMenu > 4)  
              updateSpeedMenu = 1;
          break;  
          }
          EEPROM.update(EEupdateSpeed, updateSpeed);
          EEPROM.update(EEupdateSpeedMenu, updateSpeedMenu);
         
            menuCursor(5,0);
            display.print(F("Updat"));
            menuCursor(5,1);
            display.print(F("Speed"));
            switch(updateSpeedMenu)//Gauge Update Speed selection case****
            {         
              case 1:
                updateSpeed = slow;
                menuCursor(4,3);
                display.print(F("Slow"));
              break;
              case 2: 
                updateSpeed = med;
                menuCursor(3,3);
                display.print(F("Med"));
              break;
              case 3:
                updateSpeed = fast;
                menuCursor(4,3);
                display.print(F("Fast"));
              break;
              case 4:
                updateSpeed = ludi;
                menuCursor(5,3);
                display.print(F("Turbo"));
              break;  
             }
             
        break;
        case 2://Check Engine Light Option
          cel = EEPROM.read(EEcel);               
          switch(lcdKey)                          
          {
          case btnBOTTOMLEFT://Decrease case**********
            if (btnPrev != lcdKey){
              --cel;
              btnPrev = lcdKey;
            }
            if (cel < 1)                 
               cel = 3; 
          break;
          case btnBOTTOMRIGHT://Increase case*********       
            if (btnPrev != lcdKey){
              ++cel;
              btnPrev = lcdKey;
            }
            if (cel > 3)  
              cel = 1;                 
          break;
          }
          EEPROM.update(EEcel, cel);
          
          
          menuCursor(5,0);
          display.print(F("CkEng"));
          menuCursor(5,1);
          display.print(F("Light"));
          switch(cel){
            case 1:
              menuCursor(3,3);
              display.print(F("Off"));
            break;
            case 2:
              menuCursor(5,3);
              display.print(F("Fails"));
            break;
            case 3:
              menuCursor(5,3);
              display.print(F("&Warn"));
            break;
          }
        break;
        case 3://Splash Screen*************              
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              EEPROM.update(EEsplashScreen, !EEPROM.read(EEsplashScreen));
              btnPrev = lcdKey;
            }
          }

            menuCursor(5,0);
            display.print(F("Splsh"));
            menuCursor(5,1);
            display.print(F("Scren"));

            if (EEPROM.read(EEsplashScreen) == true){
              menuCursor(3,3);
              display.print("Yes");
              }
            else{
              menuCursor(2,3); 
              display.print("No");
            }
        break;
        case 4://Reset Screen*************
          //lcdKey = readLcdButtons();//read bottom buttons to change value               
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              if (EEPROM.read(EEreset) == 0)
                EEPROM.update(EEreset, 255);
              else EEPROM.update(EEreset, 0);
              btnPrev = lcdKey;
            }
          }
          
            menuCursor(5,0);
            display.print(F("Reset"));
            menuCursor(5,1);
            display.print(F("Setng"));
            
            if (EEPROM.read(EEreset) == 255){
              menuCursor(5,3);
              display.print("Y Rst");
              }
            else{
              menuCursor(2,3);
              display.print("No");
            }  
        break;
        case 5://Time Settings, V3 Option
          //lcdKey = readLcdButtons();//read buttons for changing screens               
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){                         
            if (btnPrev != lcdKey){
              menuOrder = TimeMenu;
              btnPrev = lcdKey;
            }
          }

            menuCursor(5,0);
            display.print(F("Clock"));
            menuCursor(5,1);
            display.print(F("Setng"));

            menuCursor(4,3);
            display.print("Edit");
        break;
        case 6://Advance Settings
          //lcdKey = readLcdButtons();//read buttons for changing screens               
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){                         
            if (btnPrev != lcdKey){
              menuOrder = advancedMenu;
              btnPrev = lcdKey;
            }
          }
          
            menuCursor(5,0);
            display.print(F("Advnc"));
            menuCursor(5,1);
            display.print(F("Optns"));
            menuCursor(4,3);
            display.print("Edit");
            display.display();
        break;
        case 7://Info Screen, match this to print statment above
            menuCursor(5,0);
            display.print(F("Sofwr"));
            menuCursor(5,1);
            display.print(F("InfoV"));
            menuCursor(5,2);
            display.print(softwareVersion,3);
            menuCursor(5,3);
            display.print("U:");
            display.print(EEPROM.read(EEModelNumber));
        break;
      }//Settings Order Case Switch End
      display.display();
    }//updateScreen end
  break;
  case advancedMenu://Menu for advanced options *******************************************************************************************
    //lcdKey = readLcdButtons();//read buttons for changing screens               
    switch(lcdKey)                          
    {
      case btnTOPLEFT://goes back 1 menu
        if (btnPrev != lcdKey){
          --advSettingsOrder;
          btnPrev = lcdKey;
        }
        if (advSettingsOrder < 1)
          advSettingsOrder = 6;
      break;
      case btnTOPRIGHT://goes forward 1 menu
        if (btnPrev != lcdKey){
          ++advSettingsOrder;
          btnPrev = lcdKey;
        }
        if (advSettingsOrder > 6)
          advSettingsOrder = 1;
      break;
    }
      
    if (updateScreen > 0){
      display.clearDisplay();
      menuArrows();
      
    switch(advSettingsOrder)
      {
        case 1://Bluetooth*************        
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              EEPROM.update(EEbluetooth, !EEPROM.read(EEbluetooth));//neat, can flip the values completely in eeprom without a local variable
              btnPrev = lcdKey;
            }
          }
          menuCursor(4,0);
          display.print(F("Blue"));
          menuCursor(5,1);
          display.print(F("tooth"));
            
          if (EEPROM.read(EEbluetooth) == true){
            menuCursor(2,3);
            display.print("On");
          }
          else{
            menuCursor(3,3);
            display.print("Off");
          }
        break;
        case 2://Gyroscope*************            
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              EEPROM.update(EEgyroscope, !EEPROM.read(EEgyroscope));
              btnPrev = lcdKey;
            }
          }
          menuCursor(4,0);
          display.print(F("Gyro"));
          menuCursor(5,1);
          display.print(F("scope"));
            
          if (EEPROM.read(EEgyroscope) == true){
            menuCursor(2,3);
            display.print("On");
          }
          else{
            menuCursor(3,3);
            display.print("Off");
          }
        break;
        case 3://Free Pin 1             
          switch(lcdKey){
                case btnBOTTOMLEFT:
                  if (btnPrev != lcdKey){
                    if (EEPROM.read(EEfan1Pin) > pin1)
                      EEPROM.update(EEfan1Pin, EEPROM.read(EEfan1Pin) - 1);
                    else 
                      EEPROM.update(EEfan1Pin, 0);
                    btnPrev = lcdKey;
                  } 
                break;
                case btnBOTTOMRIGHT:
                  if (btnPrev != lcdKey){
                    if (EEPROM.read(EEfan1Pin) == 0)
                      EEPROM.update(EEfan1Pin, pin1);
                    else if (EEPROM.read(EEfan1Pin) < pin3)
                      EEPROM.update(EEfan1Pin, EEPROM.read(EEfan1Pin) + 1);
                    btnPrev = lcdKey;
                  } 
                break;
              }
          
            menuCursor(5,0);
            display.print(F("Fan 1"));
            
            menuCursor(5,3);
            switch(EEPROM.read(EEfan1Pin)){
              case 0:
                menuCursor(3,3);
                display.print("Off");
              break;
              case pin1:
                display.print("A1/E3");
              break;
              case pin2:
                display.print("A2/E5");
              break;
              case pin3:
                display.print("A3/E7");
              break;
            }
        break;
        case 4://Free Pin 2              
          switch(lcdKey){
            case btnBOTTOMLEFT:
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan2Pin) > pin1)
                  EEPROM.update(EEfan2Pin, EEPROM.read(EEfan2Pin) - 1);
                else 
                  EEPROM.update(EEfan2Pin, 0);
                btnPrev = lcdKey;
              } 
            break;
            case btnBOTTOMRIGHT:
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan2Pin) == 0)
                  EEPROM.update(EEfan2Pin, pin1);
                else if (EEPROM.read(EEfan2Pin) < pin3)
                  EEPROM.update(EEfan2Pin, EEPROM.read(EEfan2Pin) + 1);
                btnPrev = lcdKey;
              } 
            break;
          }

          menuCursor(5,0);
          display.print(F("Fan 2"));
          
          menuCursor(5,3);
          switch(EEPROM.read(EEfan2Pin)){
            case 0:
              menuCursor(3,3);
              display.print("Off");
            break;
            case pin1:
              display.print("A1/E3");
            break;
            case pin2:
              display.print("A2/E5");
            break;
            case pin3:
              display.print("A3/E7");
            break;
          }
        break;
        case 5://Free Pin 3             
          switch(lcdKey){
            case btnBOTTOMLEFT:
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan3Pin) > pin1)
                  EEPROM.update(EEfan3Pin, EEPROM.read(EEfan3Pin) - 1);
                else 
                  EEPROM.update(EEfan3Pin, 0);
                btnPrev = lcdKey;
              } 
            break;
            case btnBOTTOMRIGHT:
              if (btnPrev != lcdKey){
                if (EEPROM.read(EEfan3Pin) == 0)
                  EEPROM.update(EEfan3Pin, pin1);
                else if (EEPROM.read(EEfan3Pin) < pin3)
                  EEPROM.update(EEfan3Pin, EEPROM.read(EEfan3Pin) + 1);
                btnPrev = lcdKey;
              } 
            break;
          }
          
            menuCursor(5,0);
          display.print(F("Fan 3"));
          
          menuCursor(5,3);
          switch(EEPROM.read(EEfan3Pin)){
            case 0:
              menuCursor(3,3);
              display.print("Off");
            break;
            case pin1:
              display.print("A1/E3");
            break;
            case pin2:
              display.print("A2/E5");
            break;
            case pin3:
              display.print("A3/E7");
            break;
          }
        break;
        case 6://usb upload reeboot
          if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              _reboot_Teensyduino_();//invokes Teensy Reboot to allow TeensyLoader access without having to press the button btnPrev = lcdKey;
            }
          }
          menuCursor(4,0);
          display.print(F("USB"));
          menuCursor(5,1);
          display.print(F("UPDAT"));
            
          menuCursor(2,3);
          display.print("RBOOT");
        break;
      }
    display.display();
    }//update Screen end
  break;
  case TimeMenu://Menu for setting the Real Time Clock and Options ************************************************************************
    switch(lcdKey){
      case btnTOPLEFT:
        if (btnPrev != lcdKey && timeMenuOrder > 1){
           --timeMenuOrder;
          btnPrev = lcdKey;
        }
      break;
      case btnTOPRIGHT:
        if (btnPrev != lcdKey){
           ++timeMenuOrder;
          btnPrev = lcdKey;
        }
        if (timeMenuOrder > 4)
            timeMenuOrder = 1;
      break;
    }             
       
    switch(timeMenuOrder){
      case 1:
      //lcdKey = readLcdButtons();//read buttons for changing screens               
        switch(lcdKey)                          
        {
          case btnBOTTOMRIGHT://Add 1
            if (btnPrev != lcdKey){
              DateTime now = rtc.now();//doesn't like being in the below switch case for some reason
              switch (timeSetOrder)
              {
                case 1://hour
                  if (now.hour() >= 23)
                    rtc.adjust(DateTime(now.year(), now.month(), now.day(), 0, now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour()+1, now.minute(), now.second()));
                break;
                case 2://minute
                  if (now.minute() >= 59)
                    rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour(), 0, now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour(), now.minute()+1, 0));
                break;
                case 3://month
                  if (now.month() >= 12)
                    rtc.adjust(DateTime(now.year(), 1, now.day(), now.hour(), now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month()+1, now.day(), now.hour(), now.minute(), now.second()));
                break;
                case 4://day
                  if (now.day() >= 31)
                    rtc.adjust(DateTime(now.year(), now.month(), 1, now.hour(), now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day()+1, now.hour(), now.minute(), now.second()));
                break;
                case 5://year
                  rtc.adjust(DateTime(now.year()+1, now.month(), now.day(), now.hour(), now.minute(), now.second()));
                break;
              }
              btnPrev = lcdKey;
            } 
          break;
          case btnBOTTOMLEFT://Subtract 1
            if (btnPrev != lcdKey){
              DateTime now = rtc.now();//doesn't like being in the below switch case for some reason
              switch (timeSetOrder)
              {
                case 1://hour
                  if (now.hour() <= 0)
                    rtc.adjust(DateTime(now.year(), now.month(), now.day(), 23, now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour()-1, now.minute(), now.second()));
                break;
                case 2://minute
                  if (now.minute() <= 0)
                    rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour(), 59, now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day(), now.hour(), now.minute()-1, now.second()));
                break;
                case 3://month
                  if (now.month() <= 1)
                    rtc.adjust(DateTime(now.year(), 12, now.day(), now.hour(), now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month()-1, now.day(), now.hour(), now.minute(), now.second()));
                break;
                case 4://day
                  if (now.day() <= 1)
                    rtc.adjust(DateTime(now.year(), now.month(), 31, now.hour(), now.minute(), now.second()));
                  else rtc.adjust(DateTime(now.year(), now.month(), now.day()-1, now.hour(), now.minute(), now.second()));
                break;
                case 5://year
                  rtc.adjust(DateTime(now.year()-1, now.month(), now.day(), now.hour(), now.minute(), now.second()));
                break;
              }
              btnPrev = lcdKey;
            }
          break;
          case btnTOPLEFT://move cursor
            if (btnPrev != lcdKey){
              ++timeSetOrder;
              if (timeSetOrder > 5)
                timeSetOrder = 1;
              btnPrev = lcdKey;
            }
          break;
        }//button switch case end

        
        if (updateScreen > 0 || updateTimedScreen == true){
          display.clearDisplay();

          display.setCursor(0,0);
          display.setTextSize(2);
          display.print("v");
          display.setCursor(51,0);
          display.print(">");
          display.setCursor(0,112);
          display.print("-");//write(1);//left arrow
          display.setCursor(51,112);
          display.print("+");//write(2);//right arrow 

          DateTime now = rtc.now();
          menuCursor(5,0);
          displayTimeBig();
          menuCursor(2,1);
          if (now.hour() > 11)
            display.print("PM");
          else
            display.print("AM");
          menuCursor(5,2);
          displayDateBig();
          menuCursor(4,3);
          display.print(now.year());
          
        //  _____
        //  12:45
        //   PM
        //  12/12
        //  2017
        switch (timeSetOrder)
        {
          case 1:
            display.drawFastHLine(2, 38, 24, WHITE);
          break;
          case 2:
            display.drawFastHLine(37, 38, 24, WHITE);
          break;
          case 3:
            display.drawFastHLine(2, 82, 24, WHITE);
          break;
          case 4:
            display.drawFastHLine(38, 82, 24, WHITE);
          break;
          case 5:
            display.drawFastHLine(32, 104, 24, WHITE);
          break;
        }
        display.display();
        }
    
        //________________
        //+   12:42:12   >
        //-   12/13/22
        
      break;
      case 2://24 hour              
        if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              hourSetting = !hourSetting;//Boolean variable, neat trick to switch the value to true or flase
              btnPrev = lcdKey;
            }
        }
        EEPROM.update(EEhourSetting, hourSetting);

        if (updateScreen > 0){
        display.clearDisplay();
        menuArrows();
        menuCursor(4,0);
        display.print(F("Hour"));
        menuCursor(5,1);
        display.print(F("Formt"));
        menuCursor(3,3);
        if (hourSetting == true)
          display.print("12H");
        else 
          display.print("24H");
        display.display();
        }
      break;
      case 3://home screen clock
          //lcdKey = readLcdButtons();//read buttons for changing screens               
        if (lcdKey == btnBOTTOMLEFT || lcdKey == btnBOTTOMRIGHT){
            if (btnPrev != lcdKey){
              homeScreen = !homeScreen;
              btnPrev = lcdKey;
            } 
        }
        EEPROM.update(EEhomeScreen, homeScreen);
        
        if (updateScreen > 0){
        display.clearDisplay();
        menuArrows();
        menuCursor(4,0);
        display.print("Home");
        menuCursor(5,1);
        display.print("Clock");
        if (homeScreen == true){
          menuCursor(2,3);
          display.print("On");
        }
        else{ 
          menuCursor(3,3);
          display.print("Off");
        }
        display.display();
        }
      break;
    }//timeOrder switch case end
  break;
  }//Root Menu System Case Switch End
    
}//Loop End
/* 
 *  display.print(F) Macro notes: Great way to free up RAM when lots of display.print commands are used but requires selective use.
 *  Usually you are trading a little bit of Program Space to free up a little bit more Ram. After a bit you may notice PS doesn't change
 *  but the Ram can keep going down drastically but one command may sky rocket the PS and not change Ram at all. I feel like text inside 
 *  if statements usually don't help and symbols, long spaces, and 1 letter prints usually don't help either. Brute Force 1 by 1 and check
 *  results saved over 600 bytes of ram by carefully choosing which ones to use, and thats after use of some previous (F) Macros.
  
  //lcdKey = readLcdButtons();//blank button template
  switch(lcdKey)
  {
    case btnTOPLEFT:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
    case btnTOPRIGHT:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
    case btnBOTTOMLEFT:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
    case btnBOTTOMRIGHT:
      if (btnPrev != lcdKey){
        
        btnPrev = lcdKey;
      }
    break;
  }
    */
/*center of 16 line screen
         ________________
               1        =7
               22       =7
              333       =6
              4444      =6
             55555      =5
             666666     =5
            7777777     =4
            88888888    =4
           999999999    =3
           1010101010   =3
          11111111111   =2
          121212121212  =2
         1313131313131  =1
         14141414141414 =1
        151515151515151 =0
        1616161616161616=0
 */
  /*
    //Debug bamf- /t is insert tab. Prints binary version (marking print() with x,BIN doesn't print preceding zeroes), hex and denary. Needs a lot of Terminal window lines.
    for (Position=0;Position<31;Position++){
    Serial.print("Byte ");
    Serial.print(Position);
    Serial.print("\t");
    Serial.print(bitRead(dataStream[Position],7));
    Serial.print(bitRead(dataStream[Position],6));
    Serial.print(bitRead(dataStream[Position],5));
    Serial.print(bitRead(dataStream[Position],4));
    Serial.print(bitRead(dataStream[Position],3));
    Serial.print(bitRead(dataStream[Position],2));
    Serial.print(bitRead(dataStream[Position],1));
    Serial.print(bitRead(dataStream[Position],0));
    Serial.print("\t");
    Serial.print(dataStream[Position],HEX);
    Serial.print("  \t");
    Serial.print(dataStream[Position]);
    Serial.println("\e[K");  // clear to end of line
    }
    //End debug
  */
  /*
    Glossary
      From what I have researched, this is the framing- it isn't correct for some on the GTA. Still working on it. 
      Jeep Data points updated by Nick Risley. *'s indicate Phils old vlaues that i have not been able to verify 
    Byte   : 4.0L Jeep              / 4 cyl renix (R21 turbo)   / 13,32 2.0 F3R AMC GTA (confirmed)
    Byte 0 : Program Version  1 & 2 / Program Version           / Program Version
    Byte 1 : PROM Version     3 & 4 / PROM Version              / PROM version
    Byte 2 : Calibration code 5 & 6 / Engine run flags (bin)    / Switch values. C = engine off, nothing selected. 4 = off idle stop
    Byte 3 : MAP                    / MAP                       / MAP
    Byte 4 : CTS                    / CLT                       / CLT
    Byte 5 : IAT                    / IAT                       / IAT
    Byte 6 : Battery Volts          / Battery Volts             / Battery Volts
    Byte 7 : Oxygen sensor          / Oxygen sensor
    Byte 8 : RPM LO byte            / RPM LO Byte               / RPM LO
    Byte 9 : RPM HI byte            / RPM HI byte               / RPM HI
    Byte 10: 9th & 10th PROM        / Inj pulsewidth LO byte    / Injector Pulse LO
    Byte 11: 7th & 8th PROM         / Inj pulsewidth HI byte    / Injector Pulse HI
    Byte 12: Throttle position      / Knock sensor
    Byte 13: Advance degrees        / Advance degrees           / Throttle Position
    Byte 14: *unknown               / Control
    Byte 15: *ECT_ADC               / Turbo correction value
    Byte 16: Baro before start      / unknown
    Byte 17: *Mode                  / Failure flags  %
    Byte 18: Loop/Exhaust/EGR, *ALFA - (byte/10=air ratio) {14.7:1) / Road speed
    Byte 19: Pulse width            / throttle stop
    Byte 20: *..?                   / Throttle position
    Byte 21: Throt Sw/Fuel Sync     / System Board Error flags %%
    Byte 22: *Advance + knock mask  / ..?
    Byte 23: *warmup                / warmup
    Byte 24: ST Fuel Trim           / Stored errors %%%
    Byte 25: *temperature adc errors / recent errors %%%
    Byte 26: LT Fuel Trim           / Advance + knock correction
    Byte 27: Knock                  / Barometric pressure before start
    Byte 28: *..?                   / Adjustment off MAP
    Byte 29: A/C Sw/Request         / Switch values %%%%         / Switches possibly. changes when air is selected, makes sense
    Byte 30: 11th & 12th PROM       / Errors %%%%%
    For bitRead(x,y) x=value byte, y= position where bit 7 = 128/msb, bit 0 = 1/lsb
    % 7:Bad injector/6:TDC unable to be found/5:Roadspeed/4:Fuel pump/3:MAP bad/2:Knock sensor bad/1:Crank Pos Sens bad/0:unkown
    %% 7:Bad PROM version/6:Injector circuit fault/5:CPS variance/4:EEPROM CRC/3:ROM CRC/2~0:unknown
    %%% 7:TPS open/6:TPS short/5:CTS open/4:CTS short/3:IAT open/2:IAT short/1:EGR open/0:EGR short
    %%%% 7:Unknown/6:unknown/5:Sync(cam pos on 6pot?)/4:unknown/3:starter/2:AC engage/1:AC request/0:PARK (gears)
    %%%%% 7:Ignition module bad/6~4:unknown/3:oxygen relay/2:latch relay/1:aircon relay/0:unknown
  */
