//OLED Formatting code goes here

  //easy centering cursor for text size 1
void t1Cursor(byte t, byte h){ //# of characters, row
//Screen Width - Text Characters * Text Width / half the screen
  display.setCursor((W - t * 6) / 2, T1 * h);
}

  //easy manual cursor with t1 rows
void manuCursor(byte t, byte h){ //t2 column, row
//Screen Width - Text Characters * Text Width / half the screen
  display.setCursor((t * 12) - 10, T1 * h);
}

  //easy centering cursor for text size 2
void t2Cursor(byte t, byte h){ //# of characters, row 
//Screen Width - Text Characters * Text Width / half the screen
  display.setCursor((W - t * 12) / 2, T2 * h);
}

  //easy centering cursor for menus
void menuCursor(byte t, byte h){ //# of characters, row
  display.setCursor((W - t * 12) / 2, (h + 1) * 22);
}

  //displays top and bottom arrows
void menuArrows(){
  display.setCursor(0,0);
  display.setTextSize(2);
  display.print("<");
  display.setCursor(51,0);
  display.print(">");
  display.setCursor(0,112);
  display.print("<");//write(1);//left arrow
  display.setCursor(51,112);
  display.print(">");//write(2);//right arrow    
}
