//Stuff for controlling the free REM pins will go here 

byte IOupdate;

void updateIO(){
//INPUT is the default state of pins as it is high impedance
//analog read/write will automatically set the pinmode as needed
  //if (IOupdate == 1){
    if (EEPROM.read(EEfan1Pin) != 0)
      pinMode(EEPROM.read(EEfan1Pin), OUTPUT);
    //else
      //pinMode(EEPROM.read(EEfan1Pin), INPUT);//default pinstate is input, high impeidence 

      
    if (EEPROM.read(EEfan2Pin) != 0)
      pinMode(EEPROM.read(EEfan2Pin), OUTPUT);
    //else
      //pinMode(EEPROM.read(EEfan2Pin), INPUT);//default pinstate is input, high impeidence 


    if (EEPROM.read(EEfan3Pin) != 0)
      pinMode(EEPROM.read(EEfan3Pin), OUTPUT);
    //else
      //pinMode(EEPROM.read(EEfan3Pin), INPUT);//default pinstate is input, high impeidence 
    //IOupdate = 0;
  //}

//maybe later
   /* if (fanKill){
      if (EEPROM.read(EEfan1Pin)){
        digitalWrite(EEPROM.read(EEfan1Pin), LOW);
        fan1State = LOW;
      }
      if (EEPROM.read(EEfan2Pin)){
        digitalWrite(EEPROM.read(EEfan2Pin), LOW);
        fan2State = LOW;
      }
      if (EEPROM.read(EEfan3Pin)){
        digitalWrite(EEPROM.read(EEfan3Pin), LOW);
        fan3State = LOW;
      }
    }*/

    //else{
      if (EEPROM.read(EEfan1Pin)){
        switch(EEPROM.read(EEfan1Mode)){
          case off:
            digitalWrite(EEPROM.read(EEfan1Pin), LOW);
            fan1State = LOW;
          break;
          case on:
            digitalWrite(EEPROM.read(EEfan1Pin), HIGH);
            fan1State = HIGH;
          break;
          case Auto:
            // If AC is on, overrides temp
            if (EEPROM.read(EEac1Trigger) == true && ((engine == 2 && (ACRequest / 32) % 2) || (engine == 4 && (ACRequest / 64) % 2)) == true){
               digitalWrite(EEPROM.read(EEfan1Pin), HIGH);
               fan1State = HIGH;
            }
            else if (CTS >= EEPROM.read(EEtemp1on) && fan1State == LOW){
               digitalWrite(EEPROM.read(EEfan1Pin), HIGH);
               fan1State = HIGH;
            }
            else if (CTS <= EEPROM.read(EEtemp1off) && fan1State == HIGH){
              digitalWrite(EEPROM.read(EEfan1Pin), LOW);
              fan1State = LOW;
            }
          break;
        }
      //}
      
  
  
      if (EEPROM.read(EEfan2Pin)){
        switch(EEPROM.read(EEfan2Mode)){
          case off:
            digitalWrite(EEPROM.read(EEfan2Pin), LOW);
            fan2State = LOW;
          break;
          case on:
            digitalWrite(EEPROM.read(EEfan2Pin), HIGH);
            fan2State = HIGH;
          break;
          case Auto:
            // If AC is on, overrides temp
            if (EEPROM.read(EEac2Trigger) == true && ((engine == 2 && (ACRequest / 32) % 2) || (engine == 4 && (ACRequest / 64) % 2)) == true){
               digitalWrite(EEPROM.read(EEfan2Pin), HIGH);
               fan2State = HIGH;
            }
            else if (CTS >= EEPROM.read(EEtemp2on) && fan2State == LOW){
               digitalWrite(EEPROM.read(EEfan2Pin), HIGH);
               fan2State = HIGH;
            }
            else if (CTS <= EEPROM.read(EEtemp2off) && fan2State == HIGH){
              digitalWrite(EEPROM.read(EEfan2Pin), LOW);
              fan2State = LOW;
            }
          break;
        }
      }
  
  
      if (EEPROM.read(EEfan3Pin)){
        switch(EEPROM.read(EEfan3Mode)){
          case off:
            digitalWrite(EEPROM.read(EEfan3Pin), LOW);
            fan3State = LOW;
          break;
          case on:
            digitalWrite(EEPROM.read(EEfan3Pin), HIGH);
            fan3State = HIGH;
          break;
          case Auto:
            // If AC is on, overrides temp
            if (EEPROM.read(EEac3Trigger) == true && ((engine == 2 && (ACRequest / 32) % 2) || (engine == 4 && (ACRequest / 64) % 2)) == true){
               digitalWrite(EEPROM.read(EEfan3Pin), HIGH);
               fan3State = HIGH;
            }
            else if (CTS >= EEPROM.read(EEtemp3on) && fan3State == LOW){
               digitalWrite(EEPROM.read(EEfan3Pin), HIGH);
               fan3State = HIGH;
            }
            else if (CTS <= EEPROM.read(EEtemp3off) && fan3State == HIGH){
              digitalWrite(EEPROM.read(EEfan3Pin), LOW);
              fan3State = LOW;
            }
          break;
        }
      }
    }
}
