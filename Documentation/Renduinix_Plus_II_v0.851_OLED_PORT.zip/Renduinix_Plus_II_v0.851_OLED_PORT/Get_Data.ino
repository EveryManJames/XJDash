
//This is where we read in all the data and do stream switching. Fancy if statements to decide which streams to search for.
//In older versions using ATMEL arduinos with only 1 UART and limited space, this got really complicated. 
//Teensy boards makes this clean and much more efficient due to multiple UARTS.

void getData (){//void to create the data grabbing function
  
//if (menuOrder == Gauges || menuOrder == Diagnose || menuOrder == TCUGauges || menuOrder == Vehicle || menuOrder == TCUErrors) //No need to waste time grabbing data on other screens
//{

  /* The TCU framing is based purely off timing as there is a longer gap between frames. There are 70ms between 
   * the beginning of the last byte and the beginning of the first byte or 52ms from end to beginning. If we
   * want to read every single TCU frame reliably for the fastest possible data reading then we can skip the
   * final byte of the TCU for a time gap of 100ms/82ms. This should allow enough time to read in a full ECU Frame 
   * which can take from 16ms to 23+ms. It should be noted that the ECU data is sent 6x slower when the vehicle is 
   * off (100+ms frames) so we will only be able to read every other TCU frame.
   * 
   * OLD STUFF ^ Teensy can do it all without timing issues from software serial and sharing a single UART.
   * BUT, due to come clock division magic, you have to compile at 48mhz for 500 baud on Serial 1 and 2.
   * Serial 3 is only half the speed of 1 and 2 so safe to compile up to 120mhz if using 3.
   */

//tcu search and read    
    if (Serial3.available() > 0 && tcuReadFlag == false) { //search mode
      currentTime = millis();
      byteGap = (currentTime - tcuPrevTime); //calculate gap between bytes
      tcuPrevTime = currentTime; //set prev for next loop
      if (byteGap > 60 && byteGap < 85){ // some bytes show a gap of 108ms, while a proper end should be about 140ms
         tcuReadFlag = true; // Sets flag to start reading in a frame if beginning is found
         //for debugging, can comment out.
         /*Serial.print("Good ");
         current = Serial3.peek();
         if (current < 10)
          Serial.print(" ");
        if (current < 100)
          Serial.print(" "); 
        Serial.print(current);
        Serial.print("  ");
        Serial.print(byteGap);
        Serial.println(" mS");*/
      }
      else{ // if not the beginning then remove byte and start over
        current = Serial3.read(); //reads byte to pull it off the buffer
        //for debugging, can comment out.
        /*Serial.print("Dump ");
        if (current < 10)
          Serial.print(" ");
        if (current < 100)
          Serial.print(" "); 
        Serial.print(current);
        Serial.print("  ");
        Serial.print(byteGap);
        Serial.println(" mS");*/
      }
    }//end search mode
       
    if (Serial3.available() >= 7 && tcuReadFlag == true){ //read mode
      for (Position = 0; Position < 7; Position++){
        tcuDataStream[Position] = Serial3.read(); //read 7 bytes into the array straight off the buffer.
        if (Position == 6){ //0 indexed. looks for final byte read
          tcuPrevTime = millis(); //updates prev time to help search code
          if (tcuDataStream[0] != 1) //Module ID checksum, should always be 1
            tcuReadFlag = false;  //sets flag back to search mode if not 1
          else{
            //ModuleID = tcuDataStream[0];//set stream values to friendly vairables
            tcuTPS = tcuDataStream[1];
            tcuRPM = (tcuDataStream[2] * 34);             
            //PRNDL = tcuDataStream[3];
            //Brake = tcuDataStream[3];  
            Mode = tcuDataStream[3]; //no real need for duplicate variables
            Solenoids = tcuDataStream[4];
            //LockUp = tcuDataStream[4]; 
            //CurrentGear = tcuDataStream[4];
            SolenoidFaults = tcuDataStream[5];     
            TPSFaults = tcuDataStream[6];
        
            MPH = 0.00595 * tcuRPM * TireSize / 2 / GearRatio / 100 * SpeedCorr;//(RPM*Tire Radius/Gear Ratio)*Speed Correction
            //MPH = (0.00595*(tcuRPM * (TireSize / 2))/GearRatio)*(SpeedCorr/100); //old calc which needed floats
            if (speedUnit == false)//KPH conversion
              MPH = MPH * 1.609;
            
            tcuStreamUpdate = true; //tells screen to refresh with new data  
          }//else end
        }//final byte code end
      }//tcu read for loop end
    }//read mode end
    
//for debugging, can comment out.
    /*if (tcuStreamUpdate == true){
      for (Position = 0; Position < 7; Position++){
        Serial.print(" ");
        Serial.print(tcuDataStream[Position]);
        if (Position == 6){
          Serial.println(" ");
          tcuStreamUpdate = false;
        }
      }
    }//debug raw stream read end
*/

  /* This sequence loops three bytes over and over, in sequence through the three memory locations. Useful 3-byte search. 
   * We are looking for a particular sequence, specifically not-255, 255, 0. If a normal byte has a value of 255 then 
   * it will send a second 255 to show that it is valid data and not the end of the stream so we have to filter that out.
   * Program Number has been added to the search to improve accuracy.
   */

    if (Serial1.available() > 39 )  // Make sure the buffer has read in 31 bytes, 0 indexed.      
    {
      prev = current;  // Shift old bytes back a variable
      current = Serial1.read();
      next = Serial1.peek(); // Read the first byte on the buffer without removing it
     
      if (prev == 255 && current == 0){
      if ((engine == 4 && (next == 176 || next == 177)) || (engine == 2 && next == 32)) //searches for specific Program Number for accuracy
      { 
        for (Position = 0; Position < 31; Position++)
        {
          dataStream[Position] = Serial1.read();  //  Loop 31 bytes into the array straight off the buffer.
          if (dataStream[Position] == 255 && Serial1.peek() == 255 && dataStreamCounter == false) //Checks if it's the first instance of a double 255
          {
            --Position; //sets the position back a click to overwrite the extra 255
            dataStreamCounter = true; //set flag to prevent overwriting the "good" 255
          }
          else dataStreamCounter = false; //resets double 255 flag
        } 
      }//read if end
    }//3 byte search end
  }//ecu search end
  
  // Read the various bytes and words of the array into variables, so calculations can be easily performed
    
    //ProgramVersion = dataStream[0];           // Not useful as an average, we want the instantaneous
    //PROMversion = dataStream[1];            
    //CalibrationCode = dataStream[2];          
    //if (engine == 2)
      //PROM = (dataStream[0], dataStream[1]);
    //else
      //PROM = (dataStream[0], dataStream[1], dataStream[2], dataStream[11], dataStream[10], dataStream[30]);
      
    MAPRaw = dataStream[3];                // Value before calculations 
    CTSRaw = dataStream[4];    
    IATRaw = dataStream[5];    
    
    if (engine == 2)
      Volts = (dataStream[6] / 31.875 + 8); //converts to Volts (8 - 16)
    else
      Volts = (dataStream[6] / 16.24);      //converts to Volts (0 - 15.7)
      
    if (engine == 2)
      Lambda = (dataStream[7] * 4.34);      //converts to mV (0 - 1,106.7)
    else
      Lambda = (dataStream[7] / 51.2);      //converts to V (0 - 4.98)
    
    if (word(dataStream[9], dataStream[8]) > 303){        //9 & 8 are combined into a 16 bit "word" that can then be dec converted and divided.
      RPM = 19868686 / word(dataStream[9], dataStream[8]);//ex: 9 = 128 & 8 = 128. 128,128 in binary is 1000000010000000 or 32896 when converted to dec.                                                                                        
    if (engine == 2)
      RPM = RPM * 1.5;
    }
    else RPM = 0;//Calibrated to MS1700 Math
        
    //PROM9_10 = dataStream[10];
    //PROM7_8 = dataStream[11];
    TPS = (dataStream[12] / 2.55);       // Throttle position sensor in Percentage. (0 - 100)
    SparkADV = dataStream[13];           // Ignition Timing in degrees (0 - 255)
    //Unknown14 = dataStream[14];          
    //Unknown15 = dataStream[15];
    BaroRaw = dataStream[16];            //Initial MAP reading before Startup
    //Unknown17 = dataStream[17];
    //LoopStatus = dataStream[18];
    Exhaust = dataStream[18];
    
    if (engine == 2){
      InjPulse = (word(dataStream[11], dataStream[10]) / 100);  //Pulse Width in mS (0 - 65.5), word doesn't allow decimal so /10 later
      InjPulse = InjPulse / 10;
    }
    else
      InjPulse = (dataStream[19] / 7.79);  //Pulse Width in mS (0 - 32.7), /10 later to match 2.5L needs
    
    //Unknown20 = dataStream[20];         
    //ThrottleSwitch = dataStream[21];
    FuelSync = dataStream[21];
    //Unknown22 = dataStream[22];
    //Unknown23 = dataStream[23];
    STFuel = dataStream[24];             //short term fuel trim (0 - 255)
    //Unknown25 = dataStream[25];
    LTFuel = dataStream[26];             //long term fuel trim (0 - 255)
    Knock = dataStream[27];              //knock sensor (0 - 255)
    //Unknown28 = dataStream[28];
    //ACSwitch = dataStream[29];           //text from specific intervals
    
    if (engine == 2)
      ACRequest = dataStream[2]; //2.5L A/C & Throttle Sw
    else
      ACRequest = dataStream[29];          //same as above
    
    //PROM11_12 = dataStream[30];
    LambdaHeater = 0.0181 * analogRead(o2HeaterPin) + 0.44; //Calibrated in Excel to diode to 10k/2.2K Vdiv
    
    if (LambdaHeater < 0.5)//show clean 0 because diode drop out
      LambdaHeater = 0;

    AFR = 0.0107 * analogRead(AFRPin) + 10; // 2.2k and 3.3k voltage divider needed
    
    InjDuty = (RPM*InjPulse)/1200;
    GPH = 18.927 * InjDuty / 100;
    
    if (speedUnit == false)//LPH conversion
      GPH = GPH * 3.785;
    
    MPG = MPH / GPH;//:^) personal end goal here...
    
    if (speedUnit == false)//LHK conversion
      MPG = 100 / MPG;//remember MPG is really KPL when set to KPH
      
    //MAP calculations
    switch(pressureUnit){
      /*case 1://Voltage Calc
        MAP = (MAPRaw / 51);//converts to Voltage (0 - 5)
      break;*/
      case 2://inHg
        MAP = (MAPRaw/ 9.13 + 3.1); //converts to "Hg (3.1 - 31)
      break;
      case 3://KPA
        MAP = (MAPRaw/ 2.7 + 11);//converts to KPA (11 - 105)
      break;
      case 4://PSI
        MAP = (MAPRaw/ 18.6 + 1.5);//converts to PSI (1.52 - 15.2)
      break;
     }
    // CTS Calculations
    if (tempUnit == false)
      CTS = (CTSRaw / 1.6 - 40); //converts to Celsius (-40 - 119)
    else
      CTS = (CTSRaw / .888 - 40); //converts to Fahrenheit (-40 - 247)
    //IAT Calculations
    if (tempUnit == false)
      IAT = (IATRaw / 1.6 - 40); //converts to Celsius (-40 - 119)
    else
      IAT = (IATRaw / .888 - 40); //converts to Fahrenheit (-40 - 247)

//}//menuOrder if end

//Bluetooth Stuff
currentTime = millis();
if (EEPROM.read(EEbluetooth) == true && currentTime > btPrev + 100){
  btPrev = currentTime;
  
  bluetoothStream[0] = dataStream[3]; //MAP
  bluetoothStream[1] = dataStream[4]; //CTS
  bluetoothStream[2] = dataStream[5]; //IAT
  bluetoothStream[3] = dataStream[6]; //VOLTS
  bluetoothStream[4] = dataStream[7]; //O2
  bluetoothStream[5] = RPM / 20;//dataStream[8]; //RPM Lo bootleg convert for app
  bluetoothStream[6] = dataStream[9]; //RPM Hi, not used currently
  bluetoothStream[7] = dataStream[12]; //TPS
  bluetoothStream[8] = dataStream[13]; //IGN ADVANCE
    
  if ((Exhaust / 2) % 2)               //LOOP
    bluetoothStream[9] = 3; // decel
  else if (Exhaust / 64 % 2)
    bluetoothStream[9] = 2; //clsd
  else bluetoothStream[9] = 1; //open

  if (Exhaust < 128)                   //EXHAUST
    bluetoothStream[10] = 1; 
  else
    bluetoothStream[10] = 2;
  
  bluetoothStream[11] = dataStream[19]; //INJ MS
  bluetoothStream[12] = dataStream[27]; //KNOCK
  bluetoothStream[13] = dataStream[16]; //BARO
  bluetoothStream[14] = dataStream[24]; //STFT
  bluetoothStream[15] = dataStream[26]; //LTFT
  
  Serial2.write(byte(119));           //Control byte
  for (byte i = 0; i < 16; i++)
    Serial2.write(byte(bluetoothStream[i]));
}

if (RPM > 500 && RPM < 5200 && MinMaxCheck == 0){ // stage 1 of the Min/Max Reset for engine running conditions 
      MinMaxCheckTime = millis(); //records time and updates check for stage 2
      MinMaxCheck = 1; //sets flag for next stage
    }
    currentTime = millis();
    if (MinMaxCheck == 1 && (currentTime > MinMaxCheckTime + 5000)){ //resets min/max after 5 seconds of engine running
      MinMaxReset = true; //trips reset flag
      MinMaxCheck = 2; //sets flag to prevent multiple resets
    }

    if (currentTime > 500){//fitlers out odd startup values
      if ((MAP < MAPMin && MAP != 0) || MinMaxReset == true) //Min and Max Recording
        MAPMin = MAP;
      if ((MAP > MAPMax && MAPRaw != 255) || MinMaxReset == true)
        MAPMax = MAP;
        
      if ((CTS < CTSMin && CTS != 0) || MinMaxReset == true)
        CTSMin = CTS;
      if ((CTS > CTSMax && CTSRaw != 255) || MinMaxReset == true)
        CTSMax = CTS;
        
      if ((IAT < IATMin && IAT != 0) || MinMaxReset == true)
        IATMin = IAT;
      if ((IAT > IATMax && IATRaw != 255) || MinMaxReset == true)
        IATMax = IAT;
        
      if ((RPM < RPMMin && RPM != 0) || MinMaxReset == true)
        RPMMin = RPM;
      if ((RPM > RPMMax && RPM < 7000) || MinMaxReset == true)
        RPMMax = RPM;
        
      if ((Volts < VoltsMin && Volts != 0) || MinMaxReset == true)
        VoltsMin = Volts;
      if ((Volts > VoltsMax && Volts < 15.8) || MinMaxReset == true)
        VoltsMax = Volts;
        
      if ((TPS < TPSMin && TPS != 0) || MinMaxReset == true)
        TPSMin = TPS;
      if ((TPS > TPSMax && TPS < 99) || MinMaxReset == true)
        TPSMax = TPS;
        
      if ((Lambda < LambdaMin && Lambda != 0) || MinMaxReset == true)
        LambdaMin = Lambda;
      if (Lambda > LambdaMax || MinMaxReset == true)
        LambdaMax = Lambda;
        
      if ((Knock < KnockMin && Knock != 0) || MinMaxReset == true)
        KnockMin = Knock;
      if ((Knock > KnockMax && Knock < 254) || MinMaxReset == true)
        KnockMax = Knock;
        
      MinMaxReset = false;
    }//current time if end
    
//fake number code
/*
if (updateTimedScreen == true){
    ++counter;
for (byte l = 0; l < 31; l++)
    dataStream[l] = counter;
for (byte l = 0; l < 7; l++)
    tcuDataStream[l] = counter;
    //ModuleID = tcuDataStream[0];//set stream values to friendly vairables
            tcuTPS = tcuDataStream[1];
            tcuRPM = (tcuDataStream[2] * 34);             
            //PRNDL = tcuDataStream[3];
            //Brake = tcuDataStream[3];  
            Mode = tcuDataStream[3]; //no real need for duplicate variables
            Solenoids = tcuDataStream[4];
            //LockUp = tcuDataStream[4]; 
            //CurrentGear = tcuDataStream[4];
            SolenoidFaults = tcuDataStream[5];     
            TPSFaults = tcuDataStream[6];
        
            MPH = 0.00595 * tcuRPM * TireSize / 2 / GearRatio / 100 * SpeedCorr;//(RPM*Tire Radius/Gear Ratio)*Speed Correction
            //MPH = (0.00595*(tcuRPM * (TireSize / 2))/GearRatio)*(SpeedCorr/100); //old calc which needed floats
            if (speedUnit == false)//KPH conversion
              MPH = MPH * 1.609;
}*/

}//Void end
