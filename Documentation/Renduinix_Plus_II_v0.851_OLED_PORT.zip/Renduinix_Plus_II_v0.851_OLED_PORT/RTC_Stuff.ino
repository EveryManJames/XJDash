
//Most things related to the Real Time Clock will go here, V3 Only

char daysOfTheWeek[7][4] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
byte oldSecond;
unsigned long oldMilSec;
byte Ehour;
byte Eminute;
byte Esecond;
bool Eblink;
bool PMflag;

byte hrHi;
byte hrLo;
byte minHi;
byte minLo;
byte secHi;
byte secLo;

void easyTime() //helps format time for easier display
{
  DateTime now = rtc.now();
  
//Hour Formatting
  if (hourSetting == true){ //12hour display
    if (now.hour() == 0) //12am
      Ehour = 12;
    else if (now.hour() > 12) //pm
      Ehour = now.hour() - 12;
    else //am
    Ehour = now.hour();
  }
  else //24 hour
    Ehour = now.hour();

//Minute Formatting, just so DateTime doesn't have to be called twice
  Eminute = now.minute();

//Second Formatting
  Esecond = now.second();
  
//Second Colon Blinking
  if (oldSecond != now.second()){
    oldMilSec = millis();
    oldSecond = now.second();
    Eblink = true;
  }
  if (millis() > oldMilSec + 500)
    Eblink = false;

//AM/PM flag
  if (now.hour() > 11)
    PMflag = true;
  else
    PMflag = false;

//Seven Seg Clock breakdowns
  hrHi = Ehour / 10;
  hrLo = Ehour - (hrHi * 10);
    
  minHi = Eminute/10;
  minLo = Eminute - (minHi * 10);  
}

void displayTimeBig()
{
  easyTime();
  
  display.setTextSize(1);
  if (hourSetting == true){//12hour display
    if (PMflag == true)
      display.print("PM");
    else
      display.print("AM");
  }
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);//0 spaces right
  display.setTextSize(2);
  
  if (Ehour < 10)
    display.print(" ");
  display.print(Ehour);
  
  if (Eblink == true)
    display.print(":");
  else
    display.print(" ");
    
  if (Eminute < 10)
    display.print("0");
  display.print(Eminute);
}

void displayDateBig ()
{
  DateTime now = rtc.now();
  //if (now.day() < 10)
    //display.print(" ");
  /*display.print(daysOfTheWeek[now.dayOfTheWeek()]);
  display.print(" ");*/
  if (now.month() < 10)
    display.print(" ");
  display.print(now.month());
  display.print("/");
  display.print(now.day());
  //display.print("/");
  //display.print(now.year()-2000);
}

void displayTimeTiny()
{
  easyTime();

  if (Ehour < 10)
    display.print(" ");
  display.print(Ehour);


  if (Eblink == true)
    display.print(":");
  else
    display.print(" ");
    
  
  if (Eminute < 10)
    display.print("0");
  display.print(Eminute);
  
  if (hourSetting == true){//12hour display
    if (PMflag == true)
      display.print(" PM");
    else
      display.print(" AM");
  }
  else{
    if (Eblink == true)
      display.print(":");
    else
      display.print(" ");
    
    if (Esecond < 10)
      display.print("0");
    display.print(Esecond);
  }
  
}

void displayDateTiny()
{
  DateTime now = rtc.now();
  //if (now.day() < 10)
    //display.print(" ");
  /*display.print(daysOfTheWeek[now.dayOfTheWeek()]);
  display.print(" ");*/
  if (now.month() < 10)
    display.print(" ");
  display.print(now.month());
  display.print("/");
  display.print(now.day());
  display.print("/");
  display.print(now.year()-2000);
}
