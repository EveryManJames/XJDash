//Stuff for general Gauge Display will go here

//function to autoskip gauges
byte gaugeSkip (byte dOrder){
  byte dSkip = 255;//default value to prevent wrong 0 placement

  if (dOrder == outputsGauge && EEPROM.read(EEfan1Pin) == 0 && EEPROM.read(EEfan2Pin) == 0 && EEPROM.read(EEfan3Pin) == 0)//menu skip
    dSkip = 128; //autoskip
        
  if ((dOrder == throttleGauge && loopMode == false))
    dSkip = 128; //autoskip for throttle/loop combo gauge

  if (EEPROM.read(EEgyroscope) == false){
    if (dOrder == gyroGauge)
      dSkip = timeGauge; //autoskip for gyro
  }

  if (dOrder == accelGauge || dOrder == magGauge)
      dSkip = timeGauge; //autoskip for gyro
   
  if (dOrder >= dataTotal || (dOrder > GPHGauge && transType == false)) //checks if order is out of bounds
    dSkip = 0; //sets it back to 0 if above is true
  
  return dSkip;    
}

void celOn ()
{
  //analogWrite(celpin, celDim);
  digitalWrite(celpin, HIGH);  
}
void celOff ()
{
  analogWrite(celpin, 0);
}
void celStar ()
{
  if (dataOrder1 == celGauge){
    display.setCursor(50,0);
    display.print("*");
  }
  if (dataOrder2 == celGauge){
    display.setCursor(50,32);
    display.print("*");
  }
  if (dataOrder3 == celGauge){
    display.setCursor(50,64);
    display.print("*");
  }
  if (dataOrder4 == celGauge){
    display.setCursor(50,96);
    display.print("*");
  }
}

void displayPROM ()
{
  //display.print(PROM, HEX);
  if (engine == 2){
    display.print(dataStream[0], HEX);
    display.print(dataStream[1], HEX);
  }
  else{
    display.print(dataStream[0], HEX);
    display.print(dataStream[1], HEX);
    display.print(dataStream[2], HEX);
    display.print(dataStream[11], HEX);
    display.print(dataStream[10], HEX);
    display.print(dataStream[30], HEX);
  }
}
void displayMAP ()
{
  display.setTextSize(1);
  display.print(F("MAP"));
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (MAP < 10)
    display.print(" ");//adds extra space to keep formatting
  if (MAP < 100)
    display.print(" "); //1 spacer
  display.print(MAP, 1); //else 1 decimal point
}
void displayVacuum ()
{ 
  VacuumRaw = BaroRaw - MAPRaw;     
  switch(pressureUnit)
  {
    /*case 1://Bars Calc
      Vacuum = (VacuumRaw/25.5) / 10;//converts to Bar, got no results with /255 so it's split into 2 stages
    break;*/
    case 2://inHg
      Vacuum = (VacuumRaw/ 9.13); //converts to "Hg
    break;
    case 3://KPA
      Vacuum = (VacuumRaw/ 2.7);//converts to KPA
    break;
    case 4://PSI
      Vacuum = (VacuumRaw/ 18.6);//converts to PSI
    break;
    }
  display.setTextSize(1);
  display.print(F("VAC"));
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (Vacuum < 10 && pressureUnit != 1)
    display.print(" ");//adds extra space to keep formatting
  if (Vacuum < 100)
    display.print(" "); //1 spacer
  //if (pressureUnit == 1)
    //display.print(Vacuum, 2); //bar display
  display.print(Vacuum, 1); //else 1 decimal point
}
void displayCTS ()
{
  display.setTextSize(1);
  display.print(F("WT"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);//2 spaces right
  display.setTextSize(2);
  
  if (CTS >= -9 && CTS <= 99)
    display.print(" ");
  if (CTS >= 0 && CTS <= 9)
    display.print(" ");
  display.print(CTS);
  if (tempUnit == false)
    display.print("C");//display.write(4);       //writes custom character 4 (celsius)
  else display.print("F");//display.write(3);    //writes custom character 3 (fahrenheit)
}
void displayIAT ()
{
  display.setTextSize(1);
  display.print(F("IAT"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);//2 spaces
  display.setTextSize(2);
  
  if (IAT >= -9 && IAT <= 99)
    display.print(" ");
  if (IAT >= 0 && IAT <= 9)
    display.print(" ");
  display.print(IAT);
  if (tempUnit == false)
    display.print("C");//display.write(4);       //writes custom character 4 (celsius)
  else display.print("F");//display.write(3);    //writes custom character 3 (fahrenheit)
}
void displayRPM ()
{
  display.setTextSize(1);
  display.print(F("RPM"));
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (RPM < 10)
    display.print(" ");
  if (RPM < 100)
    display.print(" ");
  if (RPM < 1000)
    display.print(" ");
  if (RPM < 10000)
    display.print(" ");
  display.print(RPM);
}
void displayVolts ()
{
  display.setTextSize(1);
  display.print(F("VLT"));
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);//1sp
  display.setTextSize(2);
  if (Volts < 10)
    display.print(" ");
  display.print(Volts, 1); //1 decimal point
  display.print("v");
}
void displayLambda ()
{
  display.setTextSize(1);
  display.print(F("O2"));//extra spacer
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  display.print(Lambda,2);
  display.print("v");  
}
void displayExhaust ()
{
  display.setTextSize(1);
  display.print(F("EX"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if (Exhaust < 128)
    display.print("Lean"); //if less than do
  else
    display.print("Rich"); // else do greater than
}
void displayLambdaHeater ()
{
  display.setTextSize(1);
  display.print(F("HTR"));//extra spacer
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (LambdaHeater < 9.95) // < 10 gives jumpy results, this math fixes it
    display.print(" ");
  display.print(LambdaHeater, 1);
  display.print("v");
}
void displayLoopStatus ()
{
  // _Clsd_LP
  // _Cls_Cls _Prt_Dcl _WOT_Opn
  display.setTextSize(1);
  display.print("LP");
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if (loopMode == false && menuOrder == Gauges){//Combo Mode*************
    if ((FuelSync / 8) % 2 ^ (FuelSync / 2) % 2){ //bitwise odd math checks both outputs are different(XOR) to weed out P
      if ((FuelSync / 2) % 2) //now if odd then W
        display.print("  WOT"); 
      else display.print(" Cls"); //Else C from second if
    }
    else display.print(" Prt"); //Else P from XOR if  
    if ((Exhaust / 2) % 2) //bitwise math checks even or odd, 0 indexed every 2 #'s
      display.print(" Dcl"); //if odd do, Decel is always #/2 odd
    else if (Exhaust / 64 % 2)
      display.print(" Cls"); //if #/64 odd do, 64-127, 192-255
    else display.print(" Opn"); //Else even do, 0-63, 128-191
  }
  else{//Normal Mode*********************
    if ((Exhaust / 2) % 2) //bitwise math checks even or odd, 0 indexed every 2 #'s
      display.print("Dcel"); //if odd do, Decel is always #/2 odd
    else if (Exhaust / 64 % 2)
      display.print("Clsd"); //if #/64 odd do, 64-127, 192-255
    else display.print("Open"); //Else even do, 0-63, 128-191
  }
}
void displayEGR ()
{
  display.setTextSize(1);
  display.print(F("EGR"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if ((Exhaust / 64) % 2)
    display.print(" On"); //if odd
  else display.print("Off"); //else even
}
void displayTPS ()
{
  display.setTextSize(1);
  display.print("TPS");//extra spacer
  gaugeCursor += gaugeSpace;
  display.setTextSize(2);
  if (tpsMode == false){//Advance TPS Mode
    display.setCursor(0, gaugeCursor);
    if ((FuelSync / 8) % 2 ^ (FuelSync / 2) % 2){ //bitwise odd math checks both outputs are different(XOR) to weed out P
      if ((FuelSync / 2) % 2) //now if odd then W
        display.print("W "); 
      else display.print("C "); //Else C from second if
    }
      else display.print("P "); //Else P from XOR if
  }
  else display.setCursor(24, gaugeCursor);
  if (TPS < 10)
    display.print(" ");
  display.print(TPS);
  display.print("%");
}
void displayThrottleSwitch ()
{ /*Ok, this one's trickey. This value is extracted from the same byte as Fuel Sync so there are lots of possible outcomes to cope with.
   *The output is determined by 2 stages of division. #/8 will seperate P/W(Even) from C/P(Odd), then #/2 will decided W/C or P.
   *A Truth Table shows us the logic is XOR: 
   *#/8 odd  && #/2 odd  = P, oo = 0
   *#/8 odd  && #/2 even = C, oe = 1
   *#/8 even && #/2 odd  = W, eo = 1
   *#/8 even && #/2 even = P, ee = 0
   *Now we can break it down into a few if statements
   */
  display.setTextSize(1);
  display.print(F("THR"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if ((FuelSync / 8) % 2 ^ (FuelSync / 2) % 2){ //bitwise odd math checks both outputs are different(XOR) to weed out P
    if ((FuelSync / 2) % 2) //now if odd then W
      display.print(" WOT"); 
    else display.print("Clsd"); //Else C from second if
  }  
  else display.print("Part"); //Else P from XOR if  
}
void displaySparkADV ()
{
  display.setTextSize(1);
  display.print(F("IGN"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (SparkADV < 10)
    display.print(" ");
  if (SparkADV < 100)
    display.print(" ");
  display.print(SparkADV);
}
void displayKnock ()
{
  display.setTextSize(1);
  display.print(F("KNO"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (Knock < 10)
    display.print(" ");
  if (Knock < 100)
    display.print(" ");
  display.print(Knock);
}
void displayInjPulse ()
{
  display.setTextSize(1);
  display.print(F("mS"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if (InjPulse < 9.95) //< 10 produces erract result at the 9-10 transition 
    display.print(" ");
  display.print(InjPulse, 1); // 1 decimal
}
void displayInjDuty ()
{
  display.setTextSize(1);
  display.print("DC");
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (InjDuty < 10)
    display.print(" ");
  display.print(InjDuty,1);
  display.print("%");
}
void displayFuelSync ()
{
  display.setTextSize(1);
  display.print(F("SYN"));
  gaugeCursor += gaugeSpace;
  display.setCursor(48, gaugeCursor);
  display.setTextSize(2);
  if ((FuelSync / 4) % 2) { //bitwise magic that compares even or odd, 0 indexed every 4 #'s
    display.print("-"); // if odd do
  }
  else {
    display.print("+"); // if even do
  }
}
void displaySTFuel ()
{ 
  display.setTextSize(1);
  display.print(F("STFT"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (STFuel < 10)
    display.print(" ");
  if (STFuel < 100)
    display.print(" ");
  display.print(STFuel);
}
void displayLTFuel ()
{
  display.setTextSize(1);
  display.print(F("LTFT"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (LTFuel < 10)
    display.print(" ");
  if (LTFuel < 100)
    display.print(" ");
  display.print(LTFuel);
}
void displayACSwitch ()
{
  display.setTextSize(1);
  display.print(F("A/C"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (engine == 4 && (ACRequest / 32) % 2)
    display.print(" On"); //if odd
  else display.print("Off"); //else even
}
void displayACRequest ()
{
  display.setTextSize(1);
  display.print(F("REQ"));
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if (engine == 4 && (ACRequest / 64) % 2)
    display.print("Yes"); //if odd
  else display.print(" No"); //else even
}
void displayGPH ()
{
  display.setTextSize(1);
  if (MPH == 0){//GPH Mode
    if (speedUnit == false)
      display.print("LPH");
    else
      display.print("GPH");
    
    gaugeCursor += gaugeSpace;
    display.setCursor(0, gaugeCursor);
    display.setTextSize(2);  
    if (GPH < 100)
      display.print(" ");
    if (GPH < 10)
      display.print(GPH,2);
    else
      display.print(GPH,1);
  }
    
  else{ //MPG Mode
    
    if (speedUnit == false)
      display.print("LHK");
    else
      display.print("MPG");
    gaugeCursor += gaugeSpace;
    display.setCursor(0, gaugeCursor);
    display.setTextSize(2);
    if (MPG < 100)
      display.print(" ");
    if (MPG < 10)
      display.print(" ");
    display.print(MPG,1);
  }
}
void displayMPH ()
{
  display.setTextSize(1);
  if (speedUnit == false)
    display.print("KPH");
  else
    display.print("MPH");
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);
  if(MPH < 10)
    display.print(" ");
  if(MPH < 99.5)
    display.print(" ");
  display.print(MPH,0);
}
void displayGear ()
{ 
  display.setTextSize(1);
  display.print("GEAR");
  gaugeCursor += gaugeSpace;
  display.setCursor(24, gaugeCursor);
  display.setTextSize(2);

  if ((Solenoids / 32) == 6) 
    display.print("1st");
  else if ((Solenoids / 32) % 4 == 0)
    display.print("2nd");
  else if ((Solenoids / 32) % 4 == 1)
    display.print("3rd");
  else if ((Solenoids / 32) % 4 == 3)
    display.print("4th");
  else
    display.print("???");
  
}
void displayTransInfo ()
{
  display.setTextSize(1);
  display.print("TCU");
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);
  if (Mode % 2) //odd, Brake
    display.print(" ");
  else //even
    display.print("B");

  if ((Solenoids / 32) % 2) //odd
    display.print(" ");
  else //even
    display.print("1");

  if ((Solenoids / 64) % 2) //odd
    display.print(" ");
  else //even
    display.print("2");

  if (Solenoids < 128)
    display.print("L");
  else 
    display.print(" ");
  display.print(tcuTPS); 
}
/*void displayCheck ()
{
  display.print(" "); //1 spacer
  if (PROM11_12 == 242 || PROM11_12 == 243 || PROM11_12 == 247)
    display.print("Gud"); //if True
  else display.print(PROM11_12); //Else show naughty number
  display.print("Data");
}*/
void displayBaro ()
{
  switch(pressureUnit)
  {
    /*case 1://Bars Calc
      Baro = (BaroRaw/25.5) / 10;//converts to Bar, got no results with /255 so it's split into 2 stages
    break;*/
    case 2://inHg
      Baro = (BaroRaw/ 9.13 + 3.1); //converts to "Hg
    break;
    case 3://KPA
      Baro = (BaroRaw/ 2.7 + 11);//converts to KPA
    break;
    case 4://PSI
      Baro = (BaroRaw/ 18.6 + 1.5);//converts to PSI
    break;
    }
  display.setTextSize(1);
  display.print(F("Baro"));
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if (Baro < 10)
    display.print(" ");
  //display.print(" "); //1 spacer
  display.print(Baro, 1); //1 decimal
}
void displayOutputs()
{
  display.setTextSize(1);
  if (EEPROM.read(EEfan1Pin) != 0)
    display.print(F("F1 "));
  if (EEPROM.read(EEfan2Pin) != 0)
    display.print(F("F2 "));
  if (EEPROM.read(EEfan3Pin) != 0)
    display.print(F("F3"));
    
  gaugeCursor += gaugeSpace;
  display.setCursor(0, gaugeCursor);
  display.setTextSize(2);

  if (EEPROM.read(EEfan1Pin) == 0 || EEPROM.read(EEfan2Pin) == 0 || EEPROM.read(EEfan3Pin) == 0){
    display.print(" ");
  }
  
  if (EEPROM.read(EEfan1Pin) != 0){
    if (fan1State == HIGH)
      display.print("1 ");
    else display.print("- ");
  }

  if (EEPROM.read(EEfan2Pin) != 0){
    if (fan2State == HIGH)
      display.print("2 ");
    else display.print("- ");
  }

  if (EEPROM.read(EEfan3Pin) != 0){
    if (fan3State == HIGH)
      display.print("3");
    else display.print("-");
  }
}
void displayAFR()
{
  display.setTextSize(1);
  display.print(F("AFR"));//extra spacer
  gaugeCursor += gaugeSpace;
  display.setCursor(12, gaugeCursor);
  display.setTextSize(2);
  if (AFR < 9.95) // < 10 gives jumpy results, this math fixes it
    display.print(" ");
  display.print(AFR, 1);
}

